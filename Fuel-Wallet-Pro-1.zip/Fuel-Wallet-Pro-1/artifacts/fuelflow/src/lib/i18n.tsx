import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { translations, type Language, type TranslationKey } from "./translations";
import { ar as dfAr, enUS as dfEn } from "date-fns/locale";

type Vars = Record<string, string | number>;

type LanguageContextValue = {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: TranslationKey, vars?: Vars) => string;
  dir: "ltr" | "rtl";
  formatCurrency: (amount: number, opts?: { decimals?: number }) => string;
  formatNumber: (n: number, opts?: { decimals?: number }) => string;
  dateLocale: typeof dfEn;
};

const LanguageContext = createContext<LanguageContextValue | null>(null);

const STORAGE_KEY = "fuelflow.lang";

function getInitial(): Language {
  if (typeof window === "undefined") return "en";
  const params = new URLSearchParams(window.location.search);
  const fromUrl = params.get("lang");
  if (fromUrl === "ar" || fromUrl === "en") {
    window.localStorage.setItem(STORAGE_KEY, fromUrl);
    return fromUrl;
  }
  const stored = window.localStorage.getItem(STORAGE_KEY);
  return stored === "ar" || stored === "en" ? stored : "en";
}

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguageState] = useState<Language>(getInitial);
  const dir: "ltr" | "rtl" = language === "ar" ? "rtl" : "ltr";

  useEffect(() => {
    document.documentElement.dir = dir;
    document.documentElement.lang = language;
    document.documentElement.classList.toggle("rtl", dir === "rtl");
  }, [dir, language]);

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    try {
      window.localStorage.setItem(STORAGE_KEY, lang);
    } catch {
      /* ignore */
    }
  };

  const t = (key: TranslationKey, vars?: Vars) => {
    const dict = translations[language] as Record<string, string>;
    let text = dict[key] ?? (translations.en as Record<string, string>)[key] ?? key;
    if (vars) {
      for (const [k, v] of Object.entries(vars)) {
        text = text.replace(new RegExp(`\\{${k}\\}`, "g"), String(v));
      }
    }
    return text;
  };

  const formatNumber = (n: number, opts?: { decimals?: number }) => {
    const decimals = opts?.decimals ?? 2;
    return new Intl.NumberFormat("en-US", {
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals,
    }).format(n);
  };

  const formatCurrency = (amount: number, opts?: { decimals?: number }) => {
    const decimals = opts?.decimals ?? 2;
    const num = formatNumber(amount, { decimals });
    return language === "ar" ? `${num} ج.م` : `EGP ${num}`;
  };

  const dateLocale = language === "ar" ? dfAr : dfEn;

  return (
    <LanguageContext.Provider
      value={{ language, setLanguage, t, dir, formatCurrency, formatNumber, dateLocale }}
    >
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const ctx = useContext(LanguageContext);
  if (!ctx) throw new Error("useLanguage must be used within LanguageProvider");
  return ctx;
}
