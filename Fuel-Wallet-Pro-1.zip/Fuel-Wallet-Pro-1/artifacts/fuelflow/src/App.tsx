import { lazy, Suspense, useEffect, useRef } from "react";
import { ClerkProvider, SignIn, SignUp, Show, useClerk } from "@clerk/react";
import { shadcn } from "@clerk/themes";
import { AppShell } from "@/components/layout/app-shell";
import { Switch, Route, useLocation, Router as WouterRouter, Redirect } from "wouter";
import { QueryClient, QueryClientProvider, useQueryClient } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { DashboardSkeleton } from "@/components/ui/loading-skeleton";
import { LanguageProvider } from "@/lib/i18n";
import NotFound from "@/pages/not-found";
import Landing from "@/pages/landing";

const Dashboard = lazy(() => import("@/pages/dashboard"));
const Stations = lazy(() => import("@/pages/stations"));
const Wallet = lazy(() => import("@/pages/wallet"));
const Vehicles = lazy(() => import("@/pages/vehicles"));
const Fuel = lazy(() => import("@/pages/fuel"));
const Transactions = lazy(() => import("@/pages/transactions"));
const Reports = lazy(() => import("@/pages/reports"));
const Support = lazy(() => import("@/pages/support"));
const Notifications = lazy(() => import("@/pages/notifications"));
const Fleet = lazy(() => import("@/pages/fleet"));
const Invoices = lazy(() => import("@/pages/invoices"));
const Settlements = lazy(() => import("@/pages/settlements"));
const StationDashboard = lazy(() => import("@/pages/station-dashboard"));

const queryClient = new QueryClient();
const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");

const clerkPubKey = import.meta.env.VITE_CLERK_PUBLISHABLE_KEY as string;
const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL as string | undefined;

function stripBase(path: string): string {
  return basePath && path.startsWith(basePath) ? path.slice(basePath.length) || "/" : path;
}

const clerkAppearance = {
  theme: shadcn,
  cssLayerName: "clerk",
  options: {
    logoPlacement: "inside" as const,
    logoLinkUrl: basePath || "/",
    logoImageUrl: `${window.location.origin}${basePath}/logo.svg`,
    socialButtonsPlacement: "bottom" as const,
  },
  variables: {
    colorPrimary: "#F5A623",
    colorForeground: "#0F172A",
    colorMutedForeground: "#64748B",
    colorDanger: "#EF4444",
    colorBackground: "#F9FAFB",
    colorInput: "#E2E8F0",
    colorInputForeground: "#0F172A",
    colorNeutral: "#CBD5E1",
    fontFamily: "'Plus Jakarta Sans', 'IBM Plex Sans Arabic', sans-serif",
    borderRadius: "0.75rem",
  },
  elements: {
    rootBox: "w-full flex justify-center",
    cardBox: "bg-white rounded-2xl w-[440px] max-w-full overflow-hidden shadow-xl",
    card: "!shadow-none !border-0 !bg-transparent !rounded-none",
    footer: "!shadow-none !border-0 !bg-transparent !rounded-none",
    headerTitle: "text-foreground font-bold",
    headerSubtitle: "text-muted-foreground",
    socialButtonsBlockButtonText: "text-foreground font-medium",
    formFieldLabel: "text-foreground font-medium",
    footerActionLink: "text-primary font-semibold hover:text-primary/80",
    footerActionText: "text-muted-foreground",
    dividerText: "text-muted-foreground",
    identityPreviewEditButton: "text-primary",
    formFieldSuccessText: "text-green-600",
    alertText: "text-foreground",
    logoBox: "flex justify-center py-2",
    logoImage: "h-10",
    socialButtonsBlockButton: "border border-border",
    formButtonPrimary: "bg-primary hover:bg-primary/90 text-primary-foreground font-semibold",
    formFieldInput: "bg-white border border-border text-foreground",
    footerAction: "bg-secondary/50",
    dividerLine: "bg-border",
    alert: "bg-destructive/10 border-destructive/20",
    otpCodeFieldInput: "border border-border bg-white text-foreground",
    formFieldRow: "",
    main: "",
  },
};

function SignInPage() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <SignIn routing="path" path={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`} fallbackRedirectUrl={`${basePath}/`} appearance={clerkAppearance} />
    </div>
  );
}

function SignUpPage() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <SignUp routing="path" path={`${basePath}/sign-up`} signInUrl={`${basePath}/sign-in`} fallbackRedirectUrl={`${basePath}/`} appearance={clerkAppearance} />
    </div>
  );
}

function HomeRoute() {
  return (
    <>
      <Show when="signed-in">
        <AppShell>
          <Suspense fallback={<DashboardSkeleton />}>
            <Dashboard />
          </Suspense>
        </AppShell>
      </Show>
      <Show when="signed-out">
        <Landing />
      </Show>
    </>
  );
}

function ProtectedRoute({ component: Component }: { component: React.ComponentType }) {
  return (
    <>
      <Show when="signed-in">
        <AppShell>
          <Suspense fallback={<DashboardSkeleton />}>
            <Component />
          </Suspense>
        </AppShell>
      </Show>
      <Show when="signed-out">
        <Redirect to="/sign-in" />
      </Show>
    </>
  );
}

function ClerkQueryInvalidator() {
  const { addListener } = useClerk();
  const qc = useQueryClient();
  const prev = useRef<string | null | undefined>(undefined);
  useEffect(() => {
    const unsub = addListener(({ user }) => {
      const id = user?.id ?? null;
      if (prev.current !== undefined && prev.current !== id) qc.clear();
      prev.current = id;
    });
    return unsub;
  }, [addListener, qc]);
  return null;
}

function ClerkRouter() {
  const [, setLocation] = useLocation();
  return (
    <ClerkProvider
      publishableKey={clerkPubKey!}
      proxyUrl={clerkProxyUrl}
      appearance={clerkAppearance}
      signInUrl={`${basePath}/sign-in`}
      signUpUrl={`${basePath}/sign-up`}
      localization={{
        signIn: { start: { title: "Welcome to FuelFlow", subtitle: "Sign in to access your account" } },
        signUp: { start: { title: "Create your account", subtitle: "Join Egypt's smart fuel network" } },
      }}
      routerPush={(to) => setLocation(stripBase(to))}
      routerReplace={(to) => setLocation(stripBase(to), { replace: true })}
    >
      <QueryClientProvider client={queryClient}>
        <ClerkQueryInvalidator />
        <TooltipProvider>
          <Switch>
            <Route path="/" component={HomeRoute} />
            <Route path="/sign-in/*?" component={SignInPage} />
            <Route path="/sign-up/*?" component={SignUpPage} />
            <Route path="/stations" component={() => <ProtectedRoute component={Stations} />} />
            <Route path="/wallet" component={() => <ProtectedRoute component={Wallet} />} />
            <Route path="/vehicles" component={() => <ProtectedRoute component={Vehicles} />} />
            <Route path="/fuel" component={() => <ProtectedRoute component={Fuel} />} />
            <Route path="/transactions" component={() => <ProtectedRoute component={Transactions} />} />
            <Route path="/reports" component={() => <ProtectedRoute component={Reports} />} />
            <Route path="/support" component={() => <ProtectedRoute component={Support} />} />
            <Route path="/notifications" component={() => <ProtectedRoute component={Notifications} />} />
            <Route path="/fleet" component={() => <ProtectedRoute component={Fleet} />} />
            <Route path="/invoices" component={() => <ProtectedRoute component={Invoices} />} />
            <Route path="/settlements" component={() => <ProtectedRoute component={Settlements} />} />
            <Route path="/station-dashboard" component={() => <ProtectedRoute component={StationDashboard} />} />
            <Route component={NotFound} />
          </Switch>
          <Toaster />
        </TooltipProvider>
      </QueryClientProvider>
    </ClerkProvider>
  );
}

function App() {
  return (
    <LanguageProvider>
      <WouterRouter base={basePath}>
        <ClerkRouter />
      </WouterRouter>
    </LanguageProvider>
  );
}

export default App;
