import { Link, useLocation } from "wouter";
import { useUser } from "@clerk/react";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
} from "@/components/ui/sidebar";
import {
  LayoutDashboard,
  MapPin,
  Wallet,
  Car,
  Fuel,
  Receipt,
  BarChart3,
  LifeBuoy,
  Bell,
  Building2,
  FileText,
  Banknote,
  TrendingUp,
} from "lucide-react";
import { TopBar } from "./top-bar";
import { useLanguage } from "@/lib/i18n";
import type { TranslationKey } from "@/lib/translations";

const mainNavItems: Array<{ titleKey: TranslationKey; url: string; icon: typeof Car }> = [
  { titleKey: "nav.dashboard", url: "/", icon: LayoutDashboard },
  { titleKey: "nav.stations", url: "/stations", icon: MapPin },
  { titleKey: "nav.wallet", url: "/wallet", icon: Wallet },
  { titleKey: "nav.vehicles", url: "/vehicles", icon: Car },
  { titleKey: "nav.fuel", url: "/fuel", icon: Fuel },
  { titleKey: "nav.transactions", url: "/transactions", icon: Receipt },
  { titleKey: "nav.reports", url: "/reports", icon: BarChart3 },
  { titleKey: "nav.invoices", url: "/invoices", icon: FileText },
  { titleKey: "nav.settlements", url: "/settlements", icon: Banknote },
  { titleKey: "nav.stationDashboard", url: "/station-dashboard", icon: TrendingUp },
];

const secondaryNavItems: Array<{ titleKey: TranslationKey; url: string; icon: typeof Car }> = [
  { titleKey: "nav.support", url: "/support", icon: LifeBuoy },
  { titleKey: "nav.notifications", url: "/notifications", icon: Bell },
  { titleKey: "nav.fleet", url: "/fleet", icon: Building2 },
];

export function AppShell({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const { t, dir } = useLanguage();
  const side = dir === "rtl" ? "right" : "left";
  const { user } = useUser();
  const displayName = user?.fullName || user?.firstName || t("user.name");
  const initials = displayName.split(" ").map((w: string) => w[0]).join("").slice(0, 2).toUpperCase();

  return (
    <SidebarProvider>
      <div className="flex min-h-screen w-full bg-background">
        <Sidebar side={side} className="border-sidebar-border">
          <SidebarHeader className="h-16 flex items-center justify-start px-6 border-b border-sidebar-border">
            <div className="flex items-center gap-2 text-sidebar-primary font-bold text-xl tracking-tight">
              <Fuel className="h-6 w-6" />
              <span>FuelFlow</span>
            </div>
          </SidebarHeader>
          <SidebarContent>
            <SidebarGroup>
              <SidebarGroupLabel>{t("nav.menu")}</SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu>
                  {mainNavItems.map((item) => (
                    <SidebarMenuItem key={item.titleKey}>
                      <SidebarMenuButton
                        asChild
                        isActive={location === item.url}
                        tooltip={t(item.titleKey)}
                      >
                        <Link href={item.url} className="flex items-center gap-3">
                          <item.icon className="h-4 w-4" />
                          <span>{t(item.titleKey)}</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>
            <SidebarGroup>
              <SidebarGroupLabel>{t("nav.more")}</SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu>
                  {secondaryNavItems.map((item) => (
                    <SidebarMenuItem key={item.titleKey}>
                      <SidebarMenuButton
                        asChild
                        isActive={location === item.url}
                        tooltip={t(item.titleKey)}
                      >
                        <Link href={item.url} className="flex items-center gap-3">
                          <item.icon className="h-4 w-4" />
                          <span>{t(item.titleKey)}</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>
          </SidebarContent>
          <SidebarFooter className="p-4 border-t border-sidebar-border">
            <div className="flex items-center gap-3 px-2">
              <div className="h-8 w-8 rounded-full bg-sidebar-primary text-sidebar-primary-foreground flex items-center justify-center font-bold text-sm overflow-hidden shrink-0">
                {user?.imageUrl ? (
                  <img src={user.imageUrl} alt={displayName} className="w-full h-full object-cover" />
                ) : (
                  initials
                )}
              </div>
              <div className="flex flex-col min-w-0">
                <span className="text-sm font-medium truncate">{displayName}</span>
                <span className="text-xs text-sidebar-foreground/70 truncate">{user?.primaryEmailAddress?.emailAddress || t("user.role")}</span>
              </div>
            </div>
          </SidebarFooter>
        </Sidebar>
        <div className="flex-1 flex flex-col min-w-0">
          <TopBar />
          <main className="flex-1 overflow-auto p-4 md:p-6 lg:p-8">
            {children}
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}
