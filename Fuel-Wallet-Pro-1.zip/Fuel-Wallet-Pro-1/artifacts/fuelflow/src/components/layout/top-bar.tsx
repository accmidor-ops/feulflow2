import { Bell, Wallet, Check } from "lucide-react";
import { Link } from "wouter";
import { useGetWallet, useListNotifications } from "@workspace/api-client-react";
import { SidebarTrigger } from "@/components/ui/sidebar";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useLanguage } from "@/lib/i18n";

export function TopBar() {
  const { data: wallet } = useGetWallet();
  const { data: notifications } = useListNotifications();
  const { language, setLanguage, formatCurrency } = useLanguage();

  const unreadCount = notifications?.filter((n) => !n.isRead).length || 0;

  return (
    <header className="h-16 flex items-center justify-between px-4 md:px-6 border-b border-border bg-card/50 backdrop-blur supports-[backdrop-filter]:bg-card/50 sticky top-0 z-10">
      <div className="flex items-center gap-4">
        <SidebarTrigger className="md:hidden" />
      </div>

      <div className="flex items-center gap-3">
        {wallet && (
          <Link href="/wallet">
            <div className="flex items-center gap-2 bg-secondary text-secondary-foreground px-3 py-1.5 rounded-full text-sm font-medium hover:bg-secondary/80 transition-colors cursor-pointer">
              <Wallet className="h-4 w-4 text-primary" />
              <span>{formatCurrency(wallet.balance)}</span>
            </div>
          </Link>
        )}

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              variant="ghost"
              size="sm"
              className="rounded-full px-3 gap-2 font-medium"
            >
              <span className="text-sm">{language === "en" ? "EN" : "ع"}</span>
              <span className="sr-only">Switch language</span>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-40">
            <DropdownMenuItem
              className="flex items-center justify-between cursor-pointer"
              onClick={() => setLanguage("en")}
            >
              <span className="font-medium">English</span>
              {language === "en" && <Check className="h-4 w-4 text-primary" />}
            </DropdownMenuItem>
            <DropdownMenuItem
              className="flex items-center justify-between cursor-pointer"
              onClick={() => setLanguage("ar")}
              dir="rtl"
            >
              <span className="font-medium" style={{ fontFamily: "'IBM Plex Sans Arabic', sans-serif" }}>العربية</span>
              {language === "ar" && <Check className="h-4 w-4 text-primary" />}
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        <Link href="/notifications">
          <Button variant="ghost" size="icon" className="relative rounded-full">
            <Bell className="h-5 w-5" />
            {unreadCount > 0 && (
              <Badge
                variant="destructive"
                className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 text-[10px] rounded-full border-2 border-background"
              >
                {unreadCount > 9 ? "9+" : unreadCount}
              </Badge>
            )}
          </Button>
        </Link>
      </div>
    </header>
  );
}
