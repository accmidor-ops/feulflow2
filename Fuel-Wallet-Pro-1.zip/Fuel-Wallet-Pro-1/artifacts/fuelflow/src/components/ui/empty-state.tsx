import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { AlertCircle, FileQuestion, PlusCircle } from "lucide-react";

interface EmptyStateProps {
  title: string;
  description: string;
  icon?: React.ElementType;
  actionLabel?: string;
  actionHref?: string;
  actionOnClick?: () => void;
}

export function EmptyState({
  title,
  description,
  icon: Icon = FileQuestion,
  actionLabel,
  actionHref,
  actionOnClick,
}: EmptyStateProps) {
  return (
    <div className="flex flex-col items-center justify-center p-8 text-center min-h-[400px] border border-dashed rounded-lg bg-card/50">
      <div className="h-16 w-16 bg-muted rounded-full flex items-center justify-center mb-4">
        <Icon className="h-8 w-8 text-muted-foreground" />
      </div>
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      <p className="text-muted-foreground max-w-sm mb-6">{description}</p>
      
      {actionLabel && actionHref && (
        <Link href={actionHref}>
          <Button>
            <PlusCircle className="mr-2 h-4 w-4" />
            {actionLabel}
          </Button>
        </Link>
      )}
      
      {actionLabel && actionOnClick && (
        <Button onClick={actionOnClick}>
          <PlusCircle className="mr-2 h-4 w-4" />
          {actionLabel}
        </Button>
      )}
    </div>
  );
}

export function ErrorState({ title = "Something went wrong", description = "An error occurred while loading this data." }: { title?: string, description?: string }) {
  return (
    <div className="flex flex-col items-center justify-center p-8 text-center min-h-[300px] border border-destructive/20 bg-destructive/5 rounded-lg">
      <AlertCircle className="h-10 w-10 text-destructive mb-4" />
      <h3 className="text-lg font-semibold text-destructive mb-2">{title}</h3>
      <p className="text-muted-foreground">{description}</p>
      <Button variant="outline" className="mt-4" onClick={() => window.location.reload()}>
        Refresh Page
      </Button>
    </div>
  );
}
