import { useState } from "react";
import { useListTransactions, useListVehicles, useGetWallet } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { FileText, Download, CheckCircle, Building2 } from "lucide-react";
import { format } from "date-fns";
import { useLanguage } from "@/lib/i18n";
import { useToast } from "@/hooks/use-toast";

function generateInvoicePDF(invoice: any, transactions: any[], formatCurrency: (v: number, opts?: any) => string, formatNumber: (v: number, opts?: any) => string) {
  import("jspdf").then(({ default: jsPDF }) => {
    import("jspdf-autotable").then(() => {
      const doc = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });

      const W = 210;
      const AMBER = [245, 166, 35] as [number, number, number];
      const DARK = [15, 23, 42] as [number, number, number];
      const GRAY = [100, 116, 139] as [number, number, number];

      doc.setFillColor(...AMBER);
      doc.rect(0, 0, W, 40, "F");

      doc.setTextColor(255, 255, 255);
      doc.setFontSize(22);
      doc.setFont("helvetica", "bold");
      doc.text("FuelFlow Egypt", 14, 18);
      doc.setFontSize(10);
      doc.setFont("helvetica", "normal");
      doc.text("Smart Fuel Network", 14, 26);
      doc.text("Tax Registration No: 345-678-901", 14, 33);

      doc.setFontSize(28);
      doc.setFont("helvetica", "bold");
      doc.text("INVOICE", W - 14, 22, { align: "right" });
      doc.setFontSize(10);
      doc.setFont("helvetica", "normal");
      doc.text(`No: ${invoice.number}`, W - 14, 30, { align: "right" });
      doc.text(`Date: ${format(new Date(invoice.date), "dd/MM/yyyy")}`, W - 14, 37, { align: "right" });

      doc.setFillColor(...DARK);
      doc.rect(0, 40, W, 1, "F");

      doc.setTextColor(...DARK);
      doc.setFontSize(9);
      doc.setFont("helvetica", "bold");
      doc.text("BILL TO:", 14, 52);
      doc.setFont("helvetica", "normal");
      doc.text(invoice.buyerName, 14, 58);
      doc.text(invoice.buyerAddress || "Cairo, Egypt", 14, 63);
      if (invoice.buyerTaxId) {
        doc.text(`Tax ID: ${invoice.buyerTaxId}`, 14, 68);
      }

      doc.setFont("helvetica", "bold");
      doc.text("PAYMENT METHOD:", W / 2, 52);
      doc.setFont("helvetica", "normal");
      doc.text("FuelFlow Digital Wallet", W / 2, 58);
      doc.text("Currency: Egyptian Pound (EGP)", W / 2, 63);

      const uuid = `FF-${Date.now().toString(36).toUpperCase()}-EGY`;
      doc.setTextColor(...GRAY);
      doc.setFontSize(8);
      doc.text(`Invoice UUID: ${uuid}`, 14, 80);

      (doc as any).autoTable({
        startY: 86,
        head: [["#", "Description", "Liters", "Price/L (EGP)", "Amount (EGP)"]],
        body: transactions.map((tx: any, i: number) => [
          i + 1,
          `${tx.fuelType === "gasoline_91" ? "Gasoline 80" : tx.fuelType === "gasoline_95" ? "Gasoline 92" : "Diesel"} — ${tx.stationName}`,
          `${formatNumber(tx.liters, { decimals: 2 })} L`,
          formatNumber(tx.pricePerLiter, { decimals: 2 }),
          formatNumber(tx.total, { decimals: 2 }),
        ]),
        headStyles: { fillColor: AMBER, textColor: DARK, fontStyle: "bold", fontSize: 9 },
        alternateRowStyles: { fillColor: [249, 250, 251] },
        styles: { fontSize: 8.5 },
        columnStyles: {
          0: { cellWidth: 10 },
          2: { halign: "right" },
          3: { halign: "right" },
          4: { halign: "right" },
        },
      });

      const finalY = (doc as any).lastAutoTable.finalY + 8;
      const subtotal = transactions.reduce((s: number, t: any) => s + t.total, 0);
      const vat = subtotal * 0.14;
      const total = subtotal + vat;

      doc.setDrawColor(...[214, 211, 208] as [number, number, number]);
      doc.line(120, finalY, W - 14, finalY);

      const rightX = W - 14;
      doc.setFontSize(9);
      doc.setTextColor(...DARK);
      doc.text("Subtotal:", 120, finalY + 8);
      doc.text(`EGP ${formatNumber(subtotal, { decimals: 2 })}`, rightX, finalY + 8, { align: "right" });

      doc.text("VAT (14%):", 120, finalY + 15);
      doc.text(`EGP ${formatNumber(vat, { decimals: 2 })}`, rightX, finalY + 15, { align: "right" });

      doc.setFillColor(...AMBER);
      doc.rect(110, finalY + 19, W - 110 - 4, 12, "F");
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(11);
      doc.setFont("helvetica", "bold");
      doc.text("Total:", 114, finalY + 27);
      doc.text(`EGP ${formatNumber(total, { decimals: 2 })}`, rightX, finalY + 27, { align: "right" });

      doc.setFontSize(8);
      doc.setFont("helvetica", "normal");
      doc.setTextColor(...GRAY);
      doc.text("This is an electronically generated invoice compliant with", 14, 270);
      doc.text("Egypt Tax Authority (ETA) e-invoicing standards.", 14, 275);
      doc.text(`FuelFlow Egypt | support@fuelflow.eg | Cairo, Egypt`, 14, 282);

      doc.save(`FuelFlow_Invoice_${invoice.number}.pdf`);
    });
  });
}

export default function Invoices() {
  const { data: transactions, isLoading } = useListTransactions();
  const { data: vehicles } = useListVehicles();
  const { data: wallet } = useGetWallet();
  const { t, formatCurrency, formatNumber } = useLanguage();
  const { toast } = useToast();

  const [selectedMonth, setSelectedMonth] = useState<string>("all");
  const [buyerName, setBuyerName] = useState(wallet?.cardHolder || "Ahmed Hassan");
  const [buyerAddress, setBuyerAddress] = useState("Cairo, Egypt");
  const [buyerTaxId, setBuyerTaxId] = useState("");

  const months = Array.from(
    new Set((transactions || []).map((tx) => format(new Date(tx.createdAt), "yyyy-MM")))
  ).sort().reverse();

  const filteredTx = selectedMonth === "all"
    ? transactions || []
    : (transactions || []).filter((tx) => format(new Date(tx.createdAt), "yyyy-MM") === selectedMonth);

  const totalAmount = filteredTx.reduce((s, t) => s + t.total, 0);
  const vatAmount = totalAmount * 0.14;

  const handleGeneratePDF = () => {
    if (!filteredTx.length) {
      toast({ title: t("invoices.noData"), variant: "destructive" });
      return;
    }
    const monthLabel = selectedMonth === "all" ? format(new Date(), "MMM-yyyy") : selectedMonth;
    generateInvoicePDF(
      {
        number: `FF-${monthLabel}-${Math.floor(Math.random() * 9000) + 1000}`,
        date: new Date().toISOString(),
        buyerName,
        buyerAddress,
        buyerTaxId,
      },
      filteredTx,
      formatCurrency,
      formatNumber,
    );
    toast({ title: t("invoices.toast.generated") });
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">{t("invoices.title")}</h1>
        <p className="text-muted-foreground">{t("invoices.subtitle")}</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Building2 className="h-5 w-5 text-primary" />
              {t("invoices.buyerInfo")}
            </CardTitle>
            <CardDescription>{t("invoices.buyerInfoDesc")}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>{t("invoices.field.buyerName")}</Label>
              <Input value={buyerName} onChange={(e) => setBuyerName(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>{t("invoices.field.buyerAddress")}</Label>
              <Input value={buyerAddress} onChange={(e) => setBuyerAddress(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>{t("invoices.field.buyerTaxId")}</Label>
              <Input value={buyerTaxId} onChange={(e) => setBuyerTaxId(e.target.value)} placeholder={t("invoices.field.taxIdPlaceholder")} />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5 text-primary" />
              {t("invoices.invoiceConfig")}
            </CardTitle>
            <CardDescription>{t("invoices.invoiceConfigDesc")}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>{t("invoices.field.period")}</Label>
              <Select value={selectedMonth} onValueChange={setSelectedMonth}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">{t("invoices.allTransactions")}</SelectItem>
                  {months.map((m) => (
                    <SelectItem key={m} value={m}>{format(new Date(m + "-01"), "MMMM yyyy")}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="rounded-lg border border-border bg-secondary/30 p-4 space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">{t("invoices.subtotal")}</span>
                <span className="font-medium">{formatCurrency(totalAmount)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">{t("invoices.vat14")}</span>
                <span className="font-medium">{formatCurrency(vatAmount)}</span>
              </div>
              <div className="flex justify-between font-bold text-base pt-1 border-t border-border">
                <span>{t("invoices.total")}</span>
                <span className="text-primary">{formatCurrency(totalAmount + vatAmount)}</span>
              </div>
              <div className="pt-1">
                <Badge variant="outline" className="text-xs">
                  {filteredTx.length} {t("invoices.txCount")}
                </Badge>
              </div>
            </div>

            <Button className="w-full" onClick={handleGeneratePDF} disabled={isLoading || filteredTx.length === 0}>
              <Download className="me-2 h-4 w-4" />
              {t("invoices.generatePDF")}
            </Button>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CheckCircle className="h-5 w-5 text-green-500" />
            {t("invoices.etaCompliance")}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              t("invoices.compliance.uuid"),
              t("invoices.compliance.vat"),
              t("invoices.compliance.seller"),
              t("invoices.compliance.lineItems"),
            ].map((item) => (
              <div key={item} className="flex items-center gap-2 text-sm">
                <CheckCircle className="h-4 w-4 text-green-500 shrink-0" />
                <span>{item}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {isLoading ? (
        <p className="text-center text-muted-foreground">{t("common.loading")}</p>
      ) : filteredTx.length > 0 ? (
        <Card>
          <CardHeader>
            <CardTitle>{t("invoices.lineItems")}</CardTitle>
            <CardDescription>{t("invoices.lineItemsDesc", { count: filteredTx.length })}</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {filteredTx.slice(0, 10).map((tx) => (
                <div key={tx.id} className="flex items-center justify-between py-2 border-b last:border-0">
                  <div>
                    <p className="text-sm font-medium">{tx.stationName}</p>
                    <p className="text-xs text-muted-foreground">
                      {format(new Date(tx.createdAt), "dd MMM yyyy")} • {formatNumber(tx.liters, { decimals: 1 })} L
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-bold">{formatCurrency(tx.total)}</p>
                    <p className="text-xs text-muted-foreground">+VAT {formatCurrency(tx.total * 0.14)}</p>
                  </div>
                </div>
              ))}
              {filteredTx.length > 10 && (
                <p className="text-center text-sm text-muted-foreground pt-2">
                  {t("invoices.moreItems", { count: filteredTx.length - 10 })}
                </p>
              )}
            </div>
          </CardContent>
        </Card>
      ) : null}
    </div>
  );
}
