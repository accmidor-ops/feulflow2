import { useGetMonthlyReport, useGetYearlyReport, useListTransactions } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BarChart, Bar, LineChart, Line, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";
import { DashboardSkeleton } from "@/components/ui/loading-skeleton";
import { ErrorState } from "@/components/ui/empty-state";
import { Download, TrendingUp, TrendingDown, FileText } from "lucide-react";
import { Button } from "@/components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { useLanguage } from "@/lib/i18n";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";

function exportToExcel(monthlyData: any[], yearlyData: any[], formatCurrency: (v: number) => string) {
  import("xlsx").then((XLSX) => {
    const wb = XLSX.utils.book_new();

    const monthlyRows = [
      ["Month", "Spent (EGP)", "Liters", "Transactions"],
      ...(monthlyData || []).map((r: any) => [r.month, r.spent, r.liters, r.transactionCount]),
    ];
    const wsMonthly = XLSX.utils.aoa_to_sheet(monthlyRows);
    XLSX.utils.book_append_sheet(wb, wsMonthly, "Monthly Trends");

    const yearlyRows = [
      ["Year", "Spent (EGP)", "Liters"],
      ...(yearlyData || []).map((r: any) => [r.year, r.spent, r.liters]),
    ];
    const wsYearly = XLSX.utils.aoa_to_sheet(yearlyRows);
    XLSX.utils.book_append_sheet(wb, wsYearly, "Yearly Overview");

    XLSX.writeFile(wb, `FuelFlow_Report_${format(new Date(), "yyyy-MM-dd")}.xlsx`);
  });
}

function exportToPDF(monthlyData: any[], formatCurrency: (v: number) => string, formatNumber: (v: number, opts?: any) => string) {
  import("jspdf").then(({ default: jsPDF }) => {
    import("jspdf-autotable").then(() => {
      const doc = new jsPDF();

      doc.setFillColor(245, 166, 35);
      doc.rect(0, 0, 210, 25, "F");
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(18);
      doc.setFont("helvetica", "bold");
      doc.text("FuelFlow Egypt", 14, 12);
      doc.setFontSize(10);
      doc.setFont("helvetica", "normal");
      doc.text("Monthly Consumption Report", 14, 19);
      doc.text(`Generated: ${format(new Date(), "dd MMM yyyy")}`, 150, 19);

      doc.setTextColor(0, 0, 0);
      doc.setFontSize(13);
      doc.setFont("helvetica", "bold");
      doc.text("Monthly Breakdown", 14, 38);

      const totalSpent = (monthlyData || []).reduce((a: number, r: any) => a + r.spent, 0);
      const totalLiters = (monthlyData || []).reduce((a: number, r: any) => a + r.liters, 0);

      doc.setFontSize(10);
      doc.setFont("helvetica", "normal");
      doc.setTextColor(100, 116, 139);
      doc.text(`Total Spent: EGP ${formatNumber(totalSpent, { decimals: 2 })}   |   Total Volume: ${formatNumber(totalLiters, { decimals: 1 })} L`, 14, 46);

      (doc as any).autoTable({
        startY: 52,
        head: [["Month", "Spent (EGP)", "Liters", "Transactions", "Avg Price/L"]],
        body: (monthlyData || []).map((r: any) => [
          r.month,
          `EGP ${formatNumber(r.spent, { decimals: 2 })}`,
          `${formatNumber(r.liters, { decimals: 1 })} L`,
          r.transactionCount,
          r.liters > 0 ? `EGP ${formatNumber(r.spent / r.liters, { decimals: 2 })}` : "-",
        ]),
        headStyles: { fillColor: [245, 166, 35], textColor: 15, fontStyle: "bold" },
        alternateRowStyles: { fillColor: [249, 250, 251] },
        styles: { fontSize: 9 },
      });

      const pageCount = (doc as any).internal.getNumberOfPages();
      for (let i = 1; i <= pageCount; i++) {
        doc.setPage(i);
        doc.setFontSize(8);
        doc.setTextColor(150);
        doc.text(`Page ${i} of ${pageCount}`, 105, 290, { align: "center" });
        doc.text("FuelFlow Egypt — Confidential", 14, 290);
      }

      doc.save(`FuelFlow_Report_${format(new Date(), "yyyy-MM-dd")}.pdf`);
    });
  });
}

export default function Reports() {
  const { data: monthlyData, isLoading: isLoadingMonthly, isError: isErrorMonthly } = useGetMonthlyReport();
  const { data: yearlyData, isLoading: isLoadingYearly, isError: isErrorYearly } = useGetYearlyReport();
  const { t, formatCurrency, formatNumber } = useLanguage();
  const { toast } = useToast();

  if (isLoadingMonthly || isLoadingYearly) return <DashboardSkeleton />;
  if (isErrorMonthly || isErrorYearly) return <ErrorState title={t("error.reports")} />;

  const formatCurrencyShort = (val: number) => formatCurrency(val, { decimals: 0 });
  const formatLiters = (val: number) => `${formatNumber(val, { decimals: 0 })} L`;

  const totalSpentMonthly = monthlyData?.reduce((acc, curr) => acc + curr.spent, 0) || 0;
  const totalLitersMonthly = monthlyData?.reduce((acc, curr) => acc + curr.liters, 0) || 0;

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-popover border border-border p-3 rounded-lg shadow-md">
          <p className="font-medium mb-2">{label}</p>
          {payload.map((entry: any, index: number) => (
            <p key={index} className="text-sm flex items-center gap-2">
              <span className="w-3 h-3 rounded-full" style={{ backgroundColor: entry.color }} />
              <span className="text-muted-foreground">{entry.name}:</span>
              <span className="font-medium">
                {entry.dataKey === "spent" ? formatCurrencyShort(entry.value) : formatLiters(entry.value)}
              </span>
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">{t("reports.title")}</h1>
          <p className="text-muted-foreground">{t("reports.subtitle")}</p>
        </div>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline">
              <Download className="me-2 h-4 w-4" /> {t("reports.export")}
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem
              onClick={() => {
                exportToExcel(monthlyData || [], yearlyData || [], formatCurrency);
                toast({ title: t("reports.toast.excel") });
              }}
            >
              <FileText className="me-2 h-4 w-4 text-green-600" />
              {t("reports.exportExcel")}
            </DropdownMenuItem>
            <DropdownMenuItem
              onClick={() => {
                exportToPDF(monthlyData || [], formatCurrency, formatNumber);
                toast({ title: t("reports.toast.pdf") });
              }}
            >
              <FileText className="me-2 h-4 w-4 text-red-500" />
              {t("reports.exportPDF")}
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground uppercase tracking-wider">{t("reports.totalSpentYear")}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-end justify-between">
              <div className="text-3xl font-bold tracking-tight">{formatCurrency(totalSpentMonthly)}</div>
              <div className="flex items-center text-green-500 text-sm font-medium">
                <TrendingDown className="h-4 w-4 me-1" />
                {t("reports.vsLastYearDown", { percent: "4.2" })}
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground uppercase tracking-wider">{t("reports.totalVolumeYear")}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-end justify-between">
              <div className="text-3xl font-bold tracking-tight">{formatNumber(totalLitersMonthly, { decimals: 1 })} L</div>
              <div className="flex items-center text-red-500 text-sm font-medium">
                <TrendingUp className="h-4 w-4 me-1" />
                {t("reports.vsLastYearUp", { percent: "2.1" })}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="monthly" className="space-y-6">
        <TabsList>
          <TabsTrigger value="monthly">{t("reports.tab.monthly")}</TabsTrigger>
          <TabsTrigger value="yearly">{t("reports.tab.yearly")}</TabsTrigger>
        </TabsList>

        <TabsContent value="monthly" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>{t("reports.monthlySpending")}</CardTitle>
              <CardDescription>{t("reports.monthlySpendingDesc")}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[350px] w-full mt-4">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={monthlyData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border))" />
                    <XAxis dataKey="month" tickLine={false} axisLine={false} />
                    <YAxis yAxisId="left" orientation="left" tickFormatter={formatCurrencyShort} tickLine={false} axisLine={false} />
                    <YAxis yAxisId="right" orientation="right" tickFormatter={formatLiters} tickLine={false} axisLine={false} />
                    <Tooltip content={<CustomTooltip />} />
                    <Legend />
                    <Bar yAxisId="left" dataKey="spent" name={t("reports.spent")} fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                    <Bar yAxisId="right" dataKey="liters" name={t("reports.volume")} fill="hsl(var(--chart-2))" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>{t("reports.transactionVolume")}</CardTitle>
              <CardDescription>{t("reports.transactionVolumeDesc")}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[300px] w-full mt-4">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={monthlyData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border))" />
                    <XAxis dataKey="month" tickLine={false} axisLine={false} />
                    <YAxis tickLine={false} axisLine={false} />
                    <Tooltip contentStyle={{ borderRadius: "8px" }} />
                    <Line type="monotone" dataKey="transactionCount" name={t("reports.transactions")} stroke="hsl(var(--chart-3))" strokeWidth={3} dot={{ r: 4 }} activeDot={{ r: 6 }} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="yearly" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>{t("reports.historicalSpending")}</CardTitle>
              <CardDescription>{t("reports.yoy")}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[400px] w-full mt-4">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={yearlyData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                    <defs>
                      <linearGradient id="colorSpentYear" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border))" />
                    <XAxis dataKey="year" tickLine={false} axisLine={false} />
                    <YAxis tickFormatter={formatCurrencyShort} tickLine={false} axisLine={false} />
                    <Tooltip content={<CustomTooltip />} />
                    <Area type="monotone" dataKey="spent" name={t("reports.spent")} stroke="hsl(var(--primary))" fillOpacity={1} fill="url(#colorSpentYear)" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
