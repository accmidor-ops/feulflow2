import { useListNotifications, useMarkNotificationRead, getListNotificationsQueryKey } from "@workspace/api-client-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useQueryClient } from "@tanstack/react-query";
import { Bell, Tag, Info, AlertTriangle, CreditCard, CheckCircle2 } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { ListSkeleton } from "@/components/ui/loading-skeleton";
import { ErrorState, EmptyState } from "@/components/ui/empty-state";
import { useLanguage } from "@/lib/i18n";

export default function Notifications() {
  const { data: notifications, isLoading, isError } = useListNotifications();
  const queryClient = useQueryClient();
  const { t, dateLocale } = useLanguage();

  const markReadMutation = useMarkNotificationRead({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListNotificationsQueryKey() });
      }
    }
  });

  const handleMarkRead = (id: number) => {
    markReadMutation.mutate({ id });
  };

  const getIcon = (type: string) => {
    switch (type) {
      case 'promotion': return <Tag className="h-5 w-5 text-purple-500" />;
      case 'charge': return <CreditCard className="h-5 w-5 text-blue-500" />;
      case 'alert': return <AlertTriangle className="h-5 w-5 text-destructive" />;
      default: return <Info className="h-5 w-5 text-primary" />;
    }
  };

  if (isLoading) return <ListSkeleton />;
  if (isError) return <ErrorState title={t("error.notifications")} />;

  const unreadCount = notifications?.filter(n => !n.isRead).length || 0;

  return (
    <div className="space-y-6 max-w-3xl mx-auto">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">{t("notifications.title")}</h1>
          <p className="text-muted-foreground">{t("notifications.subtitle")}</p>
        </div>
        {unreadCount > 0 && (
          <Badge variant="secondary" className="px-3 py-1 text-sm rounded-full">
            {t("notifications.unread", { count: unreadCount })}
          </Badge>
        )}
      </div>

      {!notifications || notifications.length === 0 ? (
        <EmptyState
          title={t("notifications.empty.title")}
          description={t("notifications.empty.desc")}
          icon={Bell}
        />
      ) : (
        <div className="space-y-3">
          {notifications.map((notification) => (
            <Card
              key={notification.id}
              className={`transition-all duration-300 ${!notification.isRead ? 'bg-primary/5 border-primary/20 shadow-sm' : 'opacity-80'}`}
            >
              <CardContent className="p-4 sm:p-6 flex gap-4">
                <div className={`mt-1 shrink-0 h-10 w-10 rounded-full flex items-center justify-center ${!notification.isRead ? 'bg-background shadow-sm' : 'bg-secondary'}`}>
                  {getIcon(notification.type)}
                </div>
                <div className="flex-1 space-y-1">
                  <div className="flex items-start justify-between gap-2">
                    <h3 className={`font-medium ${!notification.isRead ? 'text-foreground' : 'text-muted-foreground'}`}>
                      {notification.title}
                    </h3>
                    <span className="text-xs text-muted-foreground whitespace-nowrap">
                      {formatDistanceToNow(new Date(notification.createdAt), { addSuffix: true, locale: dateLocale })}
                    </span>
                  </div>
                  <p className={`text-sm ${!notification.isRead ? 'text-foreground/90' : 'text-muted-foreground'}`}>
                    {notification.message}
                  </p>

                  {!notification.isRead && (
                    <div className="pt-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-8 px-2 -ms-2 text-primary hover:text-primary hover:bg-primary/10"
                        onClick={() => handleMarkRead(notification.id)}
                        disabled={markReadMutation.isPending}
                      >
                        <CheckCircle2 className="h-4 w-4 me-1.5" /> {t("common.markAsRead")}
                      </Button>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
