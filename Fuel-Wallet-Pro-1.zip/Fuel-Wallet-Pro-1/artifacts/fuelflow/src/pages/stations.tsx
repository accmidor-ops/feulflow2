/// <reference types="google.maps" />
import { useState, useMemo, useEffect, useRef, useCallback, Component, type ReactNode } from "react";
import { useListStations } from "@workspace/api-client-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  MapPin,
  Navigation,
  Star,
  Search,
  Clock,
  Crosshair,
  Fuel as FuelIcon,
  AlertCircle,
  Loader2,
  Maximize2,
  X,
} from "lucide-react";
import {
  APIProvider,
  Map,
  AdvancedMarker,
  Pin,
  useMap,
  useMapsLibrary,
} from "@vis.gl/react-google-maps";
import { MarkerClusterer } from "@googlemaps/markerclusterer";
import { motion, AnimatePresence } from "framer-motion";
import { useLanguage } from "@/lib/i18n";

const API_KEY = import.meta.env.VITE_GOOGLE_MAPS_API_KEY as string | undefined;
const DEFAULT_CENTER = { lat: 30.0444, lng: 31.2357 }; // Cairo
const NEARBY_RADIUS_KM = 10;

type FilterMode = "all" | "nearby" | "open";
type FuelTypeFilter = "all" | "gasoline_91" | "gasoline_95" | "diesel";

export default function Stations() {
  const { data: stations, isLoading } = useListStations();
  const { t, formatCurrency, formatNumber, language } = useLanguage();

  const [searchQuery, setSearchQuery] = useState("");
  const [filterMode, setFilterMode] = useState<FilterMode>("all");
  const [fuelFilter, setFuelFilter] = useState<FuelTypeFilter>("all");
  const [selectedStationId, setSelectedStationId] = useState<number | null>(null);
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [locationError, setLocationError] = useState<string | null>(null);
  const [isLocating, setIsLocating] = useState(false);
  const [mapCenter, setMapCenter] = useState(DEFAULT_CENTER);

  const filteredStations = useMemo(() => {
    if (!stations) return [];
    const q = searchQuery.toLowerCase().trim();
    return stations.filter((s) => {
      if (q && !`${s.name} ${s.address} ${s.city}`.toLowerCase().includes(q)) return false;
      if (filterMode === "nearby" && s.distanceKm > NEARBY_RADIUS_KM) return false;
      if (filterMode === "open" && !s.isOpen) return false;
      if (fuelFilter !== "all" && !s.fuelTypes.includes(fuelFilter)) return false;
      return true;
    });
  }, [stations, searchQuery, filterMode, fuelFilter]);

  const selectedStation = stations?.find((s) => s.id === selectedStationId);

  // Hold the live Google Map instance so FABs / camera control can drive it imperatively
  const [mapInstance, setMapInstance] = useState<google.maps.Map | null>(null);

  // Smooth pan + zoom when a station is selected; gentle zoom-out on deselect
  useEffect(() => {
    if (!mapInstance) return;
    if (selectedStation) {
      mapInstance.panTo({ lat: selectedStation.lat, lng: selectedStation.lng });
      const currentZoom = mapInstance.getZoom() ?? 12;
      if (currentZoom < 15) mapInstance.setZoom(15);
    }
  }, [mapInstance, selectedStation]);

  // Pan map when external center (autocomplete, "use my location") changes
  useEffect(() => {
    if (mapInstance) mapInstance.panTo(mapCenter);
  }, [mapInstance, mapCenter]);

  // Fit all currently filtered stations into view
  const fitAllStations = useCallback(() => {
    if (!mapInstance || filteredStations.length === 0) return;
    const bounds = new google.maps.LatLngBounds();
    filteredStations.forEach((s) => bounds.extend({ lat: s.lat, lng: s.lng }));
    if (userLocation) bounds.extend(userLocation);
    mapInstance.fitBounds(bounds, 80);
    setSelectedStationId(null);
  }, [mapInstance, filteredStations, userLocation]);

  const handleUseMyLocation = () => {
    if (!navigator.geolocation) {
      setLocationError(t("stations.locationDenied"));
      return;
    }
    setIsLocating(true);
    setLocationError(null);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const loc = { lat: pos.coords.latitude, lng: pos.coords.longitude };
        setUserLocation(loc);
        setMapCenter(loc);
        setIsLocating(false);
      },
      () => {
        setLocationError(t("stations.locationDenied"));
        setIsLocating(false);
      },
      { enableHighAccuracy: true, timeout: 8000 }
    );
  };

  const openDirections = (lat: number, lng: number) => {
    const origin = userLocation ? `${userLocation.lat},${userLocation.lng}` : "";
    const url = `https://www.google.com/maps/dir/?api=1${origin ? `&origin=${origin}` : ""}&destination=${lat},${lng}`;
    window.open(url, "_blank", "noopener,noreferrer");
  };

  // Track Google Maps auth/billing failures via the official global hook.
  // Set BEFORE the Maps script loads so it catches the failure on first load.
  const [mapsAuthFailed, setMapsAuthFailed] = useState(false);
  useEffect(() => {
    (window as any).gm_authFailure = () => setMapsAuthFailed(true);
    return () => {
      if ((window as any).gm_authFailure?.toString().includes("setMapsAuthFailed")) {
        delete (window as any).gm_authFailure;
      }
    };
  }, []);

  return (
    <div className="flex flex-col h-[calc(100vh-8rem)]">
      {/* Header */}
      <div className="mb-4 flex items-start gap-3">
        <div className="rounded-2xl bg-gradient-to-br from-amber-500/20 to-amber-600/10 p-3 ring-1 ring-amber-500/30">
          <MapPin className="h-6 w-6 text-amber-400" />
        </div>
        <div className="flex-1">
          <h1 className="text-3xl font-bold tracking-tight">{t("stations.title")}</h1>
          <p className="text-muted-foreground text-sm mt-0.5">{t("stations.subtitle")}</p>
        </div>
      </div>

      <div className="flex flex-col lg:flex-row gap-6 flex-1 min-h-0">
        {/* ─────────── Left: Search + Filters + List ─────────── */}
        <div className="w-full lg:w-[380px] flex flex-col gap-3 min-h-0">
          {/* Search */}
          <div className="relative">
            <Search className="absolute start-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none" />
            <Input
              placeholder={t("stations.searchPlaceholder")}
              className="ps-9 h-11 rounded-xl bg-white/5 border-white/10"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>

          {/* Address autocomplete (recenters the map) — uses modern PlaceAutocompleteElement */}
          {API_KEY && (
            <APIProvider apiKey={API_KEY} libraries={["places"]}>
              <MapsErrorBoundary fallback={null}>
                <PlacesAutocompleteInput
                  onPlaceSelect={(loc) => {
                    setMapCenter(loc);
                    setSelectedStationId(null);
                  }}
                  placeholder={t("stations.searchAddress")}
                  language={language}
                />
              </MapsErrorBoundary>
            </APIProvider>
          )}

          {/* Filter chips */}
          <div className="flex flex-wrap gap-2">
            <FilterChip active={filterMode === "all"} onClick={() => setFilterMode("all")}>
              {t("stations.filter.all")}
            </FilterChip>
            <FilterChip active={filterMode === "nearby"} onClick={() => setFilterMode("nearby")}>
              {t("stations.filter.nearby")}
            </FilterChip>
            <FilterChip active={filterMode === "open"} onClick={() => setFilterMode("open")}>
              {t("stations.filter.open")}
            </FilterChip>
            <button
              onClick={handleUseMyLocation}
              disabled={isLocating}
              className="ms-auto inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-medium bg-amber-500/10 text-amber-400 border border-amber-500/30 hover:bg-amber-500/20 transition-colors disabled:opacity-50"
            >
              {isLocating ? <Loader2 className="h-3 w-3 animate-spin" /> : <Crosshair className="h-3 w-3" />}
              {t("stations.useMyLocation")}
            </button>
          </div>

          {/* Fuel-type filter pills */}
          <div className="flex flex-wrap gap-1.5">
            {(["all", "gasoline_91", "gasoline_95", "diesel"] as FuelTypeFilter[]).map((ft) => (
              <button
                key={ft}
                onClick={() => setFuelFilter(ft)}
                className={`rounded-md px-2.5 py-1 text-xs font-medium transition-all ${
                  fuelFilter === ft
                    ? "bg-gradient-to-br from-amber-500 to-orange-600 text-white shadow shadow-amber-500/30"
                    : "bg-white/5 text-muted-foreground hover:bg-white/10 hover:text-foreground border border-white/10"
                }`}
              >
                {ft === "all" ? t("stations.fuelTypes") : t(`fuelType.${ft}` as any)}
              </button>
            ))}
          </div>

          {/* Status banner */}
          {userLocation && (
            <div className="rounded-lg bg-emerald-500/10 border border-emerald-500/20 px-3 py-2 text-xs text-emerald-400 flex items-center gap-2">
              <Crosshair className="h-3.5 w-3.5" />
              {t("stations.locationDetected")}
            </div>
          )}
          {locationError && (
            <div className="rounded-lg bg-red-500/10 border border-red-500/20 px-3 py-2 text-xs text-red-400 flex items-center gap-2">
              <AlertCircle className="h-3.5 w-3.5" />
              {locationError}
            </div>
          )}

          {/* Results count */}
          <div className="text-xs text-muted-foreground px-1">
            {t("stations.resultsCount", { count: filteredStations.length })}
          </div>

          {/* Station list */}
          <div className="flex-1 overflow-auto pe-2 space-y-3 min-h-0">
            {isLoading ? (
              <div className="p-4 text-center text-muted-foreground text-sm">{t("stations.loading")}</div>
            ) : filteredStations.length === 0 ? (
              <div className="p-4 text-center text-muted-foreground text-sm">{t("stations.noResults")}</div>
            ) : (
              filteredStations.map((station) => (
                <Card
                  key={station.id}
                  role="button"
                  tabIndex={0}
                  aria-pressed={selectedStationId === station.id}
                  className={`cursor-pointer transition-all rounded-2xl border-white/10 bg-gradient-to-br from-slate-900/60 to-slate-950/60 hover:border-amber-500/40 hover:shadow-lg hover:shadow-amber-500/5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-400 ${
                    selectedStationId === station.id
                      ? "border-amber-500/60 shadow-lg shadow-amber-500/10 ring-1 ring-amber-500/30"
                      : ""
                  }`}
                  onClick={() => setSelectedStationId(station.id)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" || e.key === " ") {
                      e.preventDefault();
                      setSelectedStationId(station.id);
                    }
                  }}
                >
                  <CardContent className="p-4">
                    <div className="flex justify-between items-start mb-2 gap-2">
                      <h3 className="font-semibold leading-tight">{station.name}</h3>
                      <div className="flex items-center text-xs font-medium text-amber-400 shrink-0">
                        <Star className="h-3.5 w-3.5 fill-amber-400 text-amber-400 me-1" />
                        {station.rating}
                      </div>
                    </div>
                    <div className="flex items-center text-xs text-muted-foreground mb-3">
                      <MapPin className="h-3.5 w-3.5 me-1 shrink-0" />
                      <span className="truncate">
                        {station.address}, {station.city}
                      </span>
                      <span className="ms-2 px-1.5 py-0.5 rounded-md bg-white/5 text-[11px] tabular-nums shrink-0">
                        {formatNumber(station.distanceKm, { decimals: 1 })} {t("stations.km")}
                      </span>
                    </div>
                    <div className="flex flex-wrap gap-1.5 mb-3">
                      {station.fuelTypes.map((type) => (
                        <Badge
                          key={type}
                          variant="outline"
                          className="text-[10px] font-normal bg-amber-500/5 text-amber-400 border-amber-500/20"
                        >
                          <FuelIcon className="h-2.5 w-2.5 me-1" />
                          {t(`fuelType.${type}` as any)}
                        </Badge>
                      ))}
                    </div>
                    <div className="flex items-center justify-between pt-3 border-t border-white/10">
                      <StatusBadge isOpen={station.isOpen} t={t} />
                      <Button
                        size="sm"
                        className="h-8 rounded-lg bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-400 hover:to-orange-500 text-xs font-medium"
                        onClick={(e) => {
                          e.stopPropagation();
                          openDirections(station.lat, station.lng);
                        }}
                      >
                        <Navigation className="h-3 w-3 me-1" />
                        {t("stations.directions")}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </div>

        {/* ─────────── Right: Google Map ─────────── */}
        <div
          className="w-full lg:flex-1 h-[420px] lg:h-auto rounded-2xl overflow-hidden border border-white/10 shadow-2xl bg-slate-950 relative"
          dir="ltr"
        >
          {!API_KEY || mapsAuthFailed ? (
            <MapErrorScreen message={t("stations.mapError")} />
          ) : (
            <MapsErrorBoundary fallback={<MapErrorScreen message={t("stations.mapError")} />}>
              <APIProvider apiKey={API_KEY}>
                <Map
                  mapId="DEMO_MAP_ID"
                  defaultCenter={DEFAULT_CENTER}
                  defaultZoom={12}
                  gestureHandling="greedy"
                  disableDefaultUI={false}
                  colorScheme="DARK"
                  style={{ width: "100%", height: "100%" }}
                >
                  <MapStateExposer onMap={setMapInstance} />

                  {/* User-location marker */}
                  {userLocation && (
                    <AdvancedMarker position={userLocation} title="You are here">
                      <div className="relative">
                        <div className="absolute inset-0 rounded-full bg-sky-400/30 blur animate-ping" />
                        <div className="relative h-4 w-4 rounded-full bg-sky-400 ring-2 ring-white shadow-lg" />
                      </div>
                    </AdvancedMarker>
                  )}

                  {/* Clustered station pins */}
                  <ClusteredStationMarkers
                    stations={filteredStations}
                    selectedId={selectedStationId}
                    onSelect={setSelectedStationId}
                  />
                </Map>

                {/* Floating action buttons (FABs) overlaid on map */}
                <MapControls
                  isLocating={isLocating}
                  onLocate={handleUseMyLocation}
                  onFitAll={fitAllStations}
                  locateLabel={t("stations.useMyLocation")}
                  fitAllLabel={t("stations.fitAll")}
                />

                {/* Bottom peek card for selected station */}
                <AnimatePresence>
                  {selectedStation && (
                    <BottomPeekCard
                      key={selectedStation.id}
                      station={selectedStation}
                      onClose={() => setSelectedStationId(null)}
                      onDirections={() => openDirections(selectedStation.lat, selectedStation.lng)}
                      formatCurrency={formatCurrency}
                      formatNumber={formatNumber}
                      t={t}
                    />
                  )}
                </AnimatePresence>
              </APIProvider>
            </MapsErrorBoundary>
          )}
        </div>
      </div>
    </div>
  );
}

/* Friendly fullscreen error inside the map area */
function MapErrorScreen({ message }: { message: string }) {
  return (
    <div className="h-full flex flex-col items-center justify-center text-muted-foreground text-sm gap-3 p-8 text-center">
      <div className="rounded-full bg-amber-500/10 p-3 ring-1 ring-amber-500/30">
        <AlertCircle className="h-8 w-8 text-amber-400" />
      </div>
      <p className="max-w-xs leading-relaxed">{message}</p>
      <a
        href="https://console.cloud.google.com/google/maps-apis/overview"
        target="_blank"
        rel="noopener noreferrer"
        className="text-xs text-amber-400 hover:underline"
      >
        Open Google Cloud Console →
      </a>
    </div>
  );
}

/* Generic error boundary for Maps subtrees */
class MapsErrorBoundary extends Component<{ children: ReactNode; fallback: ReactNode }, { hasError: boolean }> {
  state = { hasError: false };
  static getDerivedStateFromError() {
    return { hasError: true };
  }
  componentDidCatch(err: unknown) {
    // eslint-disable-next-line no-console
    console.warn("[Maps] subtree error", err);
  }
  render() {
    return this.state.hasError ? this.props.fallback : this.props.children;
  }
}

/* ─────────── Sub-components ─────────── */

function FilterChip({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      onClick={onClick}
      className={`rounded-full px-3 py-1.5 text-xs font-medium transition-all ${
        active
          ? "bg-gradient-to-r from-amber-500 to-orange-600 text-white shadow shadow-amber-500/30"
          : "bg-white/5 text-muted-foreground hover:bg-white/10 hover:text-foreground border border-white/10"
      }`}
    >
      {children}
    </button>
  );
}

function StatusBadge({ isOpen, t }: { isOpen: boolean; t: (k: any) => string }) {
  return (
    <div
      className={`inline-flex items-center gap-1.5 rounded-full px-2 py-1 text-[11px] font-medium ${
        isOpen
          ? "bg-emerald-500/15 text-emerald-400 border border-emerald-500/30"
          : "bg-red-500/15 text-red-400 border border-red-500/30"
      }`}
    >
      <span className={`h-1.5 w-1.5 rounded-full ${isOpen ? "bg-emerald-400 animate-pulse" : "bg-red-400"}`} />
      <Clock className="h-3 w-3" />
      {isOpen ? t("stations.openNow") : t("stations.closed")}
    </div>
  );
}

/* Exposes the live Google Map instance up to the parent via callback */
function MapStateExposer({ onMap }: { onMap: (m: google.maps.Map | null) => void }) {
  const map = useMap();
  useEffect(() => {
    onMap(map ?? null);
    return () => onMap(null);
  }, [map, onMap]);
  return null;
}

/* Marker clustering — groups nearby pins into numbered clusters when zoomed out.
   Uses the @googlemaps/markerclusterer library + AdvancedMarker refs. */
function ClusteredStationMarkers({
  stations,
  selectedId,
  onSelect,
}: {
  stations: Array<{ id: number; lat: number; lng: number; name: string }>;
  selectedId: number | null;
  onSelect: (id: number) => void;
}) {
  const map = useMap();
  const [markers, setMarkers] = useState<Record<number, google.maps.marker.AdvancedMarkerElement>>({});
  const clustererRef = useRef<MarkerClusterer | null>(null);

  // Init the clusterer once the map is ready
  useEffect(() => {
    if (!map) return;
    if (!clustererRef.current) {
      clustererRef.current = new MarkerClusterer({ map });
    }
    return () => {
      clustererRef.current?.clearMarkers();
      clustererRef.current?.setMap(null);
      clustererRef.current = null;
    };
  }, [map]);

  // Sync markers into the clusterer whenever the marker collection changes
  useEffect(() => {
    if (!clustererRef.current) return;
    clustererRef.current.clearMarkers();
    clustererRef.current.addMarkers(Object.values(markers));
  }, [markers]);

  const setMarkerRef = useCallback(
    (marker: google.maps.marker.AdvancedMarkerElement | null, id: number) => {
      setMarkers((prev) => {
        if ((marker && prev[id]) || (!marker && !prev[id])) return prev;
        if (marker) return { ...prev, [id]: marker };
        const next = { ...prev };
        delete next[id];
        return next;
      });
    },
    []
  );

  return (
    <>
      {stations.map((station) => (
        <AdvancedMarker
          key={station.id}
          ref={(marker) => setMarkerRef(marker, station.id)}
          position={{ lat: station.lat, lng: station.lng }}
          onClick={() => onSelect(station.id)}
          title={station.name}
        >
          <Pin
            background={selectedId === station.id ? "#f59e0b" : "#1e293b"}
            borderColor={selectedId === station.id ? "#fff" : "#f59e0b"}
            glyphColor={selectedId === station.id ? "#fff" : "#f59e0b"}
            scale={selectedId === station.id ? 1.3 : 1}
          />
        </AdvancedMarker>
      ))}
    </>
  );
}

/* Floating action buttons over the map (Google-Maps-mobile style) */
function MapControls({
  isLocating,
  onLocate,
  onFitAll,
  locateLabel,
  fitAllLabel,
}: {
  isLocating: boolean;
  onLocate: () => void;
  onFitAll: () => void;
  locateLabel: string;
  fitAllLabel: string;
}) {
  const fabClass =
    "h-11 w-11 rounded-full bg-slate-900/90 backdrop-blur-md ring-1 ring-amber-500/40 shadow-xl flex items-center justify-center text-amber-400 hover:bg-slate-800/95 hover:ring-amber-400 hover:scale-105 active:scale-95 transition-all disabled:opacity-50 disabled:cursor-not-allowed";
  return (
    <div className="absolute bottom-5 right-5 z-10 flex flex-col gap-2.5">
      <button onClick={onFitAll} className={fabClass} title={fitAllLabel} aria-label={fitAllLabel}>
        <Maximize2 className="h-5 w-5" />
      </button>
      <button
        onClick={onLocate}
        disabled={isLocating}
        className={fabClass}
        title={locateLabel}
        aria-label={locateLabel}
      >
        {isLocating ? <Loader2 className="h-5 w-5 animate-spin" /> : <Crosshair className="h-5 w-5" />}
      </button>
    </div>
  );
}

/* Slide-up rich detail card for the selected station, overlaid on the map.
   Replaces the legacy InfoWindow tooltip. */
function BottomPeekCard({
  station,
  onClose,
  onDirections,
  formatCurrency,
  formatNumber,
  t,
}: {
  station: any;
  onClose: () => void;
  onDirections: () => void;
  formatCurrency: (n: number) => string;
  formatNumber: (n: number, opts?: { decimals?: number }) => string;
  t: (k: any) => string;
}) {
  return (
    <motion.div
      initial={{ y: 80, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      exit={{ y: 80, opacity: 0 }}
      transition={{ type: "spring", damping: 22, stiffness: 240 }}
      className="absolute left-4 right-4 bottom-4 z-20 sm:left-5 sm:right-auto sm:w-[400px]"
    >
      <div className="rounded-2xl bg-slate-900/95 backdrop-blur-xl border border-amber-500/30 shadow-2xl shadow-black/50 overflow-hidden">
        {/* Drag handle */}
        <div className="flex justify-center pt-2 pb-1">
          <div className="h-1 w-10 rounded-full bg-white/20" />
        </div>

        <div className="px-5 pb-5">
          {/* Header */}
          <div className="flex items-start justify-between gap-3 mb-3">
            <div className="min-w-0">
              <div className="flex items-center gap-2 mb-1">
                <h3 className="font-bold text-base text-white truncate">{station.name}</h3>
                <div className="flex items-center text-xs font-semibold text-amber-400 shrink-0">
                  <Star className="h-3.5 w-3.5 fill-amber-400 text-amber-400 mr-0.5" />
                  {station.rating}
                </div>
              </div>
              <div className="flex items-center text-xs text-muted-foreground">
                <MapPin className="h-3.5 w-3.5 me-1 shrink-0" />
                <span className="truncate">
                  {station.address}, {station.city}
                </span>
              </div>
            </div>
            <button
              onClick={onClose}
              aria-label={t("stations.close")}
              className="shrink-0 h-8 w-8 rounded-full bg-white/5 hover:bg-white/10 flex items-center justify-center text-muted-foreground hover:text-white transition-colors"
            >
              <X className="h-4 w-4" />
            </button>
          </div>

          {/* Status row */}
          <div className="flex items-center gap-2 text-xs mb-3">
            <span
              className={`inline-flex items-center gap-1.5 px-2 py-1 rounded-full font-medium ${
                station.isOpen
                  ? "bg-emerald-500/15 text-emerald-400 border border-emerald-500/30"
                  : "bg-red-500/15 text-red-400 border border-red-500/30"
              }`}
            >
              <span
                className={`h-1.5 w-1.5 rounded-full ${station.isOpen ? "bg-emerald-400 animate-pulse" : "bg-red-400"}`}
              />
              {station.isOpen ? t("stations.openNow") : t("stations.closed")}
            </span>
            <span className="text-muted-foreground">·</span>
            <span className="text-foreground tabular-nums">
              {formatNumber(station.distanceKm, { decimals: 1 })} {t("stations.km")}
            </span>
          </div>

          {/* Prices */}
          <div className="grid grid-cols-2 gap-2 mb-4">
            {station.prices.gasoline91 != null && (
              <DarkPricePill
                label={t("fuelType.gasoline_91")}
                value={formatCurrency(station.prices.gasoline91)}
              />
            )}
            {station.prices.gasoline95 != null && (
              <DarkPricePill
                label={t("fuelType.gasoline_95")}
                value={formatCurrency(station.prices.gasoline95)}
              />
            )}
            {station.prices.diesel != null && (
              <DarkPricePill label={t("fuelType.diesel")} value={formatCurrency(station.prices.diesel)} />
            )}
          </div>

          {/* CTA */}
          <Button
            onClick={onDirections}
            className="w-full h-11 rounded-xl bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-400 hover:to-orange-500 text-white font-semibold shadow-lg shadow-amber-500/20"
          >
            <Navigation className="h-4 w-4 me-2" />
            {t("stations.directions")}
          </Button>
        </div>
      </div>
    </motion.div>
  );
}

function DarkPricePill({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg bg-amber-500/5 border border-amber-500/20 px-3 py-2">
      <div className="text-[10px] uppercase tracking-wide text-amber-400/70 font-semibold mb-0.5">{label}</div>
      <div className="text-sm font-bold text-white tabular-nums">{value}</div>
    </div>
  );
}

/* Places Autocomplete via the modern PlaceAutocompleteElement (web component).
   Falls back to a plain text Input + Geocoder lookup if the new element is not
   available in the loaded Maps build (e.g. billing disabled / API restricted). */
function PlacesAutocompleteInput({
  onPlaceSelect,
  placeholder,
  language,
}: {
  onPlaceSelect: (loc: { lat: number; lng: number }) => void;
  placeholder: string;
  language: string;
}) {
  const places = useMapsLibrary("places");
  const geocoding = useMapsLibrary("geocoding");
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [useFallback, setUseFallback] = useState(false);
  const [fallbackQuery, setFallbackQuery] = useState("");

  useEffect(() => {
    if (!places || !containerRef.current) return;
    const PlaceAutocompleteEl = (places as any).PlaceAutocompleteElement;
    if (!PlaceAutocompleteEl) {
      setUseFallback(true);
      return;
    }

    let element: HTMLElement | null = null;
    let handler: ((e: any) => void) | null = null;
    try {
      element = new PlaceAutocompleteEl();
      if (!element) {
        setUseFallback(true);
        return;
      }
      element.setAttribute("placeholder", placeholder);
      element.style.width = "100%";
      containerRef.current.innerHTML = "";
      containerRef.current.appendChild(element);

      handler = async (e: any) => {
        const placePrediction = e.placePrediction;
        if (!placePrediction) return;
        try {
          const place = placePrediction.toPlace();
          await place.fetchFields({ fields: ["location"] });
          if (place.location) {
            onPlaceSelect({ lat: place.location.lat(), lng: place.location.lng() });
          }
        } catch {
          /* swallow — fallback path also handles search */
        }
      };
      element.addEventListener("gmp-select", handler);
    } catch {
      setUseFallback(true);
    }
    return () => {
      if (element && handler) element.removeEventListener("gmp-select", handler);
      element?.remove();
    };
  }, [places, placeholder, onPlaceSelect]);

  // Plain-input fallback: geocode on Enter
  const handleFallbackSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!fallbackQuery.trim() || !geocoding) return;
    try {
      const geocoder = new geocoding.Geocoder();
      const result = await geocoder.geocode({ address: fallbackQuery });
      const loc = result.results[0]?.geometry?.location;
      if (loc) onPlaceSelect({ lat: loc.lat(), lng: loc.lng() });
    } catch {
      /* ignore */
    }
  };

  if (useFallback) {
    return (
      <form onSubmit={handleFallbackSubmit} className="relative">
        <Search className="absolute start-3 top-1/2 -translate-y-1/2 h-4 w-4 text-amber-400/60 pointer-events-none" />
        <Input
          value={fallbackQuery}
          onChange={(e) => setFallbackQuery(e.target.value)}
          placeholder={placeholder}
          className="ps-9 h-11 rounded-xl bg-white/5 border-amber-500/20 hover:border-amber-500/40 focus-visible:ring-amber-400"
          lang={language}
        />
      </form>
    );
  }

  return (
    <div className="relative">
      <Search className="absolute start-3 top-1/2 -translate-y-1/2 h-4 w-4 text-amber-400/60 pointer-events-none z-10" />
      <div
        ref={containerRef}
        className="places-autocomplete-host rounded-xl bg-white/5 border border-amber-500/20 hover:border-amber-500/40 focus-within:border-amber-400 transition-colors min-h-[44px] flex items-center ps-9 pe-3"
        lang={language}
      />
    </div>
  );
}
