import { useState, useEffect, useMemo } from "react";
import {
  useListVehicles,
  useListStations,
  useCreateFuelingSession,
  useCompleteFuelingSession,
  getGetWalletQueryKey,
} from "@workspace/api-client-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import QRCode from "qrcode";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import {
  Loader2,
  QrCode,
  CheckCircle2,
  Car,
  MapPin,
  AlertCircle,
  Fuel as FuelIcon,
  Receipt,
  Clock,
  Droplets,
  ChevronRight,
} from "lucide-react";
import { Link } from "wouter";
import { useLanguage } from "@/lib/i18n";

type FuelType = "gasoline_91" | "gasoline_95" | "diesel";
type PaymentStatus = "waiting" | "processing" | "paid" | "failed";

const FUEL_PRICES: Record<FuelType, number> = {
  gasoline_91: 13.75,
  gasoline_95: 15.25,
  diesel: 13.5,
};

export default function Fuel() {
  const { data: vehicles, isLoading: isLoadingVehicles } = useListVehicles();
  const { data: stations, isLoading: isLoadingStations } = useListStations();
  const { t, formatNumber, formatCurrency, language } = useLanguage();
  const currencyLabel = language === "ar" ? "ج.م" : "EGP";

  const [vehicleId, setVehicleId] = useState<string>("");
  const [stationId, setStationId] = useState<string>("");
  const [fuelType, setFuelType] = useState<FuelType>("gasoline_91");
  const [amount, setAmount] = useState<string>("");
  const [session, setSession] = useState<any>(null);
  const [qrDataUrl, setQrDataUrl] = useState<string>("");
  const [timeLeft, setTimeLeft] = useState<number>(0);
  const [status, setStatus] = useState<PaymentStatus>("waiting");
  const [isCompleted, setIsCompleted] = useState(false);
  const [completedAt, setCompletedAt] = useState<Date | null>(null);

  const queryClient = useQueryClient();
  const { toast } = useToast();

  const selectedVehicle = useMemo(
    () => vehicles?.find((v) => v.id === parseInt(vehicleId)),
    [vehicles, vehicleId]
  );
  const selectedStation = useMemo(
    () => stations?.find((s) => s.id === parseInt(stationId)),
    [stations, stationId]
  );

  // Auto-pick the vehicle's fuel type
  useEffect(() => {
    if (selectedVehicle?.fuelType) {
      setFuelType(selectedVehicle.fuelType as FuelType);
    }
  }, [selectedVehicle]);

  const amountNum = parseFloat(amount) || 0;
  const pricePerLiter = FUEL_PRICES[fuelType];
  const estimatedLiters = amountNum > 0 ? amountNum / pricePerLiter : 0;

  const createSession = useCreateFuelingSession({
    mutation: {
      onSuccess: async (data) => {
        setSession(data);
        setStatus("waiting");
        const qrUrl = await QRCode.toDataURL(data.qrPayload, {
          width: 360,
          margin: 1,
          color: { dark: "#0a0a14", light: "#ffffff" },
        });
        setQrDataUrl(qrUrl);
        const expiry = new Date(data.expiresAt).getTime();
        const now = Date.now();
        setTimeLeft(Math.max(0, Math.floor((expiry - now) / 1000)));
      },
      onError: (error: any) => {
        setStatus("failed");
        toast({ title: t("toast.fuel.failed"), description: error?.data?.message, variant: "destructive" });
      },
    },
  });

  const completeSession = useCompleteFuelingSession({
    mutation: {
      onSuccess: () => {
        setStatus("paid");
        setIsCompleted(true);
        setCompletedAt(new Date());
        queryClient.invalidateQueries({ queryKey: getGetWalletQueryKey() });
        toast({ title: t("toast.fuel.success.title"), description: t("toast.fuel.success.desc") });
      },
      onError: () => {
        setStatus("failed");
      },
    },
  });

  useEffect(() => {
    if (session && timeLeft > 0 && !isCompleted) {
      const timer = setInterval(() => setTimeLeft((p) => Math.max(0, p - 1)), 1000);
      return () => clearInterval(timer);
    }
    return undefined;
  }, [session, timeLeft, isCompleted]);

  const handleGenerate = () => {
    if (!vehicleId || !stationId || amountNum <= 0) return;
    createSession.mutate({
      data: { vehicleId: parseInt(vehicleId), stationId: parseInt(stationId) },
    });
  };

  const handleConfirmPump = () => {
    if (!session) return;
    setStatus("processing");
    setTimeout(() => {
      completeSession.mutate({
        id: session.id,
        data: { liters: estimatedLiters, pricePerLiter, fuelType },
      });
    }, 1500);
  };

  const resetFlow = () => {
    setSession(null);
    setQrDataUrl("");
    setIsCompleted(false);
    setTimeLeft(0);
    setStatus("waiting");
    setAmount("");
    setCompletedAt(null);
  };

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m}:${s.toString().padStart(2, "0")}`;
  };

  const canGenerate = !!vehicleId && !!stationId && amountNum > 0 && !createSession.isPending;

  return (
    <div className="max-w-3xl mx-auto space-y-6 px-4 sm:px-0">
      {/* Header */}
      <div className="flex items-start gap-3">
        <div className="rounded-2xl bg-gradient-to-br from-amber-500/20 to-amber-600/10 p-3 ring-1 ring-amber-500/30">
          <FuelIcon className="h-6 w-6 text-amber-400" />
        </div>
        <div>
          <h1 className="text-3xl font-bold tracking-tight">{t("fuel.title")}</h1>
          <p className="text-muted-foreground text-sm mt-0.5">{t("fuel.subtitle")}</p>
        </div>
      </div>

      {!session ? (
        /* ─────────── PRE-SESSION FORM ─────────── */
        <Card className="rounded-3xl border-white/10 bg-gradient-to-br from-slate-900/80 via-slate-900/60 to-slate-950/80 shadow-2xl backdrop-blur-sm overflow-hidden">
          <div className="h-1 w-full bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600" />
          <CardContent className="p-6 sm:p-8 space-y-6">
            {/* Vehicle + Station — 2 columns on desktop */}
            <div className="grid gap-5 sm:grid-cols-2">
              <FieldShell icon={<Car className="h-4 w-4" />} label={t("fuel.vehicle")}>
                <Select value={vehicleId} onValueChange={setVehicleId}>
                  <SelectTrigger className="h-12 rounded-xl bg-white/5 border-white/10 hover:bg-white/10 transition-colors">
                    <SelectValue placeholder={isLoadingVehicles ? t("common.loading") : t("fuel.selectVehicle")} />
                  </SelectTrigger>
                  <SelectContent>
                    {vehicles?.map((v) => (
                      <SelectItem key={v.id} value={v.id.toString()}>
                        <div className="flex items-center gap-2">
                          <span className="font-medium">{v.name}</span>
                          <span className="text-muted-foreground text-xs font-mono">{v.plate}</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </FieldShell>

              <FieldShell icon={<MapPin className="h-4 w-4" />} label={t("fuel.station")}>
                <Select value={stationId} onValueChange={setStationId}>
                  <SelectTrigger className="h-12 rounded-xl bg-white/5 border-white/10 hover:bg-white/10 transition-colors">
                    <SelectValue placeholder={isLoadingStations ? t("common.loading") : t("fuel.selectStation")} />
                  </SelectTrigger>
                  <SelectContent>
                    {stations?.map((s) => (
                      <SelectItem key={s.id} value={s.id.toString()}>
                        <div className="flex flex-col items-start">
                          <span className="font-medium">{s.name}</span>
                          <span className="text-muted-foreground text-xs">
                            {t("fuel.kmAway", { km: formatNumber(s.distanceKm, { decimals: 1 }) })}
                          </span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </FieldShell>
            </div>

            {/* Fuel Type — segmented */}
            <FieldShell icon={<Droplets className="h-4 w-4" />} label={t("fuel.fuelType")}>
              <div
                role="radiogroup"
                aria-label={t("fuel.fuelType")}
                className="grid grid-cols-3 gap-2 rounded-xl bg-white/5 border border-white/10 p-1"
              >
                {(["gasoline_91", "gasoline_95", "diesel"] as FuelType[]).map((type) => {
                  const active = fuelType === type;
                  return (
                    <button
                      key={type}
                      type="button"
                      role="radio"
                      aria-checked={active}
                      onClick={() => setFuelType(type)}
                      className={`relative h-11 rounded-lg text-sm font-medium transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-400 focus-visible:ring-offset-2 focus-visible:ring-offset-slate-900 ${
                        active
                          ? "bg-gradient-to-br from-amber-500 to-orange-600 text-white shadow-lg shadow-amber-500/30"
                          : "text-muted-foreground hover:text-foreground hover:bg-white/5"
                      }`}
                    >
                      {t(`fuelType.${type}` as any)}
                    </button>
                  );
                })}
              </div>
            </FieldShell>

            {/* Amount input with EGP prefix */}
            <FieldShell icon={<Receipt className="h-4 w-4" />} label={t("fuel.amount")}>
              <div className="relative">
                <span className="pointer-events-none absolute inset-y-0 start-0 flex items-center ps-4 text-amber-400 font-semibold">
                  {currencyLabel}
                </span>
                <Input
                  type="number"
                  inputMode="decimal"
                  min="0"
                  step="0.01"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder={t("fuel.amountPlaceholder")}
                  className="h-14 rounded-xl bg-white/5 border-white/10 ps-16 text-xl font-bold tabular-nums hover:bg-white/10 transition-colors"
                />
              </div>
              {/* Live estimate */}
              <div className="mt-3 flex items-center justify-between rounded-xl bg-amber-500/5 border border-amber-500/20 px-4 py-3">
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <Droplets className="h-3.5 w-3.5 text-amber-400" />
                  <span>{t("fuel.estimatedLiters")}</span>
                </div>
                <div className="text-end">
                  <div className="text-lg font-bold tabular-nums">
                    {amountNum > 0 ? `${formatNumber(estimatedLiters, { decimals: 2 })} L` : "—"}
                  </div>
                  <div className="text-[10px] text-muted-foreground">
                    {t("fuel.pricePerLiter")}: {formatCurrency(pricePerLiter)}
                  </div>
                </div>
              </div>
            </FieldShell>

            {/* Generate button */}
            <Button
              className="w-full h-14 rounded-xl text-base font-semibold bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-400 hover:to-orange-500 shadow-lg shadow-amber-500/30 hover:shadow-xl hover:shadow-amber-500/40 transition-all hover:scale-[1.01] active:scale-[0.99] disabled:opacity-50 disabled:hover:scale-100"
              onClick={handleGenerate}
              disabled={!canGenerate}
            >
              {createSession.isPending ? (
                <>
                  <Loader2 className="me-2 h-5 w-5 animate-spin" /> {t("fuel.generating")}
                </>
              ) : !vehicleId ? (
                <>{t("fuel.selectVehicle")}</>
              ) : !stationId ? (
                <>{t("fuel.selectStation")}</>
              ) : amountNum <= 0 ? (
                <>{t("fuel.amountRequired")}</>
              ) : (
                <>
                  <QrCode className="me-2 h-5 w-5" /> {t("fuel.generateQR")}{" "}
                  <ChevronRight className="ms-1 h-5 w-5 rtl:rotate-180" />
                </>
              )}
            </Button>
          </CardContent>
        </Card>
      ) : isCompleted ? (
        /* ─────────── SUCCESS ─────────── */
        <SuccessCard
          amount={amountNum}
          liters={estimatedLiters}
          fuelType={fuelType}
          vehicleName={selectedVehicle?.name ?? ""}
          vehiclePlate={selectedVehicle?.plate ?? ""}
          stationName={selectedStation?.name ?? ""}
          completedAt={completedAt}
          onReset={resetFlow}
        />
      ) : (
        /* ─────────── ACTIVE SESSION ─────────── */
        <div className="grid gap-6 lg:grid-cols-5">
          {/* QR card */}
          <Card className="lg:col-span-3 rounded-3xl border-white/10 bg-gradient-to-br from-slate-900/80 to-slate-950/80 shadow-2xl overflow-hidden">
            <div className="h-1 w-full bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 animate-pulse" />
            <CardContent className="p-6 sm:p-8 flex flex-col items-center text-center">
              <StatusBadge status={status} t={t} />

              <h2 className="text-xl font-bold mt-4">{t("fuel.scanAtPump")}</h2>
              <p className="text-muted-foreground text-sm mt-1">{t("fuel.scanAtPumpDesc")}</p>

              {/* QR with rotating gradient frame */}
              <div className="relative mt-6 group">
                <div className="absolute -inset-1 rounded-2xl bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 opacity-50 blur group-hover:opacity-75 transition-opacity" />
                <div className="relative bg-white p-5 rounded-2xl shadow-2xl">
                  {timeLeft === 0 && status !== "paid" && status !== "processing" && (
                    <div className="absolute inset-0 bg-slate-900/95 backdrop-blur-sm flex flex-col items-center justify-center rounded-2xl z-10">
                      <AlertCircle className="h-12 w-12 text-red-400 mb-2" />
                      <p className="font-bold text-white">{t("fuel.codeExpired")}</p>
                    </div>
                  )}
                  {qrDataUrl && (
                    <img src={qrDataUrl} alt="Payment QR Code" className="w-72 h-72 object-contain" />
                  )}
                </div>
              </div>

              {/* Timer */}
              <div className="mt-6 inline-flex items-center gap-2 rounded-full bg-white/5 border border-white/10 px-4 py-2">
                <Clock className={`h-4 w-4 ${timeLeft < 60 ? "text-red-400" : "text-amber-400"}`} />
                <span
                  className={`text-lg font-mono font-bold tabular-nums tracking-wider ${
                    timeLeft < 60 ? "text-red-400" : ""
                  }`}
                >
                  {formatTime(timeLeft)}
                </span>
                <span className="text-xs text-muted-foreground uppercase ms-1">{t("fuel.timeRemaining")}</span>
              </div>
            </CardContent>
          </Card>

          {/* Summary card */}
          <Card className="lg:col-span-2 rounded-3xl border-white/10 bg-gradient-to-br from-slate-900/80 to-slate-950/80 shadow-2xl overflow-hidden flex flex-col">
            <div className="h-1 w-full bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600" />
            <CardContent className="p-6 flex flex-col flex-1">
              <div className="flex items-center gap-2 mb-4">
                <Receipt className="h-4 w-4 text-amber-400" />
                <h3 className="text-sm font-semibold uppercase tracking-wide">{t("fuel.summaryTitle")}</h3>
              </div>

              <div className="space-y-3 text-sm flex-1">
                <SummaryRow
                  icon={<Car className="h-3.5 w-3.5" />}
                  label={t("fuel.vehicle")}
                  value={
                    <div className="text-end">
                      <div className="font-medium">{selectedVehicle?.name}</div>
                      <div className="text-[11px] text-muted-foreground font-mono">
                        {selectedVehicle?.plate}
                      </div>
                    </div>
                  }
                />
                <SummaryRow
                  icon={<MapPin className="h-3.5 w-3.5" />}
                  label={t("fuel.station")}
                  value={<span className="font-medium">{selectedStation?.name}</span>}
                />
                <SummaryRow
                  icon={<Droplets className="h-3.5 w-3.5" />}
                  label={t("fuel.fuelType")}
                  value={
                    <Badge className="bg-amber-500/15 text-amber-400 border-amber-500/30 hover:bg-amber-500/15">
                      {t(`fuelType.${fuelType}` as any)}
                    </Badge>
                  }
                />
                <SummaryRow
                  icon={<Droplets className="h-3.5 w-3.5" />}
                  label={t("fuel.estimatedLiters")}
                  value={
                    <span className="font-medium tabular-nums">
                      {formatNumber(estimatedLiters, { decimals: 2 })} L
                    </span>
                  }
                />
                <div className="h-px bg-white/10 my-2" />
                <SummaryRow
                  icon={<Receipt className="h-3.5 w-3.5" />}
                  label={t("fuel.amount")}
                  value={
                    <span className="text-xl font-bold text-amber-400 tabular-nums">
                      {formatCurrency(amountNum)}
                    </span>
                  }
                />
              </div>

              {/* Action buttons */}
              <div className="space-y-2 mt-6">
                <Button
                  className="w-full h-12 rounded-xl bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-400 hover:to-orange-500 font-semibold shadow-lg shadow-amber-500/30 transition-all"
                  onClick={handleConfirmPump}
                  disabled={
                    status === "processing" ||
                    timeLeft === 0 ||
                    completeSession.isPending
                  }
                >
                  {status === "processing" || completeSession.isPending ? (
                    <>
                      <Loader2 className="me-2 h-4 w-4 animate-spin" /> {t("fuel.fueling")}
                    </>
                  ) : (
                    <>
                      <CheckCircle2 className="me-2 h-4 w-4" /> {t("fuel.simulate")}
                    </>
                  )}
                </Button>
                <Button
                  variant="ghost"
                  className="w-full text-muted-foreground hover:text-foreground"
                  onClick={resetFlow}
                  disabled={status === "processing"}
                >
                  {t("fuel.cancelSession")}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}

/* ─────────── Sub-components ─────────── */

function FieldShell({
  icon,
  label,
  children,
}: {
  icon: React.ReactNode;
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div className="space-y-2">
      <Label className="flex items-center gap-2 text-xs font-medium text-muted-foreground">
        <span className="text-amber-400">{icon}</span>
        {label}
      </Label>
      {children}
    </div>
  );
}

function StatusBadge({ status, t }: { status: PaymentStatus; t: (k: any) => string }) {
  const styles: Record<PaymentStatus, { bg: string; text: string; dot: string; label: string }> = {
    waiting: {
      bg: "bg-amber-500/15 border-amber-500/30",
      text: "text-amber-400",
      dot: "bg-amber-400 animate-pulse",
      label: t("fuel.status.waiting"),
    },
    processing: {
      bg: "bg-sky-500/15 border-sky-500/30",
      text: "text-sky-400",
      dot: "bg-sky-400 animate-pulse",
      label: t("fuel.status.processing"),
    },
    paid: {
      bg: "bg-emerald-500/15 border-emerald-500/30",
      text: "text-emerald-400",
      dot: "bg-emerald-400",
      label: t("fuel.status.paid"),
    },
    failed: {
      bg: "bg-red-500/15 border-red-500/30",
      text: "text-red-400",
      dot: "bg-red-400",
      label: t("fuel.status.failed"),
    },
  };
  const s = styles[status];
  return (
    <div className={`inline-flex items-center gap-2 rounded-full border px-3 py-1.5 ${s.bg}`}>
      <span className={`h-2 w-2 rounded-full ${s.dot}`} />
      <span className={`text-xs font-semibold uppercase tracking-wide ${s.text}`}>{s.label}</span>
    </div>
  );
}

function SummaryRow({
  icon,
  label,
  value,
}: {
  icon: React.ReactNode;
  label: string;
  value: React.ReactNode;
}) {
  return (
    <div className="flex items-start justify-between gap-3">
      <div className="flex items-center gap-1.5 text-muted-foreground text-xs pt-0.5">
        <span className="text-amber-400/70">{icon}</span>
        {label}
      </div>
      <div>{value}</div>
    </div>
  );
}

function SuccessCard({
  amount,
  liters,
  fuelType,
  vehicleName,
  vehiclePlate,
  stationName,
  completedAt,
  onReset,
}: {
  amount: number;
  liters: number;
  fuelType: FuelType;
  vehicleName: string;
  vehiclePlate: string;
  stationName: string;
  completedAt: Date | null;
  onReset: () => void;
}) {
  const { t, formatCurrency, formatNumber } = useLanguage();
  return (
    <Card className="rounded-3xl border-emerald-500/30 bg-gradient-to-br from-emerald-950/40 via-slate-900/80 to-slate-950/80 shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-500">
      <div className="h-1 w-full bg-gradient-to-r from-emerald-400 via-emerald-500 to-teal-500" />
      <CardContent className="p-6 sm:p-10 flex flex-col items-center text-center">
        <div className="relative mb-6">
          <div className="absolute -inset-3 rounded-full bg-emerald-500/30 blur-xl animate-pulse" />
          <div className="relative h-20 w-20 bg-gradient-to-br from-emerald-400 to-emerald-600 rounded-full flex items-center justify-center shadow-2xl shadow-emerald-500/50">
            <CheckCircle2 className="h-12 w-12 text-white" strokeWidth={2.5} />
          </div>
        </div>
        <h2 className="text-2xl font-bold mb-2">{t("fuel.successTitle")}</h2>
        <p className="text-muted-foreground mb-6 max-w-sm">{t("fuel.successMsg")}</p>

        {/* Mini summary */}
        <div className="w-full max-w-md rounded-2xl bg-white/5 border border-white/10 p-5 space-y-3 text-sm text-start">
          <SummaryRow
            icon={<Car className="h-3.5 w-3.5" />}
            label={t("fuel.vehicle")}
            value={
              <div className="text-end">
                <div className="font-medium">{vehicleName}</div>
                <div className="text-[11px] text-muted-foreground font-mono">{vehiclePlate}</div>
              </div>
            }
          />
          <SummaryRow
            icon={<MapPin className="h-3.5 w-3.5" />}
            label={t("fuel.station")}
            value={<span className="font-medium">{stationName}</span>}
          />
          <SummaryRow
            icon={<Droplets className="h-3.5 w-3.5" />}
            label={t("fuel.fuelType")}
            value={
              <Badge className="bg-amber-500/15 text-amber-400 border-amber-500/30 hover:bg-amber-500/15">
                {t(`fuelType.${fuelType}` as any)} • {formatNumber(liters, { decimals: 2 })} L
              </Badge>
            }
          />
          {completedAt && (
            <SummaryRow
              icon={<Clock className="h-3.5 w-3.5" />}
              label={t("fuel.summaryTime")}
              value={
                <span className="font-medium tabular-nums">
                  {completedAt.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                </span>
              }
            />
          )}
          <div className="h-px bg-white/10" />
          <SummaryRow
            icon={<Receipt className="h-3.5 w-3.5" />}
            label={t("fuel.amount")}
            value={
              <span className="text-2xl font-bold text-emerald-400 tabular-nums">
                {formatCurrency(amount)}
              </span>
            }
          />
        </div>

        <div className="flex gap-3 w-full max-w-md mt-6">
          <Button variant="outline" className="flex-1 h-12 rounded-xl" onClick={onReset}>
            {t("common.done")}
          </Button>
          <Link href="/transactions" className="flex-1">
            <Button className="w-full h-12 rounded-xl bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-400 hover:to-orange-500 font-semibold">
              {t("fuel.viewReceipt")}
            </Button>
          </Link>
        </div>
      </CardContent>
    </Card>
  );
}
