import { useGetFleetOverview, useListFleetVehicles, useGetFleetMonthlyUsage } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { DashboardSkeleton } from "@/components/ui/loading-skeleton";
import { ErrorState } from "@/components/ui/empty-state";
import { Building2, Users, Car, AlertTriangle, TrendingUp, Filter } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { Button } from "@/components/ui/button";
import { useLanguage } from "@/lib/i18n";

export default function Fleet() {
  const { data: overview, isLoading: isLoadingOverview, isError: isErrorOverview } = useGetFleetOverview();
  const { data: vehicles, isLoading: isLoadingVehicles } = useListFleetVehicles();
  const { data: monthlyUsage, isLoading: isLoadingUsage } = useGetFleetMonthlyUsage();
  const { t, formatCurrency, formatNumber } = useLanguage();

  if (isLoadingOverview || isLoadingVehicles || isLoadingUsage) return <DashboardSkeleton />;
  if (isErrorOverview || !overview) return <ErrorState title={t("error.fleet")} />;

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'active': return t("fleet.status.active");
      case 'idle': return t("fleet.status.idle");
      case 'maintenance': return t("fleet.status.maintenance");
      default: return status;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">{t("fleet.title")}</h1>
          <p className="text-muted-foreground">{overview.companyName} • {t("fleet.opsOverview")}</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline">
            <Filter className="me-2 h-4 w-4" /> {t("fleet.filter")}
          </Button>
          <Button>{t("fleet.generateReport")}</Button>
        </div>
      </div>

      {overview.alerts && overview.alerts.length > 0 && (
        <div className="grid gap-3">
          {overview.alerts.map(alert => (
            <div key={alert.id} className={`flex items-start gap-3 p-4 rounded-lg border ${
              alert.severity === 'critical' ? 'bg-destructive/10 border-destructive/20 text-destructive' :
              alert.severity === 'warning' ? 'bg-amber-500/10 border-amber-500/20 text-amber-600 dark:text-amber-400' :
              'bg-primary/10 border-primary/20 text-primary'
            }`}>
              <AlertTriangle className="h-5 w-5 shrink-0 mt-0.5" />
              <div className="text-sm font-medium">{alert.message}</div>
            </div>
          ))}
        </div>
      )}

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
            <CardTitle className="text-sm font-medium">{t("fleet.totalVehicles")}</CardTitle>
            <Car className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{overview.vehicleCount}</div>
            <p className="text-xs text-muted-foreground mt-1">
              {t("fleet.activeToday", { count: overview.activeVehicles })}
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
            <CardTitle className="text-sm font-medium">{t("fleet.totalDrivers")}</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{overview.driverCount}</div>
            <p className="text-xs text-muted-foreground mt-1">
              {t("fleet.allDepartments")}
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
            <CardTitle className="text-sm font-medium">{t("fleet.mtdSpent")}</CardTitle>
            <Building2 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(overview.monthlySpent)}</div>
            <div className="flex items-center text-xs text-destructive mt-1 font-medium">
              <TrendingUp className="h-3 w-3 me-1" /> {t("fleet.fromLastMonth", { percent: "12" })}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
            <CardTitle className="text-sm font-medium">{t("fleet.mtdVolume")}</CardTitle>
            <FuelIcon className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatNumber(overview.monthlyLiters, { decimals: 0 })} L</div>
            <p className="text-xs text-muted-foreground mt-1">
              {t("fleet.combinedUsage")}
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-7">
        <Card className="col-span-1 lg:col-span-4">
          <CardHeader>
            <CardTitle>{t("fleet.monthlyUsage")}</CardTitle>
            <CardDescription>{t("fleet.monthlyUsageDesc")}</CardDescription>
          </CardHeader>
          <CardContent>
            {monthlyUsage && monthlyUsage.length > 0 ? (
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={monthlyUsage} margin={{ top: 20, right: 0, left: -20, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border))" />
                    <XAxis dataKey="period" tickLine={false} axisLine={false} />
                    <YAxis tickFormatter={(val) => `${formatNumber(val/1000, { decimals: 0 })}k`} tickLine={false} axisLine={false} />
                    <Tooltip
                      formatter={(value: number) => [`${formatNumber(value, { decimals: 0 })} L`, t("fleet.mtdVolume")]}
                      cursor={{ fill: 'hsl(var(--muted))' }}
                      contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                    />
                    <Bar dataKey="liters" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} maxBarSize={50} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <div className="h-[300px] flex items-center justify-center text-muted-foreground">{t("fleet.noUsageData")}</div>
            )}
          </CardContent>
        </Card>

        <Card className="col-span-1 lg:col-span-3">
          <CardHeader>
            <CardTitle>{t("fleet.topConsumers")}</CardTitle>
            <CardDescription>{t("fleet.topConsumersDesc")}</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-5">
              {overview.topVehicles.map((vehicle, i) => (
                <div key={vehicle.vehicleId} className="flex items-center">
                  <div className="w-8 text-center font-bold text-muted-foreground">{i + 1}</div>
                  <div className="ms-2 flex-1">
                    <p className="text-sm font-medium leading-none">{vehicle.plate}</p>
                    <p className="text-xs text-muted-foreground mt-1">{vehicle.name}</p>
                  </div>
                  <div className="text-end">
                    <p className="text-sm font-bold">{formatCurrency(vehicle.spent)}</p>
                    <p className="text-xs text-muted-foreground mt-1">{formatNumber(vehicle.liters, { decimals: 0 })} L</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <CardTitle>{t("fleet.fleetVehicles")}</CardTitle>
            <CardDescription>{t("fleet.fleetVehiclesDesc")}</CardDescription>
          </div>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>{t("fleet.col.plate")}</TableHead>
                  <TableHead>{t("fleet.col.driver")}</TableHead>
                  <TableHead>{t("fleet.col.department")}</TableHead>
                  <TableHead className="text-end">{t("fleet.col.mtdSpent")}</TableHead>
                  <TableHead>{t("fleet.col.status")}</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {vehicles?.map((vehicle) => (
                  <TableRow key={vehicle.id}>
                    <TableCell>
                      <div className="font-medium font-mono">{vehicle.plate}</div>
                      <div className="text-xs text-muted-foreground">{vehicle.make} {vehicle.model}</div>
                    </TableCell>
                    <TableCell>{vehicle.driver}</TableCell>
                    <TableCell>{vehicle.department}</TableCell>
                    <TableCell className="text-end font-medium">{formatCurrency(vehicle.monthlySpent)}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className={
                        vehicle.status === 'active' ? 'bg-green-50 text-green-700 border-green-200 dark:bg-green-900/30 dark:text-green-400' :
                        vehicle.status === 'idle' ? 'bg-muted text-muted-foreground' :
                        'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-900/30 dark:text-amber-400'
                      }>
                        {getStatusLabel(vehicle.status)}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function FuelIcon(props: any) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <line x1="3" x2="15" y1="22" y2="22" />
      <line x1="4" x2="14" y1="9" y2="9" />
      <path d="M14 22V4a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v18" />
      <path d="M14 13h2a2 2 0 0 1 2 2v2a2 2 0 0 0 2 2h0a2 2 0 0 0 2-2V9.83a2 2 0 0 0-.59-1.42L18 5" />
    </svg>
  );
}
