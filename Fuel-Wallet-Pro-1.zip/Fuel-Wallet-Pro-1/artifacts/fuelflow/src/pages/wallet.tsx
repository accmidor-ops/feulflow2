import { useGetWallet, useListWalletTransactions, useRechargeWallet, getGetWalletQueryKey, getListWalletTransactionsQueryKey } from "@workspace/api-client-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useState } from "react";
import { Wallet, Plus, CreditCard, Smartphone, ArrowDownRight, ArrowUpRight, History } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { ListSkeleton } from "@/components/ui/loading-skeleton";
import { ErrorState } from "@/components/ui/empty-state";
import { useLanguage } from "@/lib/i18n";

const MIN_RECHARGE = 100;

export default function WalletPage() {
  const { data: wallet, isLoading: isLoadingWallet, isError: isErrorWallet } = useGetWallet();
  const { data: transactions, isLoading: isLoadingTxs } = useListWalletTransactions();

  const [isRechargeOpen, setIsRechargeOpen] = useState(false);
  const [amount, setAmount] = useState("500");
  const [method, setMethod] = useState<"mada" | "visa" | "apple_pay" | "stc_pay">("mada");

  const queryClient = useQueryClient();
  const { toast } = useToast();
  const { t, formatCurrency, formatNumber, dateLocale } = useLanguage();

  const rechargeMutation = useRechargeWallet({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetWalletQueryKey() });
        queryClient.invalidateQueries({ queryKey: getListWalletTransactionsQueryKey() });
        setIsRechargeOpen(false);
        toast({
          title: t("toast.recharge.success.title"),
          description: t("toast.recharge.success.desc", {
            amount: formatCurrency(parseFloat(amount)),
            method: t(`method.${method}` as any),
          }),
        });
        setAmount("500");
      },
      onError: () => {
        toast({
          title: t("toast.recharge.failed.title"),
          description: t("toast.recharge.failed.desc"),
          variant: "destructive"
        });
      }
    }
  });

  const handleRecharge = (e: React.FormEvent) => {
    e.preventDefault();
    rechargeMutation.mutate({
      data: {
        amount: parseFloat(amount),
        method
      }
    });
  };

  if (isLoadingWallet) return <ListSkeleton />;
  if (isErrorWallet || !wallet) return <ErrorState title={t("error.wallet")} />;

  const progressPercentage = Math.min((wallet.monthlySpent / wallet.monthlyLimit) * 100, 100);

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">{t("wallet.title")}</h1>
        <p className="text-muted-foreground">{t("wallet.subtitle")}</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card className="bg-primary text-primary-foreground border-none overflow-hidden relative">
          <div className="absolute top-0 end-0 p-6 opacity-10">
            <Wallet className="h-32 w-32" />
          </div>
          <CardHeader className="pb-2">
            <CardTitle className="text-primary-foreground/80 font-medium text-sm flex items-center gap-2">
              <CreditCard className="h-4 w-4" />
              {t("wallet.availableBalance")}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="text-4xl font-bold tracking-tight">
              {formatCurrency(wallet.balance)}
            </div>

            <div className="pt-4 flex items-center justify-between">
              <div>
                <p className="text-xs text-primary-foreground/70 uppercase tracking-wider mb-1">{t("wallet.cardHolder")}</p>
                <p className="font-medium">{wallet.cardHolder}</p>
              </div>
              <div className="text-end">
                <p className="text-xs text-primary-foreground/70 uppercase tracking-wider mb-1">{t("wallet.cardNumber")}</p>
                <p className="font-medium font-mono" dir="ltr">{wallet.cardNumber}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="space-y-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">{t("wallet.monthlyLimitUsage")}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex justify-between items-end mb-2">
                <div className="text-2xl font-bold">{formatCurrency(wallet.monthlySpent)}</div>
                <div className="text-sm text-muted-foreground">/ {formatCurrency(wallet.monthlyLimit)}</div>
              </div>
              <div className="h-3 w-full bg-secondary rounded-full overflow-hidden">
                <div
                  className={`h-full ${progressPercentage > 90 ? 'bg-destructive' : 'bg-primary'} transition-all`}
                  style={{ width: `${progressPercentage}%` }}
                />
              </div>
              <p className="text-xs text-muted-foreground mt-2 text-end">
                {t("wallet.percentUsed", { percent: formatNumber(progressPercentage, { decimals: 1 }) })}
              </p>
            </CardContent>
          </Card>

          <Dialog open={isRechargeOpen} onOpenChange={setIsRechargeOpen}>
            <DialogTrigger asChild>
              <Button className="w-full h-12 text-base">
                <Plus className="me-2 h-5 w-5" />
                {t("wallet.recharge")}
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px]">
              <form onSubmit={handleRecharge}>
                <DialogHeader>
                  <DialogTitle>{t("wallet.recharge.title")}</DialogTitle>
                  <DialogDescription>
                    {t("wallet.recharge.desc", { min: formatCurrency(MIN_RECHARGE) })}
                  </DialogDescription>
                </DialogHeader>
                <div className="grid gap-6 py-4">
                  <div className="grid gap-2">
                    <Label htmlFor="amount">{t("wallet.recharge.amount")}</Label>
                    <div className="flex items-center gap-2">
                      <Input
                        id="amount"
                        type="number"
                        min={String(MIN_RECHARGE)}
                        step="50"
                        value={amount}
                        onChange={(e) => setAmount(e.target.value)}
                        className="text-lg font-medium"
                        required
                      />
                    </div>
                    <div className="flex gap-2 mt-2">
                      {["200", "500", "1000"].map((preset) => (
                        <Button
                          key={preset}
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => setAmount(preset)}
                          className={amount === preset ? "border-primary bg-primary/10" : ""}
                        >
                          +{preset}
                        </Button>
                      ))}
                    </div>
                  </div>

                  <div className="grid gap-3">
                    <Label>{t("wallet.method.label")}</Label>
                    <RadioGroup value={method} onValueChange={(val: any) => setMethod(val)} className="grid grid-cols-2 gap-4">
                      <div>
                        <RadioGroupItem value="mada" id="mada" className="peer sr-only" />
                        <Label
                          htmlFor="mada"
                          className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary"
                        >
                          <CreditCard className="mb-2 h-6 w-6" />
                          {t("method.mada")}
                        </Label>
                      </div>
                      <div>
                        <RadioGroupItem value="apple_pay" id="apple_pay" className="peer sr-only" />
                        <Label
                          htmlFor="apple_pay"
                          className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary"
                        >
                          <Smartphone className="mb-2 h-6 w-6" />
                          {t("method.apple_pay")}
                        </Label>
                      </div>
                      <div>
                        <RadioGroupItem value="visa" id="visa" className="peer sr-only" />
                        <Label
                          htmlFor="visa"
                          className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary"
                        >
                          <CreditCard className="mb-2 h-6 w-6" />
                          {t("method.visa")}
                        </Label>
                      </div>
                      <div>
                        <RadioGroupItem value="stc_pay" id="stc_pay" className="peer sr-only" />
                        <Label
                          htmlFor="stc_pay"
                          className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary"
                        >
                          <Smartphone className="mb-2 h-6 w-6" />
                          {t("method.stc_pay")}
                        </Label>
                      </div>
                    </RadioGroup>
                  </div>
                </div>
                <DialogFooter>
                  <Button type="button" variant="ghost" onClick={() => setIsRechargeOpen(false)}>{t("common.cancel")}</Button>
                  <Button type="submit" disabled={rechargeMutation.isPending || parseFloat(amount) < MIN_RECHARGE}>
                    {rechargeMutation.isPending ? t("common.processing") : t("wallet.recharge.pay", { amount: formatCurrency(parseFloat(amount) || 0) })}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <History className="h-5 w-5" />
            {t("wallet.ledger")}
          </CardTitle>
          <CardDescription>{t("wallet.ledger.desc")}</CardDescription>
        </CardHeader>
        <CardContent>
          {isLoadingTxs ? (
            <div className="py-8 text-center text-muted-foreground">{t("wallet.ledger.loading")}</div>
          ) : transactions && transactions.length > 0 ? (
            <div className="space-y-4">
              {transactions.map((tx) => (
                <div key={tx.id} className="flex items-center justify-between py-3 border-b last:border-0 last:pb-0">
                  <div className="flex items-center gap-4">
                    <div className={`h-10 w-10 rounded-full flex items-center justify-center ${
                      tx.type === 'recharge' ? 'bg-green-100 text-green-600 dark:bg-green-900/30' : 'bg-secondary text-secondary-foreground'
                    }`}>
                      {tx.type === 'recharge' ? <ArrowDownRight className="h-5 w-5" /> : <ArrowUpRight className="h-5 w-5" />}
                    </div>
                    <div>
                      <p className="font-medium">{tx.description}</p>
                      <div className="flex items-center gap-2 text-xs text-muted-foreground mt-0.5">
                        <span>{format(new Date(tx.createdAt), "MMM d, yyyy h:mm a", { locale: dateLocale })}</span>
                        <span>•</span>
                        <span>{t(`method.${tx.method}` as any)}</span>
                      </div>
                    </div>
                  </div>
                  <div className={`font-bold ${tx.type === 'recharge' ? 'text-green-600' : ''}`}>
                    {tx.type === 'recharge' ? '+' : '-'} {formatCurrency(tx.amount)}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="py-8 text-center text-muted-foreground">
              {t("wallet.ledger.empty")}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
