import {
  useGetDashboardSummary,
  useGetWallet
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { DashboardSkeleton } from "@/components/ui/loading-skeleton";
import { ErrorState } from "@/components/ui/empty-state";
import {
  Wallet,
  Droplet,
  CreditCard,
  TrendingDown,
  Car,
  Fuel,
  MapPin,
  QrCode,
  Receipt
} from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";
import { format } from "date-fns";
import { useLanguage } from "@/lib/i18n";

export default function Dashboard() {
  const { data: summary, isLoading: isLoadingSummary, isError: isErrorSummary } = useGetDashboardSummary();
  const { data: wallet, isLoading: isLoadingWallet, isError: isErrorWallet } = useGetWallet();
  const { t, formatCurrency, formatNumber, dateLocale } = useLanguage();

  if (isLoadingSummary || isLoadingWallet) {
    return <DashboardSkeleton />;
  }

  if (isErrorSummary || isErrorWallet || !summary || !wallet) {
    return <ErrorState title={t("error.dashboard")} />;
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">{t("dashboard.title")}</h1>
          <p className="text-muted-foreground">{t("dashboard.subtitle")}</p>
        </div>
        <div className="flex gap-2">
          <Link href="/fuel">
            <Button size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90">
              <QrCode className="mr-2 h-5 w-5" />
              {t("dashboard.payAtPump")}
            </Button>
          </Link>
          <Link href="/stations">
            <Button variant="outline" size="lg">
              <MapPin className="mr-2 h-5 w-5" />
              {t("dashboard.findStation")}
            </Button>
          </Link>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className="bg-primary text-primary-foreground">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">{t("dashboard.walletBalance")}</CardTitle>
            <Wallet className="h-4 w-4 opacity-75" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(wallet.balance)}</div>
            <p className="text-xs opacity-75 mt-1">
              {t("dashboard.monthlyLimit", { limit: formatCurrency(wallet.monthlyLimit) })}
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
            <CardTitle className="text-sm font-medium">{t("dashboard.monthlySpend")}</CardTitle>
            <CreditCard className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(summary.totalSpentMtd)}</div>
            <p className="text-xs text-muted-foreground mt-1">
              {t("dashboard.txCount", { count: summary.transactionCountMtd })}
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
            <CardTitle className="text-sm font-medium">{t("dashboard.fuelConsumed")}</CardTitle>
            <Droplet className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatNumber(summary.totalLitersMtd, { decimals: 1 })} L</div>
            <p className="text-xs text-muted-foreground mt-1">
              {t("dashboard.avgPrice", { price: formatCurrency(summary.avgPricePerLiter) })}
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
            <CardTitle className="text-sm font-medium">{t("dashboard.avgConsumption")}</CardTitle>
            <TrendingDown className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {summary.totalLitersMtd > 0 && summary.transactionCountMtd > 0
                ? formatNumber(summary.totalLitersMtd / summary.transactionCountMtd, { decimals: 1 })
                : "0"} L
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {t("dashboard.perTransaction")}
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-7">
        <Card className="col-span-1 lg:col-span-4">
          <CardHeader>
            <CardTitle>{t("dashboard.vehicleBreakdown")}</CardTitle>
            <CardDescription>
              {t("dashboard.vehicleBreakdownDesc")}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {summary.vehicleBreakdown && summary.vehicleBreakdown.length > 0 ? (
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={summary.vehicleBreakdown} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                    <XAxis dataKey="vehicleName" tickLine={false} axisLine={false} />
                    <YAxis tickFormatter={(val) => formatCurrency(val, { decimals: 0 })} tickLine={false} axisLine={false} />
                    <Tooltip
                      formatter={(value: number) => [formatCurrency(value), t("dashboard.spent")]}
                      cursor={{ fill: 'hsl(var(--muted))' }}
                      contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                    />
                    <Bar
                      dataKey="spent"
                      fill="hsl(var(--primary))"
                      radius={[4, 4, 0, 0]}
                      maxBarSize={60}
                    />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-[300px] text-muted-foreground">
                <Car className="h-12 w-12 mb-4 opacity-20" />
                <p>{t("dashboard.noVehicleData")}</p>
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="col-span-1 lg:col-span-3">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>{t("dashboard.recentTransactions")}</CardTitle>
              <CardDescription>{t("dashboard.recentTransactionsDesc")}</CardDescription>
            </div>
            <Link href="/transactions">
              <Button variant="ghost" size="sm" className="h-8 text-xs">
                {t("common.viewAll")}
              </Button>
            </Link>
          </CardHeader>
          <CardContent>
            {summary.recentTransactions && summary.recentTransactions.length > 0 ? (
              <div className="space-y-6">
                {summary.recentTransactions.map((tx) => (
                  <div key={tx.id} className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 rounded-full bg-secondary flex items-center justify-center">
                        <Fuel className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <p className="text-sm font-medium leading-none">{tx.stationName}</p>
                        <p className="text-xs text-muted-foreground mt-1">
                          {tx.vehicleName} • {format(new Date(tx.createdAt), "MMM d, h:mm a", { locale: dateLocale })}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-bold">{formatCurrency(tx.total)}</p>
                      <p className="text-xs text-muted-foreground mt-1">
                        {formatNumber(tx.liters, { decimals: 1 })} L
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-8 text-muted-foreground text-center">
                <Receipt className="h-10 w-10 mb-2 opacity-20" />
                <p className="text-sm">{t("dashboard.noRecentTransactions")}</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
