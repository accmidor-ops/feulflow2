import { useState } from "react";
import { useListSupportTickets, useCreateSupportTicket, getListSupportTicketsQueryKey } from "@workspace/api-client-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { MessageSquarePlus, Clock, CheckCircle2, AlertCircle, LifeBuoy } from "lucide-react";
import { format } from "date-fns";
import { ListSkeleton } from "@/components/ui/loading-skeleton";
import { ErrorState, EmptyState } from "@/components/ui/empty-state";
import { useLanguage } from "@/lib/i18n";

export default function Support() {
  const { data: tickets, isLoading, isError } = useListSupportTickets();
  const [isOpen, setIsOpen] = useState(false);
  const { t, dateLocale } = useLanguage();

  const queryClient = useQueryClient();
  const { toast } = useToast();

  const createMutation = useCreateSupportTicket({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListSupportTicketsQueryKey() });
        setIsOpen(false);
        toast({ title: t("support.toast.created.title"), description: t("support.toast.created.desc") });
      },
      onError: (error: any) => {
        toast({ title: t("support.toast.failed"), description: error?.data?.message, variant: "destructive" });
      }
    }
  });

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    createMutation.mutate({
      data: {
        category: formData.get("category") as any,
        subject: formData.get("subject") as string,
        message: formData.get("message") as string,
      }
    });
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'resolved': return <CheckCircle2 className="h-4 w-4 text-green-500" />;
      case 'in_progress': return <Clock className="h-4 w-4 text-amber-500" />;
      default: return <AlertCircle className="h-4 w-4 text-primary" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'resolved': return <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200 dark:bg-green-900/30 dark:text-green-400">{t("support.status.resolved")}</Badge>;
      case 'in_progress': return <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-900/30 dark:text-amber-400">{t("support.status.inProgress")}</Badge>;
      default: return <Badge className="bg-primary/10 text-primary hover:bg-primary/20 border-0">{t("support.status.open")}</Badge>;
    }
  };

  const getCategoryLabel = (category: string) => {
    switch (category) {
      case 'complaint': return t("support.cat.complaint");
      case 'suggestion': return t("support.cat.suggestion");
      default: return t("support.cat.question");
    }
  };

  if (isLoading) return <ListSkeleton />;
  if (isError) return <ErrorState title={t("error.support")} />;

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">{t("support.title")}</h1>
          <p className="text-muted-foreground">{t("support.subtitle")}</p>
        </div>

        <Dialog open={isOpen} onOpenChange={setIsOpen}>
          <DialogTrigger asChild>
            <Button>
              <MessageSquarePlus className="me-2 h-4 w-4" /> {t("support.newTicket")}
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[500px]">
            <form onSubmit={handleSubmit}>
              <DialogHeader>
                <DialogTitle>{t("support.dialog.title")}</DialogTitle>
                <DialogDescription>
                  {t("support.dialog.desc")}
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="category">{t("support.field.category")}</Label>
                  <Select name="category" defaultValue="question" required>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="question">{t("support.cat.question")}</SelectItem>
                      <SelectItem value="complaint">{t("support.cat.complaint")}</SelectItem>
                      <SelectItem value="suggestion">{t("support.cat.suggestion")}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="subject">{t("support.field.subject")}</Label>
                  <Input id="subject" name="subject" placeholder={t("support.field.subjectPlaceholder")} required />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="message">{t("support.field.message")}</Label>
                  <Textarea
                    id="message"
                    name="message"
                    placeholder={t("support.field.messagePlaceholder")}
                    className="min-h-[100px]"
                    required
                  />
                </div>
              </div>
              <DialogFooter>
                <Button type="button" variant="ghost" onClick={() => setIsOpen(false)}>{t("common.cancel")}</Button>
                <Button type="submit" disabled={createMutation.isPending}>
                  {createMutation.isPending ? t("common.submitting") : t("support.submit")}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {!tickets || tickets.length === 0 ? (
        <EmptyState
          title={t("support.empty.title")}
          description={t("support.empty.desc")}
          icon={LifeBuoy}
          actionLabel={t("support.empty.action")}
          actionOnClick={() => setIsOpen(true)}
        />
      ) : (
        <div className="grid gap-4">
          {tickets.map((ticket) => (
            <Card key={ticket.id}>
              <CardHeader className="pb-3">
                <div className="flex justify-between items-start">
                  <div className="space-y-1">
                    <CardTitle className="text-lg flex items-center gap-2">
                      {getStatusIcon(ticket.status)}
                      {ticket.subject}
                    </CardTitle>
                    <CardDescription>
                      {t("support.ticketNumber", {
                        id: ticket.id.toString().padStart(5, '0'),
                        date: format(new Date(ticket.createdAt), "MMM d, yyyy", { locale: dateLocale }),
                      })}
                    </CardDescription>
                  </div>
                  {getStatusBadge(ticket.status)}
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-foreground whitespace-pre-wrap bg-muted/30 p-4 rounded-md border border-border/50">
                  {ticket.message}
                </p>
                <div className="mt-4 flex items-center justify-between text-xs text-muted-foreground">
                  <span className="font-medium">{getCategoryLabel(ticket.category)}</span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
