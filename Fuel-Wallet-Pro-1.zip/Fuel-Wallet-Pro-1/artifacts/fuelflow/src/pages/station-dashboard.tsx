import { useState, useMemo } from "react";
import { useGetStationFinancials } from "@workspace/api-client-react";
import { useLanguage } from "@/lib/i18n";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  Cell,
  PieChart,
  Pie,
  Legend,
} from "recharts";
import { TrendingUp, TrendingDown, Minus, Fuel, ReceiptText, Droplets, Building2, Clock } from "lucide-react";
import { format, subDays, subMonths, subYears, type Locale } from "date-fns";

type Period = "30d" | "90d" | "6m" | "1y" | "all";

const STATION_COLORS = [
  "#f59e0b",
  "#f97316",
  "#10b981",
  "#3b82f6",
  "#8b5cf6",
  "#ec4899",
  "#14b8a6",
  "#6366f1",
];

const PIE_COLORS = {
  paid: "#10b981",
  inProgress: "#f59e0b",
  pending: "#ef4444",
};

function periodToDateFrom(period: Period): string | undefined {
  if (period === "all") return undefined;
  const now = new Date();
  if (period === "30d") return subDays(now, 30).toISOString();
  if (period === "90d") return subDays(now, 90).toISOString();
  if (period === "6m") return subMonths(now, 6).toISOString();
  if (period === "1y") return subYears(now, 1).toISOString();
  return undefined;
}

function formatShortName(name: string) {
  return name.replace("FuelFlow ", "");
}

function formatMonth(month: string, dateLocale: Locale) {
  try {
    const [year, mon] = month.split("-");
    return format(new Date(Number(year), Number(mon) - 1, 1), "MMM yy", { locale: dateLocale });
  } catch {
    return month;
  }
}

export default function StationDashboard() {
  const { t, formatCurrency, formatNumber, dir, dateLocale } = useLanguage();
  const [period, setPeriod] = useState<Period>("6m");

  const dateFrom = useMemo(() => periodToDateFrom(period), [period]);
  const { data, isLoading, isError } = useGetStationFinancials(
    dateFrom ? { date_from: dateFrom } : {},
  );

  const periods: Period[] = ["30d", "90d", "6m", "1y", "all"];

  const overview = data?.overview;
  const stations = data?.stations ?? [];

  const revenueByStation = useMemo(
    () =>
      [...stations]
        .sort((a, b) => b.totalRevenue - a.totalRevenue)
        .map((s, i) => ({
          name: formatShortName(s.stationName),
          revenue: s.totalRevenue,
          color: STATION_COLORS[i % STATION_COLORS.length],
        })),
    [stations],
  );

  const networkTrend = useMemo(
    () =>
      (overview?.monthlyTrend ?? []).map((row) => ({
        month: formatMonth(row.month, dateLocale),
        revenue: row.revenue,
        transactions: row.transactions,
      })),
    [overview, dateLocale],
  );

  const settlementPie = useMemo(() => {
    if (!overview) return [];
    const items = [
      { name: t("stationDash.settled"), value: overview.paidSettlementsAmount, fill: PIE_COLORS.paid },
      { name: t("stationDash.inProgress"), value: overview.inProgressSettlementsAmount, fill: PIE_COLORS.inProgress },
      { name: t("stationDash.pending"), value: overview.pendingSettlementsAmount, fill: PIE_COLORS.pending },
    ];
    return items.filter((i) => i.value > 0);
  }, [overview, t]);

  const hasSettlements =
    (overview?.paidSettlementsAmount ?? 0) +
      (overview?.inProgressSettlementsAmount ?? 0) +
      (overview?.pendingSettlementsAmount ?? 0) >
    0;

  if (isError) {
    return (
      <div className="flex items-center justify-center h-64 text-red-400">
        {t("error.stationDash")}
      </div>
    );
  }

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-amber-400">{t("stationDash.title")}</h1>
          <p className="mt-1 text-sm text-amber-400/50">{t("stationDash.subtitle")}</p>
        </div>
        {/* Period selector */}
        <div className="flex gap-1 rounded-lg bg-white/5 p-1 self-start">
          {periods.map((p) => (
            <button
              key={p}
              onClick={() => setPeriod(p)}
              className={`px-3 py-1.5 rounded-md text-xs font-medium transition-all ${
                period === p
                  ? "bg-amber-500 text-black"
                  : "text-amber-400/60 hover:text-amber-400 hover:bg-white/10"
              }`}
            >
              {t(`stationDash.period.${p}`)}
            </button>
          ))}
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <KpiCard
          label={t("stationDash.kpi.totalRevenue")}
          value={isLoading ? "…" : formatCurrency(overview?.totalRevenue ?? 0)}
          icon={<ReceiptText className="h-5 w-5 text-amber-300" />}
          accent="amber"
          loading={isLoading}
        />
        <KpiCard
          label={t("stationDash.kpi.transactions")}
          value={isLoading ? "…" : formatNumber(overview?.totalTransactions ?? 0)}
          icon={<Fuel className="h-5 w-5 text-sky-300" />}
          accent="sky"
          loading={isLoading}
        />
        <KpiCard
          label={t("stationDash.kpi.liters")}
          value={isLoading ? "…" : `${formatNumber(overview?.totalLiters ?? 0)} L`}
          icon={<Droplets className="h-5 w-5 text-teal-300" />}
          accent="teal"
          loading={isLoading}
        />
        <KpiCard
          label={t("stationDash.kpi.topStation")}
          value={isLoading ? "…" : formatShortName(overview?.topStationName ?? "—")}
          sub={isLoading ? "" : formatCurrency(overview?.topStationRevenue ?? 0)}
          icon={<Building2 className="h-5 w-5 text-fuchsia-300" />}
          accent="fuchsia"
          loading={isLoading}
        />
      </div>

      {/* Pending settlements banner */}
      {!isLoading && (overview?.pendingSettlementsAmount ?? 0) > 0 && (
        <div className="flex items-center gap-3 rounded-lg bg-amber-500/10 border border-amber-500/20 px-4 py-3">
          <Clock className="h-4 w-4 text-amber-400 shrink-0" />
          <span className="text-sm text-amber-300">
            {t("stationDash.kpi.pendingSettlements")}:{" "}
            <strong>{formatCurrency(overview!.pendingSettlementsAmount)}</strong>
          </span>
        </div>
      )}

      {/* Charts row */}
      <div className="grid gap-4 lg:grid-cols-2">
        {/* Revenue by Station */}
        <ChartCard
          title={t("stationDash.chart.revenueByStation")}
          desc={t("stationDash.chart.revenueByStationDesc")}
          loading={isLoading}
        >
          {revenueByStation.length === 0 ? (
            <EmptyChart label={t("stationDash.noData")} />
          ) : (
            <ResponsiveContainer width="100%" height={260}>
              <BarChart
                layout="vertical"
                data={revenueByStation}
                margin={{ top: 0, right: 16, bottom: 0, left: 0 }}
              >
                <CartesianGrid horizontal={false} strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
                <XAxis
                  type="number"
                  tickFormatter={(v) => `${(v / 1000).toFixed(1)}k`}
                  tick={{ fill: "rgba(255,255,255,0.4)", fontSize: 11 }}
                  axisLine={false}
                  tickLine={false}
                />
                <YAxis
                  type="category"
                  dataKey="name"
                  width={dir === "rtl" ? 80 : 100}
                  tick={{ fill: "rgba(255,255,255,0.6)", fontSize: 11 }}
                  axisLine={false}
                  tickLine={false}
                />
                <Tooltip
                  cursor={{ fill: "rgba(255,255,255,0.04)" }}
                  contentStyle={{
                    background: "#1e1e2e",
                    border: "1px solid rgba(255,255,255,0.1)",
                    borderRadius: 8,
                    fontSize: 12,
                  }}
                  labelStyle={{ color: "rgba(255,255,255,0.7)" }}
                  formatter={(v: number) => [formatCurrency(v), t("stationDash.col.revenue")]}
                />
                <Bar dataKey="revenue" radius={[0, 4, 4, 0]} maxBarSize={22}>
                  {revenueByStation.map((entry, idx) => (
                    <Cell key={idx} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          )}
        </ChartCard>

        {/* Monthly Network Revenue */}
        <ChartCard
          title={t("stationDash.chart.monthlyTrend")}
          desc={t("stationDash.chart.monthlyTrendDesc")}
          loading={isLoading}
        >
          {networkTrend.length === 0 ? (
            <EmptyChart label={t("stationDash.noData")} />
          ) : (
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={networkTrend} margin={{ top: 4, right: 8, bottom: 0, left: 0 }}>
                <CartesianGrid vertical={false} strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
                <XAxis
                  dataKey="month"
                  tick={{ fill: "rgba(255,255,255,0.4)", fontSize: 11 }}
                  axisLine={false}
                  tickLine={false}
                />
                <YAxis
                  tickFormatter={(v) => `${(v / 1000).toFixed(1)}k`}
                  tick={{ fill: "rgba(255,255,255,0.4)", fontSize: 11 }}
                  axisLine={false}
                  tickLine={false}
                  width={40}
                />
                <Tooltip
                  cursor={{ fill: "rgba(255,255,255,0.04)" }}
                  contentStyle={{
                    background: "#1e1e2e",
                    border: "1px solid rgba(255,255,255,0.1)",
                    borderRadius: 8,
                    fontSize: 12,
                  }}
                  labelStyle={{ color: "rgba(255,255,255,0.7)" }}
                  formatter={(v: number, name: string) => [
                    name === "revenue" ? formatCurrency(v) : formatNumber(v),
                    name === "revenue" ? t("stationDash.col.revenue") : t("stationDash.col.transactions"),
                  ]}
                />
                <Bar dataKey="revenue" fill="#f59e0b" radius={[4, 4, 0, 0]} maxBarSize={36} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </ChartCard>
      </div>

      {/* Settlement Status + Station cards row */}
      <div className="grid gap-4 lg:grid-cols-3">
        {/* Settlement pie */}
        <ChartCard
          title={t("stationDash.chart.settlementStatus")}
          desc={t("stationDash.chart.settlementStatusDesc")}
          loading={isLoading}
        >
          {!hasSettlements ? (
            <EmptyChart label={t("stationDash.noData")} />
          ) : (
            <ResponsiveContainer width="100%" height={220}>
              <PieChart>
                <Pie
                  data={settlementPie}
                  cx="50%"
                  cy="50%"
                  innerRadius={55}
                  outerRadius={80}
                  paddingAngle={3}
                  dataKey="value"
                >
                  {settlementPie.map((entry, idx) => (
                    <Cell key={idx} fill={entry.fill} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    background: "#1e1e2e",
                    border: "1px solid rgba(255,255,255,0.1)",
                    borderRadius: 8,
                    fontSize: 12,
                  }}
                  formatter={(v: number) => [formatCurrency(v)]}
                />
                <Legend
                  iconType="circle"
                  iconSize={8}
                  formatter={(value) => (
                    <span style={{ color: "rgba(255,255,255,0.6)", fontSize: 11 }}>{value}</span>
                  )}
                />
              </PieChart>
            </ResponsiveContainer>
          )}
          {hasSettlements && (
            <div className="mt-3 space-y-2">
              {[
                { label: t("stationDash.settled"), val: overview?.paidSettlementsAmount ?? 0, color: "bg-emerald-500" },
                { label: t("stationDash.inProgress"), val: overview?.inProgressSettlementsAmount ?? 0, color: "bg-amber-500" },
                { label: t("stationDash.pending"), val: overview?.pendingSettlementsAmount ?? 0, color: "bg-red-500" },
              ]
                .filter((r) => r.val > 0)
                .map((row) => (
                  <div key={row.label} className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <span className={`h-2 w-2 rounded-full ${row.color}`} />
                      <span className="text-amber-400/60">{row.label}</span>
                    </div>
                    <span className="text-amber-400/80 font-medium">{formatCurrency(row.val)}</span>
                  </div>
                ))}
            </div>
          )}
        </ChartCard>

        {/* Station performance table */}
        <div className="lg:col-span-2 rounded-xl bg-white/5 border border-white/10 p-5">
          <div className="mb-4">
            <h3 className="text-sm font-semibold text-amber-400">{t("stationDash.stations.title")}</h3>
            <p className="text-xs text-amber-400/40 mt-0.5">{t("stationDash.stations.desc")}</p>
          </div>

          {isLoading ? (
            <div className="space-y-3">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="h-9 rounded-md bg-white/5 animate-pulse" />
              ))}
            </div>
          ) : stations.length === 0 ? (
            <p className="text-sm text-amber-400/40 text-center py-8">{t("stationDash.noData")}</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-white/10">
                    <th className="pb-2 text-start text-xs font-medium text-amber-400/40">
                      {t("stationDash.col.station")}
                    </th>
                    <th className="pb-2 text-end text-xs font-medium text-amber-400/40">
                      {t("stationDash.col.revenue")}
                    </th>
                    <th className="pb-2 text-end text-xs font-medium text-amber-400/40 hidden sm:table-cell">
                      {t("stationDash.col.transactions")}
                    </th>
                    <th className="pb-2 text-end text-xs font-medium text-amber-400/40 hidden md:table-cell">
                      {t("stationDash.col.avgTx")}
                    </th>
                    <th className="pb-2 text-end text-xs font-medium text-amber-400/40 hidden sm:table-cell">
                      {t("stationDash.col.thisMonth")}
                    </th>
                    <th className="pb-2 text-end text-xs font-medium text-amber-400/40">
                      {t("stationDash.col.change")}
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {stations.map((s, idx) => {
                    const change = s.revenueChange;
                    const changeColor =
                      change > 0 ? "text-emerald-400" : change < 0 ? "text-red-400" : "text-amber-400/40";
                    const ChangeIcon =
                      change > 0 ? TrendingUp : change < 0 ? TrendingDown : Minus;
                    return (
                      <tr key={s.stationId} className="group hover:bg-white/[0.02]">
                        <td className="py-2.5 pe-3">
                          <div className="flex items-center gap-2">
                            <span
                              className="h-2 w-2 rounded-full shrink-0"
                              style={{ background: STATION_COLORS[idx % STATION_COLORS.length] }}
                            />
                            <span className="font-medium text-amber-400/80 truncate max-w-[120px]">
                              {formatShortName(s.stationName)}
                            </span>
                          </div>
                        </td>
                        <td className="py-2.5 text-end text-amber-400 font-medium tabular-nums">
                          {formatCurrency(s.totalRevenue)}
                        </td>
                        <td className="py-2.5 text-end text-amber-400/60 hidden sm:table-cell tabular-nums">
                          {formatNumber(s.totalTransactions)}
                        </td>
                        <td className="py-2.5 text-end text-amber-400/60 hidden md:table-cell tabular-nums">
                          {formatCurrency(s.avgTransactionValue)}
                        </td>
                        <td className="py-2.5 text-end text-amber-400/60 hidden sm:table-cell tabular-nums">
                          {formatCurrency(s.thisMonthRevenue)}
                        </td>
                        <td className="py-2.5 text-end">
                          <span
                            className={`inline-flex items-center gap-1 text-xs font-medium ${changeColor}`}
                          >
                            <ChangeIcon className="h-3 w-3" />
                            {change !== 0 ? `${Math.abs(change)}%` : "—"}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {/* Per-station sparkline cards */}
      <div>
        <h2 className="text-sm font-semibold text-amber-400/60 mb-3 uppercase tracking-wide">
          {t("stationDash.stations.title")}
        </h2>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {isLoading
            ? [...Array(8)].map((_, i) => (
                <div key={i} className="h-40 rounded-xl bg-white/5 animate-pulse" />
              ))
            : stations.map((s, idx) => (
                <StationCard
                  key={s.stationId}
                  station={s}
                  color={STATION_COLORS[idx % STATION_COLORS.length]}
                  formatCurrency={formatCurrency}
                  formatNumber={formatNumber}
                  t={t}
                />
              ))}
        </div>
      </div>
    </div>
  );
}

type Accent = "amber" | "sky" | "teal" | "fuchsia";

const ACCENT_STYLES: Record<Accent, { bg: string; border: string; iconBg: string; glow: string }> = {
  amber: {
    bg: "bg-gradient-to-br from-amber-500/15 via-amber-500/5 to-transparent",
    border: "border-amber-500/30",
    iconBg: "bg-amber-500/20",
    glow: "shadow-[0_0_25px_-10px_rgba(245,158,11,0.5)]",
  },
  sky: {
    bg: "bg-gradient-to-br from-sky-500/15 via-sky-500/5 to-transparent",
    border: "border-sky-500/30",
    iconBg: "bg-sky-500/20",
    glow: "shadow-[0_0_25px_-10px_rgba(56,189,248,0.5)]",
  },
  teal: {
    bg: "bg-gradient-to-br from-teal-500/15 via-teal-500/5 to-transparent",
    border: "border-teal-500/30",
    iconBg: "bg-teal-500/20",
    glow: "shadow-[0_0_25px_-10px_rgba(20,184,166,0.5)]",
  },
  fuchsia: {
    bg: "bg-gradient-to-br from-fuchsia-500/15 via-fuchsia-500/5 to-transparent",
    border: "border-fuchsia-500/30",
    iconBg: "bg-fuchsia-500/20",
    glow: "shadow-[0_0_25px_-10px_rgba(217,70,239,0.5)]",
  },
};

function KpiCard({
  label,
  value,
  sub,
  icon,
  accent,
  loading,
}: {
  label: string;
  value: string;
  sub?: string;
  icon: React.ReactNode;
  accent: Accent;
  loading: boolean;
}) {
  const styles = ACCENT_STYLES[accent];
  return (
    <div
      className={`relative overflow-hidden rounded-xl border p-4 flex flex-col gap-3 ${styles.bg} ${styles.border} ${styles.glow}`}
    >
      <div className="flex items-center justify-between">
        <span className="text-xs text-amber-400/60 font-medium">{label}</span>
        <div className={`p-2 rounded-lg ${styles.iconBg}`}>{icon}</div>
      </div>
      {loading ? (
        <div className="h-7 w-28 rounded bg-white/10 animate-pulse" />
      ) : (
        <div>
          <div className="text-2xl font-bold text-amber-400">{value}</div>
          {sub && <div className="text-xs text-amber-400/50 mt-1">{sub}</div>}
        </div>
      )}
    </div>
  );
}

function ChartCard({
  title,
  desc,
  loading,
  children,
}: {
  title: string;
  desc: string;
  loading: boolean;
  children: React.ReactNode;
}) {
  return (
    <div className="rounded-xl bg-white/5 border border-white/10 p-5">
      <div className="mb-4">
        <h3 className="text-sm font-semibold text-amber-400">{title}</h3>
        <p className="text-xs text-amber-400/40 mt-0.5">{desc}</p>
      </div>
      {loading ? (
        <div className="h-[260px] rounded-lg bg-white/5 animate-pulse" />
      ) : (
        children
      )}
    </div>
  );
}

function EmptyChart({ label }: { label: string }) {
  return (
    <div className="flex h-[260px] items-center justify-center text-sm text-amber-400/30">{label}</div>
  );
}

function StationCard({
  station,
  color,
  formatCurrency,
  formatNumber,
  t,
}: {
  station: {
    stationId: number;
    stationName: string;
    city: string;
    totalRevenue: number;
    totalTransactions: number;
    totalLiters: number;
    revenueChange: number;
    pendingAmount: number;
    inProgressAmount: number;
    paidAmount: number;
    monthlyTrend: { month: string; revenue: number; transactions: number; liters: number }[];
  };
  color: string;
  formatCurrency: (v: number) => string;
  formatNumber: (v: number) => string;
  t: (k: string) => string;
}) {
  const change = station.revenueChange;
  const changeColor =
    change > 0 ? "text-emerald-400" : change < 0 ? "text-red-400" : "text-amber-400/40";
  const ChangeIcon = change > 0 ? TrendingUp : change < 0 ? TrendingDown : Minus;

  return (
    <div
      className="relative overflow-hidden rounded-xl border border-white/10 p-4 flex flex-col gap-3 bg-white/5 transition-all hover:border-white/20"
      style={{
        backgroundImage: `linear-gradient(135deg, ${color}22 0%, transparent 60%)`,
      }}
    >
      <span
        className="absolute inset-y-0 start-0 w-1"
        style={{ background: color }}
        aria-hidden
      />
      {/* Header */}
      <div className="flex items-start justify-between gap-2 ps-2">
        <div className="flex items-center gap-2 min-w-0">
          <span
            className="h-2.5 w-2.5 rounded-full shrink-0 ring-2 ring-offset-2 ring-offset-[#0f0f1a]"
            style={{ background: color, boxShadow: `0 0 8px ${color}` }}
          />
          <span className="text-sm font-semibold text-amber-400 truncate">
            {formatShortName(station.stationName)}
          </span>
        </div>
        <span className={`inline-flex items-center gap-0.5 text-xs font-medium shrink-0 ${changeColor}`}>
          <ChangeIcon className="h-3 w-3" />
          {change !== 0 ? `${Math.abs(change)}%` : "—"}
        </span>
      </div>

      {/* Revenue */}
      <div className="ps-2">
        <div className="text-xl font-bold text-amber-400" style={{ color }}>
          {formatCurrency(station.totalRevenue)}
        </div>
        <div className="text-xs text-amber-400/50 mt-0.5">{station.city}</div>
      </div>

      {/* Sparkline */}
      <div className="h-14">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={station.monthlyTrend} margin={{ top: 2, right: 2, bottom: 2, left: 2 }}>
            <Line
              type="monotone"
              dataKey="revenue"
              stroke={color}
              strokeWidth={2}
              dot={false}
              isAnimationActive={false}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-2 gap-2 border-t border-white/10 pt-3">
        <Stat label={t("stationDash.col.transactions")} value={formatNumber(station.totalTransactions)} />
        <Stat label={t("stationDash.col.liters")} value={`${formatNumber(station.totalLiters)}L`} />
      </div>

      {/* Settlement mini */}
      {(station.pendingAmount > 0 || station.inProgressAmount > 0 || station.paidAmount > 0) && (
        <div className="flex gap-2 flex-wrap">
          {station.paidAmount > 0 && (
            <Badge color="emerald">{`${t("stationDash.settled")} ${formatCurrency(station.paidAmount)}`}</Badge>
          )}
          {station.inProgressAmount > 0 && (
            <Badge color="amber">{`${t("stationDash.inProgress")} ${formatCurrency(station.inProgressAmount)}`}</Badge>
          )}
          {station.pendingAmount > 0 && (
            <Badge color="red">{`${t("stationDash.pending")} ${formatCurrency(station.pendingAmount)}`}</Badge>
          )}
        </div>
      )}
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <div className="text-xs text-amber-400/40">{label}</div>
      <div className="text-sm font-medium text-amber-400/80 mt-0.5 tabular-nums">{value}</div>
    </div>
  );
}

function Badge({ color, children }: { color: "emerald" | "amber" | "red"; children: React.ReactNode }) {
  const cls = {
    emerald: "bg-emerald-500/10 text-emerald-400",
    amber: "bg-amber-500/10 text-amber-400",
    red: "bg-red-500/10 text-red-400",
  }[color];
  return (
    <span className={`inline-block rounded px-1.5 py-0.5 text-[10px] font-medium ${cls}`}>
      {children}
    </span>
  );
}
