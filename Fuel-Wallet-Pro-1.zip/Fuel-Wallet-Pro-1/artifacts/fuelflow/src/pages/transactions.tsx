import { useState } from "react";
import { useListTransactions, useListVehicles } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ListSkeleton } from "@/components/ui/loading-skeleton";
import { ErrorState, EmptyState } from "@/components/ui/empty-state";
import { format } from "date-fns";
import { Receipt, Fuel, Filter, Calendar } from "lucide-react";
import { useLanguage } from "@/lib/i18n";

export default function Transactions() {
  const [selectedVehicleId, setSelectedVehicleId] = useState<string>("all");
  const { t, formatCurrency, formatNumber, dateLocale } = useLanguage();

  const { data: vehicles } = useListVehicles();

  const { data: transactions, isLoading: isLoadingTxs, isError } = useListTransactions(
    selectedVehicleId !== "all" ? { vehicleId: parseInt(selectedVehicleId) } : undefined
  );

  if (isError) return <ErrorState title={t("error.transactions")} />;

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">{t("transactions.title")}</h1>
          <p className="text-muted-foreground">{t("transactions.subtitle")}</p>
        </div>

        <div className="flex items-center gap-2">
          <Filter className="h-4 w-4 text-muted-foreground" />
          <Select value={selectedVehicleId} onValueChange={setSelectedVehicleId}>
            <SelectTrigger className="w-[200px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">{t("transactions.allVehicles")}</SelectItem>
              {vehicles?.map(v => (
                <SelectItem key={v.id} value={v.id.toString()}>{v.name} ({v.plate})</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>{t("transactions.history")}</CardTitle>
          <CardDescription>
            {selectedVehicleId === "all" ? t("transactions.allVehicles") : vehicles?.find(v => v.id.toString() === selectedVehicleId)?.name}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoadingTxs ? (
            <ListSkeleton />
          ) : !transactions || transactions.length === 0 ? (
            <EmptyState
              title={t("transactions.empty.title")}
              description={t("transactions.empty.desc")}
              icon={Receipt}
            />
          ) : (
            <div className="space-y-4">
              {transactions.map((tx) => (
                <div key={tx.id} className="flex flex-col sm:flex-row sm:items-center justify-between py-4 border-b last:border-0 last:pb-0 gap-4">
                  <div className="flex items-start gap-4">
                    <div className="h-12 w-12 rounded-full bg-secondary flex items-center justify-center shrink-0">
                      <Receipt className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-base">{tx.stationName}</h4>
                      <div className="flex flex-col sm:flex-row sm:items-center gap-1 sm:gap-4 text-sm text-muted-foreground mt-1">
                        <span className="flex items-center gap-1">
                          <Fuel className="h-3.5 w-3.5" />
                          {t("transactions.fuelLine", {
                            fuelType: t(`fuelType.${tx.fuelType}` as any),
                            liters: formatNumber(tx.liters, { decimals: 1 }),
                            price: formatCurrency(tx.pricePerLiter),
                          })}
                        </span>
                      </div>
                      <div className="flex flex-col sm:flex-row sm:items-center gap-1 sm:gap-4 text-sm text-muted-foreground mt-1">
                        <span className="flex items-center gap-1">
                          <Calendar className="h-3.5 w-3.5" />
                          {format(new Date(tx.createdAt), "MMM d, yyyy h:mm a", { locale: dateLocale })}
                        </span>
                        <span className="hidden sm:inline">•</span>
                        <span className="font-medium text-foreground">{tx.vehicleName}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex sm:flex-col items-center sm:items-end justify-between sm:justify-center w-full sm:w-auto ps-16 sm:ps-0">
                    <span className="text-sm font-medium text-muted-foreground sm:hidden">{t("transactions.total")}</span>
                    <span className="text-lg font-bold">{formatCurrency(tx.total)}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
