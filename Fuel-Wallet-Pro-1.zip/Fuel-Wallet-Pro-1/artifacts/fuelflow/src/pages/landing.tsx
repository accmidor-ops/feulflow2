import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { MapPin, Wallet, QrCode, BarChart3, Shield, Zap } from "lucide-react";

const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");

export default function Landing() {
  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="h-8 w-8 rounded-lg bg-primary flex items-center justify-center">
            <svg viewBox="0 0 24 24" fill="none" className="h-5 w-5 text-primary-foreground">
              <path d="M12 22C12 22 4 15 4 9C4 5.13 7.58 2 12 2C16.42 2 20 5.13 20 9C20 15 12 22 12 22Z" fill="currentColor"/>
              <path d="M12 15C12 15 8 11.5 8 9C8 6.79 9.79 5 12 5C14.21 5 16 6.79 16 9C16 11.5 12 15 12 15Z" fill="#FDE68A"/>
            </svg>
          </div>
          <span className="text-xl font-bold">FuelFlow</span>
        </div>
        <div className="flex gap-3">
          <Link href="/sign-in">
            <Button variant="ghost">Sign In</Button>
          </Link>
          <Link href="/sign-up">
            <Button>Get Started</Button>
          </Link>
        </div>
      </header>

      <main className="px-6 py-16 max-w-5xl mx-auto space-y-20">
        <section className="text-center space-y-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-sm font-medium border border-primary/20">
            <Zap className="h-3.5 w-3.5" />
            Egypt's Smart Fuel Network
          </div>
          <h1 className="text-4xl md:text-6xl font-bold tracking-tight leading-tight">
            Smart fuel management<br />
            <span className="text-primary">for Egypt</span>
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto leading-relaxed">
            Pay at the pump with QR codes, track your fleet consumption, manage your digital wallet in EGP, and get detailed reports — all in one platform.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center pt-4">
            <Link href="/sign-up">
              <Button size="lg" className="w-full sm:w-auto text-base px-8">Create Free Account</Button>
            </Link>
            <Link href="/sign-in">
              <Button size="lg" variant="outline" className="w-full sm:w-auto text-base px-8">Sign In</Button>
            </Link>
          </div>
        </section>

        <section className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[
            {
              icon: QrCode,
              title: "Pay at Pump",
              desc: "Generate a QR code on your phone and pay contactlessly at any FuelFlow station across Egypt.",
            },
            {
              icon: Wallet,
              title: "Digital Wallet",
              desc: "Manage your EGP balance, set monthly limits, and recharge via Meeza, Visa, Apple Pay, or InstaPay.",
            },
            {
              icon: MapPin,
              title: "Station Network",
              desc: "Find the nearest partner stations in Cairo, Alexandria, Giza, and more with live pricing.",
            },
            {
              icon: BarChart3,
              title: "Reports & Analytics",
              desc: "Export Excel and PDF reports. Get monthly consumption summaries delivered to your email.",
            },
            {
              icon: Shield,
              title: "B2B Fleet Management",
              desc: "Manage your company fleet, track drivers, set spending limits, and generate invoices.",
            },
            {
              icon: Zap,
              title: "Arabic & English",
              desc: "Full bilingual support with complete RTL Arabic interface and Egyptian locale formatting.",
            },
          ].map((feature) => (
            <div key={feature.title} className="p-6 rounded-xl border border-border bg-card space-y-3">
              <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                <feature.icon className="h-5 w-5 text-primary" />
              </div>
              <h3 className="font-semibold text-lg">{feature.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{feature.desc}</p>
            </div>
          ))}
        </section>

        <section className="text-center space-y-4 py-12 px-8 rounded-2xl bg-primary text-primary-foreground">
          <h2 className="text-3xl font-bold">Ready to get started?</h2>
          <p className="opacity-80">Join thousands of Egyptian drivers and fleet managers using FuelFlow.</p>
          <Link href="/sign-up">
            <Button size="lg" variant="secondary" className="mt-4 text-base px-8">
              Create Your Free Account
            </Button>
          </Link>
        </section>
      </main>

      <footer className="border-t border-border px-6 py-8 text-center text-sm text-muted-foreground">
        <p>FuelFlow Egypt — Smart Fuel Management Platform</p>
      </footer>
    </div>
  );
}
