import { useState } from "react";
import { useListVehicles, useCreateVehicle, getListVehiclesQueryKey, useGetVehicleConsumption, getGetVehicleConsumptionQueryKey } from "@workspace/api-client-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Car, Plus, Settings2, Calendar, Droplets, Gauge } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { ListSkeleton } from "@/components/ui/loading-skeleton";
import { ErrorState, EmptyState } from "@/components/ui/empty-state";
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid } from "recharts";
import { useLanguage } from "@/lib/i18n";

export default function Vehicles() {
  const { data: vehicles, isLoading, isError } = useListVehicles();
  const [selectedVehicleId, setSelectedVehicleId] = useState<number | null>(null);
  const [isAddOpen, setIsAddOpen] = useState(false);

  const queryClient = useQueryClient();
  const { toast } = useToast();
  const { t } = useLanguage();

  const createMutation = useCreateVehicle({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListVehiclesQueryKey() });
        setIsAddOpen(false);
        toast({ title: t("vehicles.toast.added") });
      },
      onError: (error: any) => {
        toast({ title: t("vehicles.toast.failed"), description: error?.data?.message, variant: "destructive" });
      }
    }
  });

  const handleAddSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    createMutation.mutate({
      data: {
        name: formData.get("name") as string,
        make: formData.get("make") as string,
        model: formData.get("model") as string,
        year: parseInt(formData.get("year") as string),
        plate: formData.get("plate") as string,
        fuelType: formData.get("fuelType") as any,
        tankCapacity: parseInt(formData.get("tankCapacity") as string),
        color: formData.get("color") as string,
      }
    });
  };

  if (isLoading) return <ListSkeleton />;
  if (isError) return <ErrorState title={t("error.vehicles")} />;

  const selectedVehicle = vehicles?.find(v => v.id === selectedVehicleId) || vehicles?.[0];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">{t("vehicles.title")}</h1>
          <p className="text-muted-foreground">{t("vehicles.subtitle")}</p>
        </div>

        <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="me-2 h-4 w-4" /> {t("vehicles.add")}
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[500px]">
            <form onSubmit={handleAddSubmit}>
              <DialogHeader>
                <DialogTitle>{t("vehicles.addDialog.title")}</DialogTitle>
                <DialogDescription>{t("vehicles.addDialog.desc")}</DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">{t("vehicles.field.nickname")}</Label>
                    <Input id="name" name="name" placeholder={t("vehicles.field.nicknamePlaceholder")} required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="plate">{t("vehicles.field.plate")}</Label>
                    <Input id="plate" name="plate" placeholder={t("vehicles.field.platePlaceholder")} required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="make">{t("vehicles.field.make")}</Label>
                    <Input id="make" name="make" placeholder="Toyota" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="model">{t("vehicles.field.model")}</Label>
                    <Input id="model" name="model" placeholder="Corolla" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="year">{t("vehicles.field.year")}</Label>
                    <Input id="year" name="year" type="number" placeholder="2024" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="color">{t("vehicles.field.color")}</Label>
                    <Input id="color" name="color" placeholder={t("vehicles.field.colorPlaceholder")} required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="fuelType">{t("vehicles.field.fuelType")}</Label>
                    <Select name="fuelType" defaultValue="gasoline_91">
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="gasoline_91">{t("fuelType.gasoline_91")}</SelectItem>
                        <SelectItem value="gasoline_95">{t("fuelType.gasoline_95")}</SelectItem>
                        <SelectItem value="diesel">{t("fuelType.diesel")}</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="tankCapacity">{t("vehicles.field.tankCapacity")}</Label>
                    <Input id="tankCapacity" name="tankCapacity" type="number" placeholder="60" required />
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button type="button" variant="ghost" onClick={() => setIsAddOpen(false)}>{t("common.cancel")}</Button>
                <Button type="submit" disabled={createMutation.isPending}>
                  {createMutation.isPending ? t("common.saving") : t("vehicles.add")}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {!vehicles || vehicles.length === 0 ? (
        <EmptyState
          title={t("vehicles.empty.title")}
          description={t("vehicles.empty.desc")}
          icon={Car}
          actionLabel={t("vehicles.add")}
          actionOnClick={() => setIsAddOpen(true)}
        />
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="col-span-1 space-y-4">
            <h3 className="font-medium text-sm text-muted-foreground px-1 uppercase tracking-wider">{t("vehicles.yourGarage")}</h3>
            <div className="space-y-3">
              {vehicles.map((vehicle) => (
                <Card
                  key={vehicle.id}
                  className={`cursor-pointer transition-all hover:border-primary/50 ${selectedVehicle?.id === vehicle.id ? 'border-primary ring-1 ring-primary shadow-sm bg-primary/5' : ''}`}
                  onClick={() => setSelectedVehicleId(vehicle.id)}
                >
                  <CardContent className="p-4">
                    <div className="flex items-center gap-4">
                      <div className="h-12 w-12 rounded-lg bg-secondary flex items-center justify-center shrink-0">
                        <Car className="h-6 w-6 text-primary" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="font-bold truncate text-base">{vehicle.name}</h4>
                        <p className="text-sm text-muted-foreground truncate">{vehicle.make} {vehicle.model} • {vehicle.plate}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          <div className="col-span-1 lg:col-span-2">
            {selectedVehicle ? (
              <VehicleDetail vehicle={selectedVehicle} />
            ) : null}
          </div>
        </div>
      )}
    </div>
  );
}

function VehicleDetail({ vehicle }: { vehicle: any }) {
  const { data: consumption, isLoading } = useGetVehicleConsumption(vehicle.id, {
    query: { enabled: !!vehicle.id, queryKey: getGetVehicleConsumptionQueryKey(vehicle.id) }
  });
  const { t, formatCurrency, formatNumber, dateLocale } = useLanguage();

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <Card>
        <CardHeader className="flex flex-row items-start justify-between pb-2">
          <div>
            <CardTitle className="text-2xl">{vehicle.name}</CardTitle>
            <CardDescription>{vehicle.year} {vehicle.make} {vehicle.model} • {vehicle.color}</CardDescription>
          </div>
          <div className="px-3 py-1 bg-secondary rounded-md text-sm font-bold font-mono tracking-wider border">
            {vehicle.plate}
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4">
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground flex items-center gap-1"><Droplets className="h-3 w-3" /> {t("vehicles.detail.fuelType")}</p>
              <p className="font-medium">{t(`fuelType.${vehicle.fuelType}` as any)}</p>
            </div>
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground flex items-center gap-1"><Gauge className="h-3 w-3" /> {t("vehicles.detail.capacity")}</p>
              <p className="font-medium">{vehicle.tankCapacity} L</p>
            </div>
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground flex items-center gap-1"><Calendar className="h-3 w-3" /> {t("vehicles.detail.lastFueled")}</p>
              <p className="font-medium">{vehicle.lastFueledAt ? format(new Date(vehicle.lastFueledAt), "MMM d, yyyy", { locale: dateLocale }) : t("vehicles.detail.never")}</p>
            </div>
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground flex items-center gap-1"><Settings2 className="h-3 w-3" /> {t("vehicles.detail.avgConsumption")}</p>
              <p className="font-medium">{vehicle.avgConsumption ? `${formatNumber(vehicle.avgConsumption, { decimals: 1 })} L/100km` : t("vehicles.detail.na")}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">{t("vehicles.detail.totalSpent")}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{formatCurrency(vehicle.totalSpent)}</div>
            {consumption && (
              <p className="text-xs text-muted-foreground mt-1">
                {t("vehicles.detail.avgPerLiter", { price: formatCurrency(consumption.avgPricePerLiter) })}
              </p>
            )}
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">{t("vehicles.detail.totalLiters")}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{formatNumber(vehicle.totalLiters, { decimals: 1 })} L</div>
            {consumption && (
              <p className="text-xs text-muted-foreground mt-1">
                {t("vehicles.detail.acrossN", { count: consumption.transactionCount })}
              </p>
            )}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>{t("vehicles.detail.consumptionHistory")}</CardTitle>
          <CardDescription>{t("vehicles.detail.consumptionHistoryDesc")}</CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="h-[250px] flex items-center justify-center text-muted-foreground">{t("vehicles.detail.loadingChart")}</div>
          ) : consumption?.monthly && consumption.monthly.length > 0 ? (
            <div className="h-[250px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={consumption.monthly} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <defs>
                    <linearGradient id="colorLiters" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border))" />
                  <XAxis dataKey="month" tickLine={false} axisLine={false} tick={{ fontSize: 12 }} />
                  <YAxis tickLine={false} axisLine={false} tick={{ fontSize: 12 }} />
                  <Tooltip
                    contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                  />
                  <Area
                    type="monotone"
                    dataKey="liters"
                    stroke="hsl(var(--primary))"
                    strokeWidth={2}
                    fillOpacity={1}
                    fill="url(#colorLiters)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          ) : (
            <div className="h-[250px] flex items-center justify-center text-muted-foreground">
              {t("vehicles.detail.notEnoughData")}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
