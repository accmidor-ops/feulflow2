import { useState } from "react";
import { format } from "date-fns";
import { ar as arLocale, enUS } from "date-fns/locale";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import * as XLSX from "xlsx";
import { useLanguage } from "@/lib/i18n";
import { useListSettlements, useListStations, useCreateSettlement, useUpdateSettlement, useCalculateSettlement, getCalculateSettlementQueryKey } from "@workspace/api-client-react";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { ChevronDown, Download, Plus, RefreshCw } from "lucide-react";

const PERIOD_PRESETS: Record<string, { label: string; getDates: () => { from: Date; to: Date } }> = {
  daily: {
    label: "daily",
    getDates: () => {
      const now = new Date();
      const from = new Date(now);
      from.setHours(0, 0, 0, 0);
      const to = new Date(now);
      to.setHours(23, 59, 59, 999);
      return { from, to };
    },
  },
  weekly: {
    label: "weekly",
    getDates: () => {
      const now = new Date();
      const day = now.getDay();
      const from = new Date(now);
      from.setDate(now.getDate() - day);
      from.setHours(0, 0, 0, 0);
      const to = new Date(from);
      to.setDate(from.getDate() + 6);
      to.setHours(23, 59, 59, 999);
      return { from, to };
    },
  },
  monthly: {
    label: "monthly",
    getDates: () => {
      const now = new Date();
      const from = new Date(now.getFullYear(), now.getMonth(), 1);
      const to = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59, 999);
      return { from, to };
    },
  },
  custom: {
    label: "custom",
    getDates: () => {
      const from = new Date();
      from.setDate(from.getDate() - 30);
      from.setHours(0, 0, 0, 0);
      const to = new Date();
      to.setHours(23, 59, 59, 999);
      return { from, to };
    },
  },
};

function toDateInputValue(d: Date) {
  return d.toISOString().slice(0, 10);
}

function statusColor(status: string) {
  if (status === "paid") return "bg-green-100 text-green-800 border-green-200";
  if (status === "in_progress") return "bg-amber-100 text-amber-800 border-amber-200";
  return "bg-slate-100 text-slate-700 border-slate-200";
}

export default function Settlements() {
  const { t, formatCurrency, language } = useLanguage();
  const { toast } = useToast();
  const dateLocale = language === "ar" ? arLocale : enUS;

  const [filterStationId, setFilterStationId] = useState<string>("all");
  const [filterStatus, setFilterStatus] = useState<string>("all");

  const [dialogOpen, setDialogOpen] = useState(false);
  const [statusDialogOpen, setStatusDialogOpen] = useState(false);
  const [selectedSettlementId, setSelectedSettlementId] = useState<number | null>(null);
  const [newStatus, setNewStatus] = useState<string>("pending");

  const [calcStationId, setCalcStationId] = useState<string>("");
  const [calcPeriod, setCalcPeriod] = useState<string>("monthly");
  const [calcDateFrom, setCalcDateFrom] = useState<string>(() => {
    const d = PERIOD_PRESETS.monthly.getDates().from;
    return toDateInputValue(d);
  });
  const [calcDateTo, setCalcDateTo] = useState<string>(() => {
    const d = PERIOD_PRESETS.monthly.getDates().to;
    return toDateInputValue(d);
  });
  const [calcCommissionRate, setCalcCommissionRate] = useState("2.5");
  const [calcGatewayFeeRate, setCalcGatewayFeeRate] = useState("1.5");
  const [calcAdjustments, setCalcAdjustments] = useState("0");
  const [calcNotes, setCalcNotes] = useState("");
  const [previewRequested, setPreviewRequested] = useState(false);

  const listParams = {
    ...(filterStationId !== "all" ? { station_id: parseInt(filterStationId) } : {}),
    ...(filterStatus !== "all" ? { status: filterStatus as "pending" | "in_progress" | "paid" } : {}),
  };

  const { data: settlements = [], isLoading, refetch } = useListSettlements(listParams);
  const { data: stations = [] } = useListStations();

  const canPreview = previewRequested && !!calcStationId && !!calcDateFrom && !!calcDateTo;

  const calcParams = {
    station_id: calcStationId ? parseInt(calcStationId) : 0,
    date_from: calcDateFrom || new Date().toISOString(),
    date_to: calcDateTo || new Date().toISOString(),
    commission_rate: parseFloat(calcCommissionRate) / 100,
    gateway_fee_rate: parseFloat(calcGatewayFeeRate) / 100,
    adjustments: parseFloat(calcAdjustments) || 0,
  };

  const { data: preview, isFetching: isPreviewing } = useCalculateSettlement(calcParams, {
    query: { enabled: canPreview, queryKey: getCalculateSettlementQueryKey(calcParams) },
  });

  const createMutation = useCreateSettlement({
    mutation: {
      onSuccess: () => {
        toast({ title: t("settlements.toast.saved") });
        setDialogOpen(false);
        setPreviewRequested(false);
        refetch();
      },
      onError: () => {
        toast({ title: t("settlements.toast.error"), variant: "destructive" });
      },
    },
  });

  const updateMutation = useUpdateSettlement({
    mutation: {
      onSuccess: () => {
        toast({ title: t("settlements.toast.updated") });
        setStatusDialogOpen(false);
        refetch();
      },
    },
  });

  function handlePeriodChange(period: string) {
    setCalcPeriod(period);
    if (period !== "custom") {
      const { from, to } = PERIOD_PRESETS[period].getDates();
      setCalcDateFrom(toDateInputValue(from));
      setCalcDateTo(toDateInputValue(to));
    }
    setPreviewRequested(false);
  }

  function handlePreview() {
    if (!calcStationId || !calcDateFrom || !calcDateTo) return;
    setPreviewRequested(true);
  }

  function handleSave() {
    if (!preview || !calcStationId) return;
    createMutation.mutate({
      data: {
        stationId: parseInt(calcStationId),
        period: calcPeriod as "daily" | "weekly" | "monthly" | "custom",
        dateFrom: new Date(calcDateFrom).toISOString(),
        dateTo: new Date(calcDateTo).toISOString(),
        commissionRate: parseFloat(calcCommissionRate) / 100,
        gatewayFeeRate: parseFloat(calcGatewayFeeRate) / 100,
        adjustments: parseFloat(calcAdjustments) || 0,
        notes: calcNotes || undefined,
      },
    });
  }

  function openStatusDialog(id: number, currentStatus: string) {
    setSelectedSettlementId(id);
    setNewStatus(currentStatus);
    setStatusDialogOpen(true);
  }

  function handleStatusUpdate() {
    if (!selectedSettlementId) return;
    updateMutation.mutate({
      id: selectedSettlementId,
      data: { status: newStatus as "pending" | "in_progress" | "paid" },
    });
  }

  const pendingTotal = settlements
    .filter((s) => s.status === "pending")
    .reduce((sum, s) => sum + s.netAmount, 0);
  const inProgressTotal = settlements
    .filter((s) => s.status === "in_progress")
    .reduce((sum, s) => sum + s.netAmount, 0);
  const paidTotal = settlements
    .filter((s) => s.status === "paid")
    .reduce((sum, s) => sum + s.netAmount, 0);

  const pendingCount = settlements.filter((s) => s.status === "pending").length;
  const inProgressCount = settlements.filter((s) => s.status === "in_progress").length;
  const paidCount = settlements.filter((s) => s.status === "paid").length;

  function formatPeriodLabel(s: (typeof settlements)[0]) {
    const from = new Date(s.dateFrom);
    const to = new Date(s.dateTo);
    return `${format(from, "dd MMM", { locale: dateLocale })} – ${format(to, "dd MMM yyyy", { locale: dateLocale })}`;
  }

  function exportPDF() {
    const doc = new jsPDF({ orientation: "landscape" });
    const W = doc.internal.pageSize.getWidth();

    doc.setFillColor(245, 166, 35);
    doc.rect(0, 0, W, 18, "F");
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(13);
    doc.setFont("helvetica", "bold");
    doc.text("FuelFlow – Financial Settlements Report", 14, 12);
    doc.setFontSize(9);
    doc.setFont("helvetica", "normal");
    doc.text(`Generated: ${format(new Date(), "dd/MM/yyyy HH:mm")}`, W - 14, 12, { align: "right" });

    autoTable(doc, {
      startY: 24,
      head: [["Station", "Period", "Txns", "Total Sales", "Commission", "Gateway Fees", "Adjustments", "Net Payable", "Status"]],
      body: settlements.map((s) => [
        s.stationName,
        formatPeriodLabel(s),
        s.transactionCount,
        formatCurrency(s.totalSales),
        `${formatCurrency(s.commissionAmount)} (${(s.commissionRate * 100).toFixed(1)}%)`,
        `${formatCurrency(s.gatewayFeeAmount)} (${(s.gatewayFeeRate * 100).toFixed(1)}%)`,
        formatCurrency(s.adjustments),
        formatCurrency(s.netAmount),
        s.status === "paid" ? "Paid" : s.status === "in_progress" ? "In Progress" : "Pending",
      ]),
      styles: { fontSize: 8, cellPadding: 3 },
      headStyles: { fillColor: [245, 166, 35], textColor: 255, fontStyle: "bold" },
      alternateRowStyles: { fillColor: [249, 250, 251] },
    });

    const finalY = (doc as any).lastAutoTable.finalY + 8;
    doc.setFontSize(9);
    doc.setFont("helvetica", "bold");
    doc.text(`Total Net Payable: ${formatCurrency(settlements.reduce((s, r) => s + r.netAmount, 0))}`, 14, finalY);

    doc.save(`settlements-${format(new Date(), "yyyy-MM-dd")}.pdf`);
  }

  function exportExcel() {
    const rows = settlements.map((s) => ({
      Station: s.stationName,
      Period: formatPeriodLabel(s),
      "Period Type": s.period,
      Transactions: s.transactionCount,
      "Total Sales (EGP)": s.totalSales,
      "Commission Rate": `${(s.commissionRate * 100).toFixed(1)}%`,
      "Commission (EGP)": s.commissionAmount,
      "Gateway Fee Rate": `${(s.gatewayFeeRate * 100).toFixed(1)}%`,
      "Gateway Fees (EGP)": s.gatewayFeeAmount,
      "Adjustments (EGP)": s.adjustments,
      "Net Payable (EGP)": s.netAmount,
      Status: s.status === "paid" ? "Paid" : s.status === "in_progress" ? "In Progress" : "Pending",
      Created: format(new Date(s.createdAt), "dd/MM/yyyy"),
    }));

    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Settlements");
    XLSX.writeFile(wb, `settlements-${format(new Date(), "yyyy-MM-dd")}.xlsx`);
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-1 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">{t("settlements.title")}</h1>
          <p className="text-muted-foreground text-sm mt-0.5">{t("settlements.subtitle")}</p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm">
                <Download className="h-4 w-4 me-2" />
                {t("settlements.export")}
                <ChevronDown className="h-4 w-4 ms-1" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={exportExcel}>{t("settlements.exportExcel")}</DropdownMenuItem>
              <DropdownMenuItem onClick={exportPDF}>{t("settlements.exportPdf")}</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          <Button size="sm" onClick={() => { setPreviewRequested(false); setDialogOpen(true); }}>
            <Plus className="h-4 w-4 me-2" />
            {t("settlements.calculate")}
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">{t("settlements.summary.totalPending")}</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{formatCurrency(pendingTotal)}</p>
            <p className="text-xs text-muted-foreground mt-1">{pendingCount} {t("settlements.summary.settlements")}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">{t("settlements.summary.totalInProgress")}</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-amber-600">{formatCurrency(inProgressTotal)}</p>
            <p className="text-xs text-muted-foreground mt-1">{inProgressCount} {t("settlements.summary.settlements")}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">{t("settlements.summary.totalPaid")}</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-green-600">{formatCurrency(paidTotal)}</p>
            <p className="text-xs text-muted-foreground mt-1">{paidCount} {t("settlements.summary.settlements")}</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
            <Select value={filterStationId} onValueChange={setFilterStationId}>
              <SelectTrigger className="w-[200px]">
                <SelectValue placeholder={t("settlements.filter.allStations")} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{t("settlements.filter.allStations")}</SelectItem>
                {stations.map((s) => (
                  <SelectItem key={s.id} value={String(s.id)}>{s.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder={t("settlements.filter.allStatuses")} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{t("settlements.filter.allStatuses")}</SelectItem>
                <SelectItem value="pending">{t("settlements.status.pending")}</SelectItem>
                <SelectItem value="in_progress">{t("settlements.status.in_progress")}</SelectItem>
                <SelectItem value="paid">{t("settlements.status.paid")}</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="ghost" size="icon" onClick={() => refetch()} disabled={isLoading}>
              <RefreshCw className={`h-4 w-4 ${isLoading ? "animate-spin" : ""}`} />
            </Button>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {settlements.length === 0 ? (
            <div className="py-16 text-center">
              <p className="font-medium text-base">{t("settlements.empty.title")}</p>
              <p className="text-muted-foreground text-sm mt-1">{t("settlements.empty.desc")}</p>
              <Button className="mt-4" size="sm" onClick={() => setDialogOpen(true)}>
                <Plus className="h-4 w-4 me-2" />
                {t("settlements.calculate")}
              </Button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b bg-muted/50">
                    <th className="text-start ps-6 py-3 font-medium text-muted-foreground">{t("settlements.col.station")}</th>
                    <th className="text-start px-4 py-3 font-medium text-muted-foreground">{t("settlements.col.period")}</th>
                    <th className="text-end px-4 py-3 font-medium text-muted-foreground">{t("settlements.col.transactions")}</th>
                    <th className="text-end px-4 py-3 font-medium text-muted-foreground">{t("settlements.col.totalSales")}</th>
                    <th className="text-end px-4 py-3 font-medium text-muted-foreground">{t("settlements.col.commission")}</th>
                    <th className="text-end px-4 py-3 font-medium text-muted-foreground">{t("settlements.col.gatewayFee")}</th>
                    <th className="text-end px-4 py-3 font-medium text-muted-foreground">{t("settlements.col.adjustments")}</th>
                    <th className="text-end px-4 py-3 font-medium text-muted-foreground font-bold">{t("settlements.col.netAmount")}</th>
                    <th className="text-center px-4 py-3 font-medium text-muted-foreground">{t("settlements.col.status")}</th>
                    <th className="text-center px-4 py-3 pe-6 font-medium text-muted-foreground">{t("settlements.col.actions")}</th>
                  </tr>
                </thead>
                <tbody>
                  {settlements.map((s) => (
                    <tr key={s.id} className="border-b last:border-0 hover:bg-muted/30 transition-colors">
                      <td className="ps-6 py-4 font-medium">{s.stationName}</td>
                      <td className="px-4 py-4 text-muted-foreground text-xs whitespace-nowrap">
                        <div className="font-medium text-foreground capitalize">{t(`settlements.period.${s.period}` as any)}</div>
                        <div>{formatPeriodLabel(s)}</div>
                      </td>
                      <td className="px-4 py-4 text-end">{s.transactionCount}</td>
                      <td className="px-4 py-4 text-end font-medium">{formatCurrency(s.totalSales)}</td>
                      <td className="px-4 py-4 text-end text-red-600">
                        <div>-{formatCurrency(s.commissionAmount)}</div>
                        <div className="text-xs text-muted-foreground">{(s.commissionRate * 100).toFixed(1)}%</div>
                      </td>
                      <td className="px-4 py-4 text-end text-red-600">
                        <div>-{formatCurrency(s.gatewayFeeAmount)}</div>
                        <div className="text-xs text-muted-foreground">{(s.gatewayFeeRate * 100).toFixed(1)}%</div>
                      </td>
                      <td className="px-4 py-4 text-end text-muted-foreground">
                        {s.adjustments !== 0 ? `-${formatCurrency(s.adjustments)}` : "—"}
                      </td>
                      <td className="px-4 py-4 text-end font-bold text-base">{formatCurrency(s.netAmount)}</td>
                      <td className="px-4 py-4 text-center">
                        <Badge variant="outline" className={statusColor(s.status)}>
                          {t(`settlements.status.${s.status}` as any)}
                        </Badge>
                      </td>
                      <td className="px-4 py-4 pe-6 text-center">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => openStatusDialog(s.id, s.status)}
                        >
                          {t("settlements.updateStatus")}
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={(open) => { setDialogOpen(open); if (!open) setPreviewRequested(false); }}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{t("settlements.dialog.title")}</DialogTitle>
            <DialogDescription>{t("settlements.dialog.desc")}</DialogDescription>
          </DialogHeader>

          <div className="space-y-4 pt-2">
            <div className="space-y-1.5">
              <Label>{t("settlements.field.station")}</Label>
              <Select value={calcStationId} onValueChange={(v) => { setCalcStationId(v); setPreviewRequested(false); }}>
                <SelectTrigger>
                  <SelectValue placeholder={t("settlements.filter.allStations")} />
                </SelectTrigger>
                <SelectContent>
                  {stations.map((s) => (
                    <SelectItem key={s.id} value={String(s.id)}>{s.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-1.5">
              <Label>{t("settlements.field.period")}</Label>
              <Select value={calcPeriod} onValueChange={handlePeriodChange}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {["daily", "weekly", "monthly", "custom"].map((p) => (
                    <SelectItem key={p} value={p}>{t(`settlements.period.${p}` as any)}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>{t("settlements.field.dateFrom")}</Label>
                <Input
                  type="date"
                  value={calcDateFrom}
                  onChange={(e) => { setCalcDateFrom(e.target.value); setPreviewRequested(false); }}
                />
              </div>
              <div className="space-y-1.5">
                <Label>{t("settlements.field.dateTo")}</Label>
                <Input
                  type="date"
                  value={calcDateTo}
                  onChange={(e) => { setCalcDateTo(e.target.value); setPreviewRequested(false); }}
                />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div className="space-y-1.5">
                <Label>{t("settlements.field.commissionRate")}</Label>
                <Input
                  type="number"
                  min="0"
                  max="100"
                  step="0.1"
                  value={calcCommissionRate}
                  onChange={(e) => { setCalcCommissionRate(e.target.value); setPreviewRequested(false); }}
                />
              </div>
              <div className="space-y-1.5">
                <Label>{t("settlements.field.gatewayFeeRate")}</Label>
                <Input
                  type="number"
                  min="0"
                  max="100"
                  step="0.1"
                  value={calcGatewayFeeRate}
                  onChange={(e) => { setCalcGatewayFeeRate(e.target.value); setPreviewRequested(false); }}
                />
              </div>
              <div className="space-y-1.5">
                <Label>{t("settlements.field.adjustments")}</Label>
                <Input
                  type="number"
                  min="0"
                  step="0.01"
                  value={calcAdjustments}
                  onChange={(e) => { setCalcAdjustments(e.target.value); setPreviewRequested(false); }}
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <Label>{t("settlements.field.notes")}</Label>
              <Textarea
                value={calcNotes}
                onChange={(e) => setCalcNotes(e.target.value)}
                rows={2}
                className="resize-none"
              />
            </div>

            {!previewRequested && (
              <Button
                className="w-full"
                variant="outline"
                onClick={handlePreview}
                disabled={!calcStationId || !calcDateFrom || !calcDateTo}
              >
                <RefreshCw className="h-4 w-4 me-2" />
                {t("settlements.preview.title")}
              </Button>
            )}

            {previewRequested && preview && (
              <div className="rounded-lg border bg-muted/40 p-4 space-y-2">
                <p className="font-semibold text-sm mb-3">
                  {t("settlements.preview.title")} — {preview.stationName}
                </p>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">
                    {t("settlements.preview.txCount", { count: String(preview.transactionCount) })}
                  </span>
                </div>
                <Separator />
                <div className="flex justify-between text-sm">
                  <span>{t("settlements.preview.totalSales")}</span>
                  <span className="font-medium">{formatCurrency(preview.totalSales)}</span>
                </div>
                <div className="flex justify-between text-sm text-red-600">
                  <span>{t("settlements.preview.commission", { rate: (preview.commissionRate * 100).toFixed(1) })}</span>
                  <span>-{formatCurrency(preview.commissionAmount)}</span>
                </div>
                <div className="flex justify-between text-sm text-red-600">
                  <span>{t("settlements.preview.gateway", { rate: (preview.gatewayFeeRate * 100).toFixed(1) })}</span>
                  <span>-{formatCurrency(preview.gatewayFeeAmount)}</span>
                </div>
                {preview.adjustments > 0 && (
                  <div className="flex justify-between text-sm text-red-600">
                    <span>{t("settlements.preview.adjustments")}</span>
                    <span>-{formatCurrency(preview.adjustments)}</span>
                  </div>
                )}
                <Separator />
                <div className="flex justify-between font-bold">
                  <span>{t("settlements.preview.net")}</span>
                  <span className="text-green-700">{formatCurrency(preview.netAmount)}</span>
                </div>
              </div>
            )}

            {previewRequested && isPreviewing && (
              <div className="text-center text-sm text-muted-foreground py-4">{t("common.loading")}</div>
            )}

            <div className="flex gap-2 pt-2">
              <Button variant="outline" className="flex-1" onClick={() => setDialogOpen(false)}>
                {t("common.cancel")}
              </Button>
              <Button
                className="flex-1"
                onClick={handleSave}
                disabled={!preview || createMutation.isPending || isPreviewing}
              >
                {createMutation.isPending ? t("common.saving") : t("settlements.save")}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={statusDialogOpen} onOpenChange={setStatusDialogOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>{t("settlements.updateStatus")}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 pt-2">
            <Select value={newStatus} onValueChange={setNewStatus}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="pending">{t("settlements.status.pending")}</SelectItem>
                <SelectItem value="in_progress">{t("settlements.status.in_progress")}</SelectItem>
                <SelectItem value="paid">{t("settlements.status.paid")}</SelectItem>
              </SelectContent>
            </Select>
            <div className="flex gap-2">
              <Button variant="outline" className="flex-1" onClick={() => setStatusDialogOpen(false)}>
                {t("common.cancel")}
              </Button>
              <Button className="flex-1" onClick={handleStatusUpdate} disabled={updateMutation.isPending}>
                {updateMutation.isPending ? t("common.saving") : t("common.done")}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
