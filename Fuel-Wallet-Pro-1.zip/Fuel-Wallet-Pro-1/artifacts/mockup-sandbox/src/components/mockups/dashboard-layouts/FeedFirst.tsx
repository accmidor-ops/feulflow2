import React from "react";
import {
  Wallet,
  Droplet,
  CreditCard,
  TrendingDown,
  Car,
  Fuel,
  MapPin,
  QrCode,
  Receipt,
  Bell,
  ChevronRight,
  LayoutDashboard,
  LogOut,
  Settings,
  HelpCircle,
  FileText,
  History,
  TrendingUp,
  CircleDashed,
  MoreVertical,
  Activity
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import "./_group.css";

const VEHICLES = [
  { id: 1, name: "Toyota Corolla — أ ب ج 1234", spent: 1420.50, liters: 97.9 },
  { id: 2, name: "Honda Civic — د ه و 5678", spent: 980.25, liters: 67.6 },
  { id: 3, name: "Nissan Sunny — ز ح ط 9012", spent: 742.00, liters: 51.1 },
];

const TRANSACTIONS = [
  { id: 1, station: "TotalEnergies Heliopolis", vehicle: "Toyota Corolla — أ ب ج 1234", time: "Today, 08:30 AM", total: 420.50, liters: 29.0, trend: "+0.15/L" },
  { id: 2, station: "Wataniya New Cairo", vehicle: "Honda Civic — د ه و 5678", time: "Yesterday, 06:15 PM", total: 550.00, liters: 37.9, trend: "-0.05/L" },
  { id: 3, station: "ChillOut 6th October", vehicle: "Nissan Sunny — ز ح ط 9012", time: "Yesterday, 09:00 AM", total: 320.00, liters: 22.0, trend: "Same" },
  { id: 4, station: "Mobil Smart Village", vehicle: "Toyota Corolla — أ ب ج 1234", time: "Mon May 5, 05:45 PM", total: 600.00, liters: 41.3, trend: "+0.20/L" },
  { id: 5, station: "Shell Maadi Corniche", vehicle: "Honda Civic — د ه و 5678", time: "Sun May 4, 11:20 AM", total: 430.25, liters: 29.6, trend: "-0.10/L" },
];

function Sidebar() {
  return (
    <div className="hidden md:flex w-64 flex-col fixed inset-y-0 z-50 ff-sidebar-bg border-r border-[hsl(var(--sidebar-border))]">
      <div className="h-16 flex items-center px-6 border-b border-[hsl(var(--sidebar-border))]">
        <Fuel className="h-6 w-6 text-[hsl(var(--sidebar-primary))] mr-2" />
        <span className="font-bold text-lg text-[hsl(var(--sidebar-foreground))] tracking-tight">FuelFlow</span>
      </div>
      <div className="flex-1 overflow-y-auto py-4">
        <nav className="space-y-1 px-3">
          <a href="#" className="flex items-center px-3 py-2 text-sm font-medium rounded-md bg-[hsl(var(--sidebar-accent))] text-[hsl(var(--sidebar-accent-foreground))]">
            <LayoutDashboard className="mr-3 h-5 w-5 opacity-75" />
            Dashboard
          </a>
          <a href="#" className="flex items-center px-3 py-2 text-sm font-medium rounded-md text-[hsl(var(--sidebar-foreground))] hover:bg-[hsl(var(--sidebar-accent))] opacity-80 hover:opacity-100">
            <MapPin className="mr-3 h-5 w-5 opacity-75" />
            Stations
          </a>
          <a href="#" className="flex items-center px-3 py-2 text-sm font-medium rounded-md text-[hsl(var(--sidebar-foreground))] hover:bg-[hsl(var(--sidebar-accent))] opacity-80 hover:opacity-100">
            <Wallet className="mr-3 h-5 w-5 opacity-75" />
            Wallet
          </a>
          <a href="#" className="flex items-center px-3 py-2 text-sm font-medium rounded-md text-[hsl(var(--sidebar-foreground))] hover:bg-[hsl(var(--sidebar-accent))] opacity-80 hover:opacity-100">
            <Car className="mr-3 h-5 w-5 opacity-75" />
            Vehicles
          </a>
          <a href="#" className="flex items-center px-3 py-2 text-sm font-medium rounded-md text-[hsl(var(--sidebar-foreground))] hover:bg-[hsl(var(--sidebar-accent))] opacity-80 hover:opacity-100">
            <QrCode className="mr-3 h-5 w-5 opacity-75" />
            Pay at Pump
          </a>
          <a href="#" className="flex items-center px-3 py-2 text-sm font-medium rounded-md text-[hsl(var(--sidebar-foreground))] hover:bg-[hsl(var(--sidebar-accent))] opacity-80 hover:opacity-100">
            <History className="mr-3 h-5 w-5 opacity-75" />
            Transactions
          </a>
          <a href="#" className="flex items-center px-3 py-2 text-sm font-medium rounded-md text-[hsl(var(--sidebar-foreground))] hover:bg-[hsl(var(--sidebar-accent))] opacity-80 hover:opacity-100">
            <FileText className="mr-3 h-5 w-5 opacity-75" />
            Reports
          </a>
        </nav>
      </div>
      <div className="p-4 border-t border-[hsl(var(--sidebar-border))]">
        <div className="flex items-center">
          <div className="h-8 w-8 rounded-full bg-[hsl(var(--sidebar-accent))] flex items-center justify-center text-sm font-medium text-[hsl(var(--sidebar-foreground))]">
            AH
          </div>
          <div className="ml-3">
            <p className="text-sm font-medium text-[hsl(var(--sidebar-foreground))]">Ahmed Hassan</p>
            <p className="text-xs text-[hsl(var(--sidebar-foreground))] opacity-60">Driver</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function TopBar() {
  return (
    <header className="h-16 bg-white border-b flex items-center justify-between px-6 sticky top-0 z-40">
      <div className="flex items-center md:hidden">
        <Fuel className="h-6 w-6 text-primary mr-2" />
        <span className="font-bold text-lg tracking-tight">FuelFlow</span>
      </div>
      <div className="hidden md:block" />
      <div className="flex items-center gap-4">
        <div className="hidden sm:flex items-center px-3 py-1.5 rounded-full bg-primary/10 text-primary text-sm font-medium">
          <Wallet className="h-4 w-4 mr-2" />
          EGP 4,820.50
        </div>
        <button className="relative p-2 text-slate-500 hover:text-slate-900 transition-colors">
          <Bell className="h-5 w-5" />
          <span className="absolute top-1.5 right-1.5 h-2 w-2 rounded-full bg-destructive" />
        </button>
      </div>
    </header>
  );
}

export function FeedFirst() {
  return (
    <div className="fuelflow-mockup bg-[hsl(var(--background))] min-h-screen">
      <Sidebar />
      <div className="md:pl-64 flex flex-col min-h-screen">
        <TopBar />
        <main className="flex-1 p-6 max-w-7xl mx-auto w-full">
          
          {/* Summary Strip */}
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 mb-8 bg-white p-6 rounded-2xl border shadow-sm">
            <div className="flex-1 min-w-[280px]">
              <div className="text-sm font-medium text-slate-500 mb-1 flex items-center">
                <Wallet className="h-4 w-4 mr-1.5" />
                Available Balance
              </div>
              <div className="text-4xl font-bold text-[hsl(var(--primary))] tracking-tight mb-3">
                EGP 4,820.50
              </div>
              <div className="flex justify-between text-xs text-slate-500 mb-1.5">
                <span>Spent: EGP 5,179.50</span>
                <span>Limit: EGP 10,000.00</span>
              </div>
              <Progress value={51.8} className="h-2 bg-slate-100 [&>div]:bg-[hsl(var(--primary))]" />
            </div>
            
            <div className="hidden lg:block w-px h-16 bg-slate-200" />
            
            <div className="flex-1 flex items-center justify-between lg:justify-end gap-6 sm:gap-12">
              <div>
                <div className="text-xs font-medium text-slate-500 mb-1 uppercase tracking-wider">MTD Spend</div>
                <div className="text-xl font-bold text-slate-900">EGP 3,142.75</div>
                <div className="text-xs text-slate-500 mt-0.5">18 transactions</div>
              </div>
              <div className="w-px h-10 bg-slate-200" />
              <div>
                <div className="text-xs font-medium text-slate-500 mb-1 uppercase tracking-wider">Liters</div>
                <div className="text-xl font-bold text-slate-900">412.5 L</div>
                <div className="text-xs text-slate-500 mt-0.5">EGP 14.50 / L avg</div>
              </div>
              <div className="w-px h-10 bg-slate-200" />
              <div>
                <div className="text-xs font-medium text-slate-500 mb-1 uppercase tracking-wider">Avg/Tx</div>
                <div className="text-xl font-bold text-slate-900">22.9 L</div>
                <div className="text-xs text-emerald-600 font-medium mt-0.5 flex items-center">
                  <TrendingDown className="h-3 w-3 mr-0.5" /> 1.2 L
                </div>
              </div>
            </div>
          </div>

          {/* Primary CTAs */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-10">
            <Button size="lg" className="h-16 text-lg bg-[hsl(var(--primary))] text-[hsl(var(--primary-foreground))] hover:bg-[hsl(var(--primary))]/90 shadow-md">
              <QrCode className="mr-2 h-6 w-6" />
              Pay at Pump
            </Button>
            <Button variant="outline" size="lg" className="h-16 text-lg border-2 bg-white shadow-sm">
              <MapPin className="mr-2 h-6 w-6 text-slate-500" />
              Find Station
            </Button>
          </div>

          {/* Two Column Layout */}
          <div className="grid grid-cols-1 xl:grid-cols-12 gap-8 items-start">
            
            {/* LEFT: Activity Feed (65%) */}
            <div className="xl:col-span-8 space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-bold flex items-center">
                  <Activity className="h-5 w-5 mr-2 text-[hsl(var(--primary))]" />
                  Activity
                </h2>
                <Button variant="ghost" size="sm" className="text-slate-500">View All</Button>
              </div>

              <div className="bg-white rounded-2xl border shadow-sm p-1">
                {/* Timeline rendering */}
                <div className="relative p-5">
                  <div className="absolute top-8 bottom-8 left-[35px] w-px bg-slate-200 z-0" />
                  
                  <div className="mb-4 relative z-10 pl-[52px]">
                    <span className="text-xs font-bold uppercase tracking-wider text-slate-500 bg-slate-100 px-2 py-1 rounded-md">Today</span>
                  </div>
                  
                  <div className="relative z-10 flex items-start gap-4 mb-8">
                    <div className="h-8 w-8 rounded-full bg-slate-100 border-2 border-white flex items-center justify-center shrink-0 shadow-sm mt-1">
                      <Fuel className="h-4 w-4 text-[hsl(var(--primary))]" />
                    </div>
                    <div className="flex-1 min-w-0 bg-slate-50/50 hover:bg-slate-50 transition-colors p-4 rounded-xl border border-slate-100">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2">
                        <div className="font-semibold text-slate-900 truncate">TotalEnergies Heliopolis</div>
                        <div className="font-bold text-base whitespace-nowrap">EGP 420.50</div>
                      </div>
                      <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-sm text-slate-500">
                        <div className="flex items-center"><Car className="h-3.5 w-3.5 mr-1" /> Toyota Corolla — أ ب ج 1234</div>
                        <div className="flex items-center"><Droplet className="h-3.5 w-3.5 mr-1" /> 29.0 L</div>
                        <div className="text-xs bg-slate-200/50 px-1.5 py-0.5 rounded text-slate-600">+0.15/L vs last</div>
                      </div>
                    </div>
                  </div>

                  <div className="mb-4 relative z-10 pl-[52px]">
                    <span className="text-xs font-bold uppercase tracking-wider text-slate-500 bg-slate-100 px-2 py-1 rounded-md">Yesterday</span>
                  </div>

                  <div className="relative z-10 flex items-start gap-4 mb-6">
                    <div className="h-8 w-8 rounded-full bg-slate-100 border-2 border-white flex items-center justify-center shrink-0 shadow-sm mt-1">
                      <Fuel className="h-4 w-4 text-[hsl(var(--primary))]" />
                    </div>
                    <div className="flex-1 min-w-0 bg-slate-50/50 hover:bg-slate-50 transition-colors p-4 rounded-xl border border-slate-100">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2">
                        <div className="font-semibold text-slate-900 truncate">Wataniya New Cairo</div>
                        <div className="font-bold text-base whitespace-nowrap">EGP 550.00</div>
                      </div>
                      <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-sm text-slate-500">
                        <div className="flex items-center"><Car className="h-3.5 w-3.5 mr-1" /> Honda Civic — د ه و 5678</div>
                        <div className="flex items-center"><Droplet className="h-3.5 w-3.5 mr-1" /> 37.9 L</div>
                        <div className="text-xs bg-emerald-50 px-1.5 py-0.5 rounded text-emerald-700">-0.05/L vs last</div>
                      </div>
                    </div>
                  </div>

                  <div className="relative z-10 flex items-start gap-4 mb-8">
                    <div className="h-8 w-8 rounded-full bg-slate-100 border-2 border-white flex items-center justify-center shrink-0 shadow-sm mt-1">
                      <Fuel className="h-4 w-4 text-[hsl(var(--primary))]" />
                    </div>
                    <div className="flex-1 min-w-0 bg-slate-50/50 hover:bg-slate-50 transition-colors p-4 rounded-xl border border-slate-100">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2">
                        <div className="font-semibold text-slate-900 truncate">ChillOut 6th October</div>
                        <div className="font-bold text-base whitespace-nowrap">EGP 320.00</div>
                      </div>
                      <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-sm text-slate-500">
                        <div className="flex items-center"><Car className="h-3.5 w-3.5 mr-1" /> Nissan Sunny — ز ح ط 9012</div>
                        <div className="flex items-center"><Droplet className="h-3.5 w-3.5 mr-1" /> 22.0 L</div>
                      </div>
                    </div>
                  </div>

                  <div className="mb-4 relative z-10 pl-[52px]">
                    <span className="text-xs font-bold uppercase tracking-wider text-slate-500 bg-slate-100 px-2 py-1 rounded-md">Mon May 5</span>
                  </div>

                  <div className="relative z-10 flex items-start gap-4">
                    <div className="h-8 w-8 rounded-full bg-slate-100 border-2 border-white flex items-center justify-center shrink-0 shadow-sm mt-1">
                      <Fuel className="h-4 w-4 text-[hsl(var(--primary))]" />
                    </div>
                    <div className="flex-1 min-w-0 bg-slate-50/50 hover:bg-slate-50 transition-colors p-4 rounded-xl border border-slate-100">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2">
                        <div className="font-semibold text-slate-900 truncate">Mobil Smart Village</div>
                        <div className="font-bold text-base whitespace-nowrap">EGP 600.00</div>
                      </div>
                      <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-sm text-slate-500">
                        <div className="flex items-center"><Car className="h-3.5 w-3.5 mr-1" /> Toyota Corolla — أ ب ج 1234</div>
                        <div className="flex items-center"><Droplet className="h-3.5 w-3.5 mr-1" /> 41.3 L</div>
                        <div className="text-xs bg-slate-200/50 px-1.5 py-0.5 rounded text-slate-600">+0.20/L vs last</div>
                      </div>
                    </div>
                  </div>

                </div>
              </div>
            </div>

            {/* RIGHT: By Vehicle Sidebar (35%) */}
            <div className="xl:col-span-4">
              <Card className="sticky top-24 shadow-sm border bg-white">
                <CardHeader className="pb-4 border-b border-slate-100">
                  <CardTitle className="text-lg flex items-center">
                    <Car className="h-5 w-5 mr-2 text-slate-400" />
                    By vehicle
                  </CardTitle>
                  <CardDescription>Monthly spend distribution</CardDescription>
                </CardHeader>
                <CardContent className="pt-6 px-0 pb-2">
                  <div className="space-y-1">
                    {VEHICLES.map((vehicle, idx) => {
                      // Calculate percentage based on max spend to scale bars
                      const maxSpend = Math.max(...VEHICLES.map(v => v.spent));
                      const percentage = (vehicle.spent / maxSpend) * 100;
                      
                      return (
                        <div key={vehicle.id} className="px-6 py-3 hover:bg-slate-50 transition-colors">
                          <div className="flex items-start justify-between mb-2">
                            <div className="flex items-center gap-3">
                              <div className="h-10 w-10 rounded-lg bg-slate-100 flex items-center justify-center text-slate-500 font-bold shrink-0">
                                {idx + 1}
                              </div>
                              <div className="min-w-0">
                                <div className="text-sm font-semibold text-slate-900 truncate">{vehicle.name.split(' — ')[0]}</div>
                                <div className="text-xs text-slate-500 flex items-center mt-0.5">
                                  <Badge variant="outline" className="text-[10px] h-4 px-1 rounded-sm bg-white font-normal mr-2">
                                    {vehicle.name.split(' — ')[1]}
                                  </Badge>
                                  {vehicle.liters} L
                                </div>
                              </div>
                            </div>
                            <div className="text-right">
                              <div className="text-sm font-bold text-slate-900 whitespace-nowrap">
                                EGP {vehicle.spent.toLocaleString(undefined, {minimumFractionDigits: 2})}
                              </div>
                            </div>
                          </div>
                          <div className="pl-13 pr-1 pt-1">
                            <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
                              <div 
                                className="h-full bg-[hsl(var(--primary))] rounded-full" 
                                style={{ width: `${percentage}%` }}
                              />
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                  
                  <div className="mt-4 px-6 pt-4 border-t border-slate-100">
                    <Button variant="outline" className="w-full text-slate-600 bg-slate-50">Manage Fleet</Button>
                  </div>
                </CardContent>
              </Card>
            </div>
            
          </div>
        </main>
      </div>
    </div>
  );
}
