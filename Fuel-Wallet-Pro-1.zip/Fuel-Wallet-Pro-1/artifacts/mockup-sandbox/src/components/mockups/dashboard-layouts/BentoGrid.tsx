import React from "react";
import { 
  Wallet, 
  Droplet, 
  CreditCard, 
  Car, 
  MapPin, 
  QrCode, 
  Bell, 
  Settings,
  LayoutDashboard,
  Receipt,
  FileText,
  HelpCircle,
  LogOut,
  ChevronRight,
  TrendingDown
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";
import "./_group.css";

const VEHICLES = [
  { vehicleName: "Toyota Corolla — أ ب ج 1234", spent: 1420.50 },
  { vehicleName: "Honda Civic — د ه و 5678", spent: 980.25 },
  { vehicleName: "Nissan Sunny — ز ح ط 9012", spent: 742.00 },
];

const TRANSACTIONS = [
  {
    id: 1,
    stationName: "TotalEnergies Heliopolis",
    vehicleName: "Toyota Corolla — أ ب ج 1234",
    createdAt: "2024-05-18T14:30:00Z",
    total: 450.00,
    liters: 31.0,
    pricePerLiter: 14.50
  },
  {
    id: 2,
    stationName: "Wataniya New Cairo",
    vehicleName: "Honda Civic — د ه و 5678",
    createdAt: "2024-05-17T09:15:00Z",
    total: 320.50,
    liters: 22.1,
    pricePerLiter: 14.50
  },
  {
    id: 3,
    stationName: "ChillOut 6th October",
    vehicleName: "Nissan Sunny — ز ح ط 9012",
    createdAt: "2024-05-15T18:45:00Z",
    total: 280.00,
    liters: 19.3,
    pricePerLiter: 14.50
  },
  {
    id: 4,
    stationName: "Mobil Smart Village",
    vehicleName: "Toyota Corolla — أ ب ج 1234",
    createdAt: "2024-05-12T08:20:00Z",
    total: 510.00,
    liters: 35.2,
    pricePerLiter: 14.50
  },
  {
    id: 5,
    stationName: "Shell Maadi Corniche",
    vehicleName: "Honda Civic — د ه و 5678",
    createdAt: "2024-05-10T16:10:00Z",
    total: 410.25,
    liters: 28.3,
    pricePerLiter: 14.50
  }
];

export function BentoGrid() {
  return (
    <div className="fuelflow-mockup flex h-screen w-full bg-background overflow-hidden font-sans">
      
      {/* Sidebar */}
      <aside className="w64 flex-shrink-0 ff-sidebar-bg flex flex-col border-r border-sidebar-border hidden md:flex">
        <div className="h-16 flex items-center px-6 border-b border-sidebar-border/50">
          <div className="flex items-center gap-2 text-primary font-bold text-xl tracking-tight">
            <Droplet className="h-6 w-6 fill-primary" />
            FuelFlow
          </div>
        </div>
        <div className="flex-1 overflow-y-auto py-4 px-3 flex flex-col gap-1">
          <NavItem icon={<LayoutDashboard size={18} />} label="Dashboard" active />
          <NavItem icon={<MapPin size={18} />} label="Stations" />
          <NavItem icon={<Wallet size={18} />} label="Wallet" />
          <NavItem icon={<Car size={18} />} label="Vehicles" />
          <NavItem icon={<QrCode size={18} />} label="Pay at Pump" />
          <NavItem icon={<Receipt size={18} />} label="Transactions" />
          
          <div className="mt-4 mb-2 px-3 text-xs font-semibold text-sidebar-foreground/50 uppercase tracking-wider">
            Management
          </div>
          <NavItem icon={<FileText size={18} />} label="Reports" />
          <NavItem icon={<FileText size={18} />} label="Invoices" />
          <NavItem icon={<Wallet size={18} />} label="Settlements" />
          
          <div className="mt-auto pt-4 flex flex-col gap-1">
            <NavItem icon={<HelpCircle size={18} />} label="Support" />
            <NavItem icon={<Settings size={18} />} label="Settings" />
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top bar */}
        <header className="h-16 flex-shrink-0 bg-card border-b border-border flex items-center justify-between px-6 z-10">
          <div className="md:hidden flex items-center gap-2 text-primary font-bold text-xl">
            <Droplet className="h-6 w-6 fill-primary" />
          </div>
          <div className="hidden md:flex items-center gap-4 text-sm text-muted-foreground">
            {/* Breadcrumb or date could go here */}
            <span>May 18, 2024</span>
          </div>
          <div className="flex items-center gap-4">
            <div className="hidden sm:flex items-center gap-2 bg-secondary px-3 py-1.5 rounded-full border border-border">
              <Wallet size={16} className="text-primary" />
              <span className="font-semibold text-sm">EGP 4,820.50</span>
            </div>
            <button className="relative p-2 text-muted-foreground hover:bg-secondary rounded-full transition-colors">
              <Bell size={20} />
              <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-destructive rounded-full"></span>
            </button>
            <div className="h-8 w-px bg-border mx-1"></div>
            <div className="flex items-center gap-3">
              <div className="text-right hidden sm:block">
                <p className="text-sm font-medium leading-none">Ahmed Hassan</p>
                <p className="text-xs text-muted-foreground mt-1">Driver</p>
              </div>
              <Avatar className="h-9 w-9 border border-border">
                <AvatarFallback className="bg-primary/10 text-primary font-semibold">AH</AvatarFallback>
              </Avatar>
            </div>
          </div>
        </header>

        {/* Dashboard Area - Bento Grid */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 bg-background">
          <div className="max-w-7xl mx-auto space-y-6">
            
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-end mb-2">
              <div>
                <h1 className="text-3xl font-bold tracking-tight text-foreground">Dashboard</h1>
                <p className="text-muted-foreground mt-1">Your control center for the month.</p>
              </div>
            </div>

            {/* Bento Grid */}
            <div className="grid grid-cols-1 md:grid-cols-12 md:grid-rows-[minmax(180px,auto)_minmax(180px,auto)_minmax(120px,auto)] gap-5">
              
              {/* HERO TILE: Wallet (6 cols, 2 rows) */}
              <div className="col-span-1 md:col-span-6 md:row-span-2 relative overflow-hidden rounded-[1.5rem] bg-gradient-to-br from-amber-400 to-amber-600 text-amber-950 p-6 sm:p-8 flex flex-col justify-between shadow-sm">
                <div className="absolute top-0 right-0 p-8 opacity-20 pointer-events-none">
                  <Wallet size={120} />
                </div>
                <div>
                  <div className="flex items-center gap-2 mb-2 opacity-90 font-medium">
                    <Wallet size={20} />
                    Wallet Balance
                  </div>
                  <div className="text-5xl sm:text-6xl font-black tracking-tight mt-2 mb-1">
                    EGP 4,820.50
                  </div>
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/20 text-amber-950 font-medium text-sm backdrop-blur-sm">
                    <span className="w-1.5 h-1.5 rounded-full bg-green-400"></span>
                    Active and ready
                  </div>
                </div>

                <div className="mt-12">
                  <div className="flex justify-between items-end mb-2 text-sm font-medium opacity-90">
                    <span>Monthly Limit Usage</span>
                    <span>EGP 10,000.00</span>
                  </div>
                  <Progress value={48.2} className="h-3 bg-black/10 [&>div]:bg-white" />
                  <div className="mt-6 flex gap-3">
                    <Button className="bg-white text-amber-700 hover:bg-white/90 rounded-xl px-6">
                      Recharge
                    </Button>
                    <Button variant="outline" className="border-white/30 text-amber-950 hover:bg-white/20 bg-transparent rounded-xl">
                      History
                    </Button>
                  </div>
                </div>
              </div>

              {/* MEDIUM TILE: Spend (3 cols, 1 row) */}
              <div className="col-span-1 md:col-span-3 rounded-[1.5rem] bg-card border border-border p-6 flex flex-col justify-center shadow-sm">
                <div className="flex items-center justify-between mb-4">
                  <div className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center">
                    <CreditCard className="text-muted-foreground w-5 h-5" />
                  </div>
                  <Badge variant="secondary" className="bg-muted text-muted-foreground">MTD</Badge>
                </div>
                <div className="text-sm font-medium text-muted-foreground mb-1">Monthly Spend</div>
                <div className="text-3xl font-bold text-foreground">EGP 3,142.75</div>
                <div className="text-sm text-muted-foreground mt-2 flex items-center gap-1.5">
                  <span className="text-foreground font-medium">18</span> transactions
                </div>
              </div>

              {/* MEDIUM TILE: Fuel Consumed (3 cols, 1 row) */}
              <div className="col-span-1 md:col-span-3 rounded-[1.5rem] bg-card border border-border p-6 flex flex-col justify-center shadow-sm">
                <div className="flex items-center justify-between mb-4">
                  <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                    <Droplet className="text-primary w-5 h-5" />
                  </div>
                  <Badge variant="secondary" className="bg-muted text-muted-foreground">MTD</Badge>
                </div>
                <div className="text-sm font-medium text-muted-foreground mb-1">Fuel Consumed</div>
                <div className="text-3xl font-bold text-foreground">412.5 <span className="text-xl font-medium text-muted-foreground">L</span></div>
                <div className="text-sm text-muted-foreground mt-2 flex items-center gap-1.5">
                  Avg <span className="text-foreground font-medium">EGP 14.50</span> / L
                </div>
              </div>

              {/* TALL TILE: Transactions (6 cols, 2 rows total, spanning rows 2 & 3 in standard layout or stacked on right)
                  Let's place it spanning rows 2 & 3, right 6 cols. But we used top-right for spend/fuel.
                  Actually, our grid is 12 cols.
                  Row 1: Wallet (6), Spend (3), Fuel (3)
                  Row 2: Wallet (6 continues), Transactions (6 continues down to Row 3)
                  Row 3: Chart (6 cols), Transactions (6 continues)
               */}
              <div className="col-span-1 md:col-span-6 md:row-span-2 rounded-[1.5rem] bg-card border border-border p-6 shadow-sm flex flex-col">
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h3 className="text-lg font-bold text-foreground">Recent Transactions</h3>
                    <p className="text-sm text-muted-foreground">Latest 5 fuel ups</p>
                  </div>
                  <Button variant="ghost" size="sm" className="text-primary hover:text-primary/80 h-8 rounded-lg">
                    View All <ChevronRight size={16} className="ml-1" />
                  </Button>
                </div>
                
                <div className="flex-1 flex flex-col gap-4">
                  {TRANSACTIONS.map((tx) => (
                    <div key={tx.id} className="flex items-center justify-between p-3 -mx-3 hover:bg-muted/50 rounded-xl transition-colors">
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 rounded-full bg-secondary flex items-center justify-center flex-shrink-0">
                          <QrCode className="text-primary w-5 h-5" />
                        </div>
                        <div className="min-w-0">
                          <p className="text-sm font-bold text-foreground truncate">{tx.stationName}</p>
                          <p className="text-xs text-muted-foreground truncate max-w-[200px] sm:max-w-xs">{tx.vehicleName}</p>
                        </div>
                      </div>
                      <div className="text-right flex-shrink-0">
                        <p className="text-sm font-bold text-foreground">EGP {tx.total.toFixed(2)}</p>
                        <p className="text-xs text-muted-foreground">{tx.liters.toFixed(1)} L</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* WIDE TILE: Chart (6 cols, 1 row) */}
              <div className="col-span-1 md:col-span-6 rounded-[1.5rem] bg-card border border-border p-6 shadow-sm flex flex-col">
                 <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="font-bold text-foreground">Vehicle Breakdown</h3>
                    <p className="text-xs text-muted-foreground">Spend per vehicle (EGP)</p>
                  </div>
                  <div className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center">
                    <Car className="text-muted-foreground w-4 h-4" />
                  </div>
                </div>
                <div className="flex-1 min-h-[120px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart layout="vertical" data={VEHICLES} margin={{ top: 0, right: 0, left: 0, bottom: 0 }}>
                      <XAxis type="number" hide />
                      <YAxis dataKey="vehicleName" type="category" hide />
                      <Tooltip 
                        cursor={{ fill: 'transparent' }}
                        content={({ active, payload }) => {
                          if (active && payload && payload.length) {
                            return (
                              <div className="bg-popover text-popover-foreground border border-border p-2 rounded-lg text-xs shadow-md">
                                <p className="font-semibold mb-1">{payload[0].payload.vehicleName}</p>
                                <p className="text-primary font-bold">EGP {payload[0].value}</p>
                              </div>
                            );
                          }
                          return null;
                        }}
                      />
                      <Bar 
                        dataKey="spent" 
                        fill="hsl(var(--primary))" 
                        radius={[0, 4, 4, 0]}
                        barSize={24}
                        background={{ fill: 'hsl(var(--secondary))', radius: 4 }}
                      />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* CTAS TILE: (12 cols, 1 row at bottom?) Actually let's just make it span 6 cols, or 12 if we want it wide. 
                  Wait, row 1: Wallet(6), Spend(3), Fuel(3) = 12
                  Row 2: Wallet(6), Trans(6) = 12
                  Row 3: Chart(6), Trans(6) = 12
                  Row 4: CTAs(12) 
              */}
              <div className="col-span-1 md:col-span-12 grid grid-cols-1 sm:grid-cols-2 gap-5 mt-2">
                <Button className="h-20 sm:h-24 rounded-[1.5rem] bg-primary hover:bg-primary/90 text-primary-foreground flex items-center justify-start px-6 sm:px-8 group shadow-sm">
                  <div className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center mr-4 group-hover:scale-110 transition-transform">
                    <QrCode className="w-6 h-6" />
                  </div>
                  <div className="text-left">
                    <div className="font-bold text-lg">Pay at Pump</div>
                    <div className="text-sm opacity-90 font-normal hidden sm:block">Scan QR to authorize fueling</div>
                  </div>
                </Button>
                
                <Button variant="outline" className="h-20 sm:h-24 rounded-[1.5rem] bg-card border-border hover:bg-secondary/50 text-foreground flex items-center justify-start px-6 sm:px-8 group shadow-sm">
                  <div className="w-12 h-12 rounded-full bg-secondary flex items-center justify-center mr-4 group-hover:scale-110 transition-transform">
                    <MapPin className="w-6 h-6 text-primary" />
                  </div>
                  <div className="text-left">
                    <div className="font-bold text-lg">Find Station</div>
                    <div className="text-sm text-muted-foreground font-normal hidden sm:block">Navigate to nearest FuelFlow partner</div>
                  </div>
                </Button>
              </div>

            </div>

          </div>
        </div>
      </main>
    </div>
  );
}

function NavItem({ icon, label, active = false }: { icon: React.ReactNode, label: string, active?: boolean }) {
  return (
    <a 
      href="#" 
      className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
        active 
          ? "bg-sidebar-accent text-sidebar-accent-foreground" 
          : "text-sidebar-foreground/70 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground"
      }`}
    >
      <span className={active ? "text-primary" : "opacity-70"}>{icon}</span>
      {label}
    </a>
  );
}
