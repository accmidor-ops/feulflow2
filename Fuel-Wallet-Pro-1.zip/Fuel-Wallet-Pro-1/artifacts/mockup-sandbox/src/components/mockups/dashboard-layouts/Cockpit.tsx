import React from "react";
import { 
  Wallet, 
  CreditCard, 
  Droplet, 
  TrendingDown, 
  MapPin, 
  QrCode, 
  Bell, 
  Search,
  LayoutDashboard,
  Fuel,
  Car,
  Receipt,
  FileText,
  CreditCard as SettlesIcon,
  HelpCircle,
  Settings,
  Plus,
  ArrowRight
} from "lucide-react";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer,
  Cell
} from "recharts";
import "./_group.css";

const VEHICLE_DATA = [
  { vehicleName: "Toyota Corolla — أ ب ج 1234", spent: 1420.50 },
  { vehicleName: "Honda Civic — د ه و 5678", spent: 980.25 },
  { vehicleName: "Nissan Sunny — ز ح ط 9012", spent: 742.00 },
];

const TRANSACTIONS = [
  { id: 1, station: "TotalEnergies Heliopolis", vehicle: "Toyota Corolla — أ ب ج 1234", date: "Today, 08:30 AM", total: 450.00, liters: 31.0, price: 14.50 },
  { id: 2, station: "Wataniya New Cairo", vehicle: "Honda Civic — د ه و 5678", date: "Yesterday, 14:15 PM", total: 320.50, liters: 22.1, price: 14.50 },
  { id: 3, station: "ChillOut 6th October", vehicle: "Nissan Sunny — ز ح ط 9012", date: "Oct 24, 09:45 AM", total: 210.00, liters: 14.5, price: 14.50 },
  { id: 4, station: "Mobil Smart Village", vehicle: "Toyota Corolla — أ ب ج 1234", date: "Oct 22, 18:20 PM", total: 580.00, liters: 40.0, price: 14.50 },
  { id: 5, station: "Shell Maadi Corniche", vehicle: "Honda Civic — د ه و 5678", date: "Oct 20, 07:10 AM", total: 420.75, liters: 29.0, price: 14.50 },
  { id: 6, station: "AlAhli Nasr City", vehicle: "Nissan Sunny — ز ح ط 9012", date: "Oct 18, 11:30 AM", total: 315.50, liters: 21.8, price: 14.50 },
];

const NAV_ITEMS = [
  { icon: LayoutDashboard, label: "Dashboard", active: true },
  { icon: MapPin, label: "Stations" },
  { icon: Wallet, label: "Wallet" },
  { icon: Car, label: "Vehicles" },
  { icon: QrCode, label: "Pay at Pump" },
  { icon: Receipt, label: "Transactions" },
  { icon: FileText, label: "Reports" },
  { icon: FileText, label: "Invoices" },
  { icon: SettlesIcon, label: "Settlements" },
  { icon: HelpCircle, label: "Support" },
  { icon: Bell, label: "Notifications" },
  { icon: Settings, label: "Settings" },
];

function Sidebar() {
  return (
    <div className="w64 flex-shrink-0 ff-sidebar-bg flex flex-col h-screen overflow-y-auto border-r border-[hsl(var(--sidebar-border))]">
      <div className="p-6 flex items-center gap-3">
        <div className="w-8 h-8 rounded bg-[hsl(var(--primary))] flex items-center justify-center">
          <Droplet className="w-5 h-5 text-[hsl(var(--primary-foreground))]" />
        </div>
        <span className="text-xl font-bold tracking-tight text-white">FuelFlow</span>
      </div>
      <div className="px-4 py-2">
        <div className="text-xs font-semibold text-[hsl(var(--sidebar-foreground))] opacity-50 uppercase tracking-wider mb-4 px-2">Menu</div>
        <nav className="space-y-1">
          {NAV_ITEMS.map((item, i) => (
            <a 
              key={i} 
              href="#" 
              className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                item.active 
                  ? 'bg-[hsl(var(--sidebar-accent))] text-white' 
                  : 'text-[hsl(var(--sidebar-foreground))] opacity-70 hover:opacity-100 hover:bg-[hsl(var(--sidebar-accent))]'
              }`}
            >
              <item.icon className="w-4 h-4" />
              {item.label}
            </a>
          ))}
        </nav>
      </div>
    </div>
  );
}

function Topbar() {
  return (
    <div className="h-16 bg-white border-b ff-border flex items-center justify-between px-6 shrink-0">
      <div className="flex items-center gap-4 bg-gray-100 px-3 py-2 rounded-md w-96">
        <Search className="w-4 h-4 text-gray-400" />
        <input 
          type="text" 
          placeholder="Search stations, transactions..." 
          className="bg-transparent border-none outline-none text-sm w-full placeholder:text-gray-400"
        />
      </div>
      <div className="flex items-center gap-5">
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-orange-50 border border-orange-100">
          <Wallet className="w-4 h-4 text-orange-600" />
          <span className="text-sm font-bold text-orange-700">EGP 4,820.50</span>
        </div>
        <button className="relative text-gray-500 hover:text-gray-700 transition-colors">
          <Bell className="w-5 h-5" />
          <span className="absolute -top-1 -right-1 w-2 h-2 bg-red-500 rounded-full border-2 border-white"></span>
        </button>
        <div className="flex items-center gap-3 pl-5 border-l ff-border cursor-pointer">
          <div className="text-right hidden md:block">
            <div className="text-sm font-bold leading-none text-gray-900">Ahmed Hassan</div>
            <div className="text-xs text-gray-500 mt-1">Driver</div>
          </div>
          <div className="w-9 h-9 rounded-full bg-gray-200 flex items-center justify-center text-gray-600 font-bold text-sm">
            AH
          </div>
        </div>
      </div>
    </div>
  );
}

export function Cockpit() {
  return (
    <div className="fuelflow-mockup flex h-screen w-full bg-[hsl(var(--background))] overflow-hidden font-sans">
      <Sidebar />
      <div className="flex-1 flex flex-col h-full overflow-hidden">
        <Topbar />
        
        {/* Main Content Area - No scrolling on body, highly dense */}
        <div className="flex-1 p-4 flex flex-col gap-4 overflow-hidden">
          
          {/* Top KPI Strip - Flush together */}
          <div className="flex bg-white rounded-lg shadow-sm border ff-border overflow-hidden shrink-0">
            {/* Wallet KPI - Anchor */}
            <div className="flex-1 p-4 bg-[hsl(var(--primary))] text-[hsl(var(--primary-foreground))] flex flex-col justify-center">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold uppercase tracking-wider opacity-80">Wallet Balance</span>
                <Wallet className="w-4 h-4 opacity-80" />
              </div>
              <div className="text-2xl font-black mb-1">EGP 4,820.50</div>
              <div className="flex items-center gap-2 text-xs font-medium opacity-80">
                <div className="h-1.5 flex-1 bg-black/20 rounded-full overflow-hidden">
                  <div className="h-full bg-white rounded-full" style={{ width: '48%' }}></div>
                </div>
                <span>48% of EGP 10,000.00</span>
              </div>
            </div>
            
            {/* KPI 2 */}
            <div className="flex-1 p-4 border-l border-gray-100 flex flex-col justify-center">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-gray-500 uppercase tracking-wider">Monthly Spend (MTD)</span>
                <CreditCard className="w-4 h-4 text-gray-400" />
              </div>
              <div className="text-2xl font-black text-gray-900 mb-1">EGP 3,142.75</div>
              <div className="text-xs font-medium text-green-600 flex items-center gap-1">
                <TrendingDown className="w-3 h-3" /> -12% vs last month (18 txs)
              </div>
            </div>
            
            {/* KPI 3 */}
            <div className="flex-1 p-4 border-l border-gray-100 flex flex-col justify-center">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-gray-500 uppercase tracking-wider">Fuel Consumed</span>
                <Droplet className="w-4 h-4 text-gray-400" />
              </div>
              <div className="text-2xl font-black text-gray-900 mb-1">412.5 L</div>
              <div className="text-xs font-medium text-gray-500">
                Avg price: EGP 14.50 / L
              </div>
            </div>
            
            {/* KPI 4 */}
            <div className="flex-1 p-4 border-l border-gray-100 flex flex-col justify-center">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-gray-500 uppercase tracking-wider">Avg Consumption</span>
                <Fuel className="w-4 h-4 text-gray-400" />
              </div>
              <div className="text-2xl font-black text-gray-900 mb-1">22.9 L</div>
              <div className="text-xs font-medium text-gray-500">
                Per transaction
              </div>
            </div>
          </div>
          
          {/* Bottom 3 Columns - Filling remaining height */}
          <div className="flex-1 flex gap-4 min-h-0">
            
            {/* Col 1: Vehicle Chart (~40%) */}
            <div className="w-[40%] bg-white rounded-lg shadow-sm border ff-border flex flex-col overflow-hidden">
              <div className="p-4 border-b border-gray-100 flex items-center justify-between shrink-0">
                <h3 className="font-bold text-gray-900">Spend by Vehicle</h3>
                <span className="text-xs font-medium text-gray-500 bg-gray-100 px-2 py-1 rounded">EGP</span>
              </div>
              <div className="flex-1 p-4 min-h-0 flex flex-col">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={VEHICLE_DATA} layout="vertical" margin={{ top: 0, right: 0, left: 0, bottom: 0 }}>
                    <XAxis type="number" hide />
                    <YAxis 
                      dataKey="vehicleName" 
                      type="category" 
                      axisLine={false} 
                      tickLine={false}
                      width={180}
                      tick={{ fontSize: 11, fill: '#6b7280', fontWeight: 500 }}
                    />
                    <Tooltip 
                      cursor={{fill: 'transparent'}}
                      content={({ active, payload }) => {
                        if (active && payload && payload.length) {
                          return (
                            <div className="bg-gray-900 text-white text-xs px-3 py-2 rounded shadow-xl">
                              <div className="font-bold">{payload[0].payload.vehicleName}</div>
                              <div className="text-gray-300 mt-1">EGP {payload[0].value?.toLocaleString('en-US', {minimumFractionDigits: 2})}</div>
                            </div>
                          );
                        }
                        return null;
                      }}
                    />
                    <Bar dataKey="spent" radius={[0, 4, 4, 0]} barSize={32}>
                      {VEHICLE_DATA.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={index === 0 ? "hsl(var(--primary))" : index === 1 ? "#374151" : "#9ca3af"} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
                
                <div className="mt-4 pt-4 border-t border-gray-100 grid grid-cols-3 gap-2 shrink-0">
                  {VEHICLE_DATA.map((v, i) => (
                    <div key={i} className="text-center">
                      <div className="text-[10px] text-gray-500 truncate mb-1" title={v.vehicleName}>{v.vehicleName.split(' — ')[1]}</div>
                      <div className="text-sm font-bold text-gray-900">{(v.spent / 3142.75 * 100).toFixed(0)}%</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
            
            {/* Col 2: Tight Table (~35%) */}
            <div className="w-[35%] bg-white rounded-lg shadow-sm border ff-border flex flex-col overflow-hidden">
              <div className="p-3 border-b border-gray-100 flex items-center justify-between shrink-0 bg-gray-50/50">
                <h3 className="font-bold text-gray-900 text-sm">Recent Transactions</h3>
                <button className="text-xs font-medium text-orange-600 hover:text-orange-700 flex items-center gap-1">
                  View all <ArrowRight className="w-3 h-3" />
                </button>
              </div>
              <div className="flex-1 overflow-auto">
                <table className="w-full text-left border-collapse">
                  <thead className="bg-gray-50 text-[10px] uppercase text-gray-500 font-bold sticky top-0 border-b border-gray-100">
                    <tr>
                      <th className="px-3 py-2 font-semibold">Station / Time</th>
                      <th className="px-3 py-2 font-semibold">Vehicle</th>
                      <th className="px-3 py-2 font-semibold text-right">Amount</th>
                    </tr>
                  </thead>
                  <tbody className="text-xs divide-y divide-gray-100">
                    {TRANSACTIONS.map((tx) => (
                      <tr key={tx.id} className="hover:bg-gray-50 transition-colors">
                        <td className="px-3 py-2.5">
                          <div className="font-bold text-gray-900 truncate max-w-[140px]">{tx.station}</div>
                          <div className="text-[10px] text-gray-500 mt-0.5">{tx.date}</div>
                        </td>
                        <td className="px-3 py-2.5">
                          <div className="text-gray-700 truncate max-w-[100px]">{tx.vehicle.split(' — ')[1]}</div>
                        </td>
                        <td className="px-3 py-2.5 text-right">
                          <div className="font-bold text-gray-900">EGP {tx.total.toFixed(2)}</div>
                          <div className="text-[10px] text-gray-500 mt-0.5">{tx.liters} L</div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
            
            {/* Col 3: Quick Actions Rail (~25%) */}
            <div className="w-[25%] flex flex-col gap-3 shrink-0">
              
              <button className="w-full bg-[hsl(var(--primary))] text-[hsl(var(--primary-foreground))] rounded-lg p-5 shadow-sm hover:brightness-105 transition-all flex flex-col items-center justify-center gap-3 border border-orange-400 group shrink-0">
                <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                  <QrCode className="w-6 h-6" />
                </div>
                <div className="text-center">
                  <div className="font-black text-lg">Pay at Pump</div>
                  <div className="text-xs opacity-80 mt-1 font-medium">Scan QR to refuel immediately</div>
                </div>
              </button>
              
              <button className="w-full bg-gray-900 text-white rounded-lg p-4 shadow-sm hover:bg-black transition-all flex items-center gap-4 group shrink-0 border border-gray-800">
                <div className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center group-hover:bg-gray-700 transition-colors">
                  <MapPin className="w-5 h-5 text-[hsl(var(--primary))]" />
                </div>
                <div className="text-left flex-1">
                  <div className="font-bold text-sm">Find Station</div>
                  <div className="text-xs text-gray-400 mt-0.5">Locate nearest network</div>
                </div>
                <ArrowRight className="w-4 h-4 text-gray-600 group-hover:text-gray-400 transition-colors" />
              </button>
              
              <div className="flex-1 bg-white rounded-lg border ff-border shadow-sm flex flex-col min-h-0 overflow-hidden">
                <div className="p-3 border-b border-gray-100 bg-gray-50/50 shrink-0">
                  <h3 className="font-bold text-gray-900 text-xs uppercase tracking-wider">Secondary Actions</h3>
                </div>
                <div className="flex-1 flex flex-col divide-y divide-gray-100 overflow-y-auto">
                  <button className="flex items-center gap-3 p-3 hover:bg-gray-50 text-left transition-colors">
                    <div className="w-8 h-8 rounded bg-orange-50 flex items-center justify-center">
                      <Wallet className="w-4 h-4 text-orange-600" />
                    </div>
                    <div>
                      <div className="font-bold text-gray-900 text-xs">Recharge Wallet</div>
                      <div className="text-[10px] text-gray-500 mt-0.5">Add funds via card</div>
                    </div>
                  </button>
                  <button className="flex items-center gap-3 p-3 hover:bg-gray-50 text-left transition-colors">
                    <div className="w-8 h-8 rounded bg-gray-100 flex items-center justify-center">
                      <Plus className="w-4 h-4 text-gray-600" />
                    </div>
                    <div>
                      <div className="font-bold text-gray-900 text-xs">Add Vehicle</div>
                      <div className="text-[10px] text-gray-500 mt-0.5">Register new plate</div>
                    </div>
                  </button>
                  <button className="flex items-center gap-3 p-3 hover:bg-gray-50 text-left transition-colors">
                    <div className="w-8 h-8 rounded bg-gray-100 flex items-center justify-center">
                      <FileText className="w-4 h-4 text-gray-600" />
                    </div>
                    <div>
                      <div className="font-bold text-gray-900 text-xs">Export Report</div>
                      <div className="text-[10px] text-gray-500 mt-0.5">Download MTD CSV</div>
                    </div>
                  </button>
                </div>
              </div>

            </div>
            
          </div>
        </div>
      </div>
    </div>
  );
}
