import { Router, type IRouter } from "express";
import { db, settlementsTable, transactionsTable, stationsTable } from "@workspace/db";
import { and, gte, lte, eq } from "drizzle-orm";
import {
  ListSettlementsResponse,
  ListSettlementsResponseItem,
  CreateSettlementBody,
  CalculateSettlementResponse,
  UpdateSettlementBody,
  UpdateSettlementResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

const DEFAULT_COMMISSION_RATE = 0.025;
const DEFAULT_GATEWAY_FEE_RATE = 0.015;

async function calculateForPeriod(
  stationId: number,
  dateFrom: Date,
  dateTo: Date,
  commissionRate = DEFAULT_COMMISSION_RATE,
  gatewayFeeRate = DEFAULT_GATEWAY_FEE_RATE,
  adjustments = 0,
) {
  const txs = await db
    .select()
    .from(transactionsTable)
    .where(
      and(
        eq(transactionsTable.stationId, stationId),
        gte(transactionsTable.createdAt, dateFrom),
        lte(transactionsTable.createdAt, dateTo),
      ),
    );

  const totalSales = txs.reduce((s, t) => s + t.total, 0);
  const commissionAmount = totalSales * commissionRate;
  const gatewayFeeAmount = totalSales * gatewayFeeRate;
  const netAmount = totalSales - commissionAmount - gatewayFeeAmount - adjustments;

  return {
    transactionCount: txs.length,
    totalSales: Number(totalSales.toFixed(2)),
    commissionRate,
    commissionAmount: Number(commissionAmount.toFixed(2)),
    gatewayFeeRate,
    gatewayFeeAmount: Number(gatewayFeeAmount.toFixed(2)),
    adjustments: Number(adjustments.toFixed(2)),
    netAmount: Number(netAmount.toFixed(2)),
  };
}

router.get("/settlements", async (req, res): Promise<void> => {
  const { station_id, date_from, date_to, status, period } = req.query as Record<string, string>;

  const filters = [];
  if (station_id) filters.push(eq(settlementsTable.stationId, parseInt(station_id)));
  if (status) filters.push(eq(settlementsTable.status, status));
  if (period) filters.push(eq(settlementsTable.period, period));
  if (date_from) filters.push(gte(settlementsTable.dateFrom, new Date(date_from)));
  if (date_to) filters.push(lte(settlementsTable.dateTo, new Date(date_to)));

  const rows = filters.length
    ? await db.select().from(settlementsTable).where(and(...filters))
    : await db.select().from(settlementsTable);

  const stations = await db.select().from(stationsTable);
  const sMap = new Map(stations.map((s) => [s.id, s]));

  const result = rows.map((r) => ({
    ...r,
    stationName: sMap.get(r.stationId)?.name ?? "Unknown Station",
    dateFrom: r.dateFrom.toISOString(),
    dateTo: r.dateTo.toISOString(),
    createdAt: r.createdAt.toISOString(),
    updatedAt: r.updatedAt.toISOString(),
  }));

  res.json(ListSettlementsResponse.parse(result));
});

router.get("/settlements/calculate", async (req, res): Promise<void> => {
  const { station_id, date_from, date_to, commission_rate, gateway_fee_rate, adjustments } =
    req.query as Record<string, string>;

  if (!station_id || !date_from || !date_to) {
    res.status(400).json({ error: "station_id, date_from and date_to are required" });
    return;
  }

  const stationId = parseInt(station_id);
  const stations = await db.select().from(stationsTable);
  const station = stations.find((s) => s.id === stationId);
  if (!station) {
    res.status(404).json({ error: "Station not found" });
    return;
  }

  const calc = await calculateForPeriod(
    stationId,
    new Date(date_from),
    new Date(date_to),
    commission_rate ? parseFloat(commission_rate) : DEFAULT_COMMISSION_RATE,
    gateway_fee_rate ? parseFloat(gateway_fee_rate) : DEFAULT_GATEWAY_FEE_RATE,
    adjustments ? parseFloat(adjustments) : 0,
  );

  res.json(
    CalculateSettlementResponse.parse({
      stationId,
      stationName: station.name,
      dateFrom: date_from,
      dateTo: date_to,
      ...calc,
    }),
  );
});

router.post("/settlements", async (req, res): Promise<void> => {
  const body = CreateSettlementBody.parse(req.body);

  const stations = await db.select().from(stationsTable);
  const station = stations.find((s) => s.id === body.stationId);
  if (!station) {
    res.status(404).json({ error: "Station not found" });
    return;
  }

  const calc = await calculateForPeriod(
    body.stationId,
    body.dateFrom instanceof Date ? body.dateFrom : new Date(body.dateFrom),
    body.dateTo instanceof Date ? body.dateTo : new Date(body.dateTo),
    body.commissionRate ?? DEFAULT_COMMISSION_RATE,
    body.gatewayFeeRate ?? DEFAULT_GATEWAY_FEE_RATE,
    body.adjustments ?? 0,
  );

  const [saved] = await db
    .insert(settlementsTable)
    .values({
      stationId: body.stationId,
      period: body.period,
      dateFrom: body.dateFrom instanceof Date ? body.dateFrom : new Date(body.dateFrom),
      dateTo: body.dateTo instanceof Date ? body.dateTo : new Date(body.dateTo),
      notes: body.notes ?? null,
      ...calc,
    })
    .returning();

  res.status(201).json(
    ListSettlementsResponseItem.parse({
      ...saved,
      stationName: station.name,
      dateFrom: saved.dateFrom.toISOString(),
      dateTo: saved.dateTo.toISOString(),
      createdAt: saved.createdAt.toISOString(),
      updatedAt: saved.updatedAt.toISOString(),
    }),
  );
});

router.patch("/settlements/:id", async (req, res): Promise<void> => {
  const id = parseInt(req.params.id);
  const body = UpdateSettlementBody.parse(req.body);

  const [updated] = await db
    .update(settlementsTable)
    .set({
      status: body.status,
      ...(body.notes !== undefined ? { notes: body.notes } : {}),
      updatedAt: new Date(),
    })
    .where(eq(settlementsTable.id, id))
    .returning();

  if (!updated) {
    res.status(404).json({ error: "Settlement not found" });
    return;
  }

  const stations = await db.select().from(stationsTable);
  const sMap = new Map(stations.map((s) => [s.id, s]));

  res.json(
    UpdateSettlementResponse.parse({
      ...updated,
      stationName: sMap.get(updated.stationId)?.name ?? "Unknown Station",
      dateFrom: updated.dateFrom.toISOString(),
      dateTo: updated.dateTo.toISOString(),
      createdAt: updated.createdAt.toISOString(),
      updatedAt: updated.updatedAt.toISOString(),
    }),
  );
});

export default router;
