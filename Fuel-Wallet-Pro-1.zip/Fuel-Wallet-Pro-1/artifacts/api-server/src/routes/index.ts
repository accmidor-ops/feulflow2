import { Router, type IRouter } from "express";
import healthRouter from "./health";
import stationsRouter from "./stations";
import walletRouter from "./wallet";
import vehiclesRouter from "./vehicles";
import fuelingRouter from "./fueling";
import transactionsRouter from "./transactions";
import reportsRouter from "./reports";
import supportRouter from "./support";
import notificationsRouter from "./notifications";
import fleetRouter from "./fleet";
import emailRouter from "./email";
import settlementsRouter from "./settlements";
import stationFinancialsRouter from "./station-financials";

const router: IRouter = Router();

router.use(healthRouter);
router.use(stationFinancialsRouter);
router.use(stationsRouter);
router.use(walletRouter);
router.use(vehiclesRouter);
router.use(fuelingRouter);
router.use(transactionsRouter);
router.use(reportsRouter);
router.use(supportRouter);
router.use(notificationsRouter);
router.use(fleetRouter);
router.use("/email", emailRouter);
router.use(settlementsRouter);

export default router;
