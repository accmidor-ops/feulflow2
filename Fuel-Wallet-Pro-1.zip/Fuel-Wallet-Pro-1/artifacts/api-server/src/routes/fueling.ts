import { Router, type IRouter } from "express";
import {
  db,
  fuelingSessionsTable,
  transactionsTable,
  walletsTable,
  walletTransactionsTable,
  vehiclesTable,
  stationsTable,
} from "@workspace/db";
import { eq } from "drizzle-orm";
import {
  CreateFuelingSessionBody,
  CompleteFuelingSessionParams,
  CompleteFuelingSessionBody,
  CompleteFuelingSessionResponse,
} from "@workspace/api-zod";
import { randomBytes } from "crypto";

const router: IRouter = Router();

router.post("/fueling/sessions", async (req, res): Promise<void> => {
  const parsed = CreateFuelingSessionBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const code = randomBytes(8).toString("hex").toUpperCase();
  const expiresAt = new Date(Date.now() + 5 * 60 * 1000);
  const qrPayload = `FUELFLOW|V:${parsed.data.vehicleId}|S:${parsed.data.stationId}|C:${code}`;
  const [session] = await db
    .insert(fuelingSessionsTable)
    .values({
      qrPayload,
      vehicleId: parsed.data.vehicleId,
      stationId: parsed.data.stationId,
      status: "pending",
      expiresAt,
    })
    .returning();
  res.status(201).json({
    id: session.id,
    qrPayload: session.qrPayload,
    vehicleId: session.vehicleId,
    stationId: session.stationId,
    status: session.status,
    expiresAt: session.expiresAt,
    createdAt: session.createdAt,
  });
});

router.post("/fueling/sessions/:id/complete", async (req, res): Promise<void> => {
  const params = CompleteFuelingSessionParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const body = CompleteFuelingSessionBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }
  const [session] = await db
    .select()
    .from(fuelingSessionsTable)
    .where(eq(fuelingSessionsTable.id, params.data.id));
  if (!session) {
    res.status(404).json({ error: "Session not found" });
    return;
  }
  const total = Number((body.data.liters * body.data.pricePerLiter).toFixed(2));
  const [tx] = await db
    .insert(transactionsTable)
    .values({
      vehicleId: session.vehicleId,
      stationId: session.stationId,
      fuelType: body.data.fuelType,
      liters: body.data.liters,
      pricePerLiter: body.data.pricePerLiter,
      total,
    })
    .returning();
  await db
    .update(fuelingSessionsTable)
    .set({ status: "completed" })
    .where(eq(fuelingSessionsTable.id, session.id));
  const [wallet] = await db.select().from(walletsTable).limit(1);
  if (wallet) {
    await db
      .update(walletsTable)
      .set({ balance: Math.max(0, wallet.balance - total) })
      .where(eq(walletsTable.id, wallet.id));
    await db.insert(walletTransactionsTable).values({
      walletId: wallet.id,
      type: "debit",
      amount: total,
      method: "wallet",
      description: `Fuel purchase - ${body.data.liters.toFixed(2)}L`,
    });
  }
  const [vehicle] = await db.select().from(vehiclesTable).where(eq(vehiclesTable.id, session.vehicleId));
  const [station] = await db.select().from(stationsTable).where(eq(stationsTable.id, session.stationId));
  res.json(
    CompleteFuelingSessionResponse.parse({
      id: tx.id,
      vehicleId: tx.vehicleId,
      vehicleName: vehicle?.name ?? "Vehicle",
      stationId: tx.stationId,
      stationName: station?.name ?? "Station",
      fuelType: tx.fuelType,
      liters: tx.liters,
      pricePerLiter: tx.pricePerLiter,
      total: tx.total,
      createdAt: tx.createdAt,
    }),
  );
});

export default router;
