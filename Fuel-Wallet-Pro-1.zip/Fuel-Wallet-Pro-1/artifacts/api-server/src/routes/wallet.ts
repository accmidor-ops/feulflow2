import { Router, type IRouter } from "express";
import { db, walletsTable, walletTransactionsTable, transactionsTable } from "@workspace/db";
import { desc, eq, gte, sum } from "drizzle-orm";
import {
  GetWalletResponse,
  RechargeWalletBody,
  RechargeWalletResponse,
  ListWalletTransactionsResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

async function getDefaultWallet() {
  const [w] = await db.select().from(walletsTable).limit(1);
  return w;
}

async function monthlySpent(): Promise<number> {
  const start = new Date();
  start.setUTCDate(1);
  start.setUTCHours(0, 0, 0, 0);
  const [{ total }] = await db
    .select({ total: sum(transactionsTable.total) })
    .from(transactionsTable)
    .where(gte(transactionsTable.createdAt, start));
  return Number(total ?? 0);
}

router.get("/wallet", async (_req, res): Promise<void> => {
  const w = await getDefaultWallet();
  if (!w) {
    res.status(404).json({ error: "Wallet not found" });
    return;
  }
  res.json(
    GetWalletResponse.parse({
      id: w.id,
      balance: w.balance,
      currency: w.currency,
      cardNumber: w.cardNumber,
      cardHolder: w.cardHolder,
      monthlySpent: await monthlySpent(),
      monthlyLimit: w.monthlyLimit,
    }),
  );
});

router.post("/wallet/recharge", async (req, res): Promise<void> => {
  const parsed = RechargeWalletBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const w = await getDefaultWallet();
  if (!w) {
    res.status(404).json({ error: "Wallet not found" });
    return;
  }
  const newBal = w.balance + parsed.data.amount;
  const [updated] = await db
    .update(walletsTable)
    .set({ balance: newBal })
    .where(eq(walletsTable.id, w.id))
    .returning();
  await db.insert(walletTransactionsTable).values({
    walletId: w.id,
    type: "recharge",
    amount: parsed.data.amount,
    method: parsed.data.method,
    description: `Wallet recharged via ${parsed.data.method.replace("_", " ")}`,
  });
  res.json(
    RechargeWalletResponse.parse({
      id: updated.id,
      balance: updated.balance,
      currency: updated.currency,
      cardNumber: updated.cardNumber,
      cardHolder: updated.cardHolder,
      monthlySpent: await monthlySpent(),
      monthlyLimit: updated.monthlyLimit,
    }),
  );
});

router.get("/wallet/transactions", async (_req, res): Promise<void> => {
  const rows = await db
    .select()
    .from(walletTransactionsTable)
    .orderBy(desc(walletTransactionsTable.createdAt));
  res.json(
    ListWalletTransactionsResponse.parse(
      rows.map((r) => ({
        id: r.id,
        type: r.type,
        amount: r.amount,
        method: r.method,
        description: r.description,
        createdAt: r.createdAt,
      })),
    ),
  );
});

export default router;
