import { Router, type IRouter } from "express";
import { db, transactionsTable, stationsTable, settlementsTable } from "@workspace/db";
import { gte, eq } from "drizzle-orm";
import { GetStationFinancialsResponse } from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/stations/financials", async (req, res): Promise<void> => {
  const { date_from } = req.query as Record<string, string>;

  const now = new Date();
  const thisMonthStart = new Date(now.getFullYear(), now.getMonth(), 1);
  const lastMonthStart = new Date(now.getFullYear(), now.getMonth() - 1, 1);
  const lastMonthEnd = new Date(now.getFullYear(), now.getMonth(), 0, 23, 59, 59, 999);

  // Fetch all transactions (optionally filtered by date_from)
  let txQuery = db.select().from(transactionsTable);
  const allTxs = date_from
    ? await (txQuery as any).where(gte(transactionsTable.createdAt, new Date(date_from)))
    : await txQuery;

  // Fetch all stations
  const stations = await db.select().from(stationsTable);

  // Fetch all settlements
  const settlements = await db.select().from(settlementsTable);

  // Fetch this-month and last-month transactions (always full for MoM comparison)
  const thisMonthTxs = await db
    .select()
    .from(transactionsTable)
    .where(gte(transactionsTable.createdAt, thisMonthStart));

  const allTxsUnfiltered = await db.select().from(transactionsTable);
  const lastMonthTxs = allTxsUnfiltered.filter(
    (t) => t.createdAt >= lastMonthStart && t.createdAt <= lastMonthEnd,
  );

  // Build monthly trend buckets (last 6 months)
  const trendMonths: string[] = [];
  for (let i = 5; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    trendMonths.push(d.toISOString().slice(0, 7));
  }

  // --- Per-station aggregation ---
  const stationMap = new Map(stations.map((s) => [s.id, s]));

  // Group filtered txs by station
  const byStation = new Map<
    number,
    { revenue: number; liters: number; count: number }
  >();
  for (const t of allTxs) {
    const cur = byStation.get(t.stationId) ?? { revenue: 0, liters: 0, count: 0 };
    cur.revenue += t.total;
    cur.liters += t.liters;
    cur.count += 1;
    byStation.set(t.stationId, cur);
  }

  // Group this-month txs by station
  const thisMonthByStation = new Map<number, { revenue: number; liters: number; count: number }>();
  for (const t of thisMonthTxs) {
    const cur = thisMonthByStation.get(t.stationId) ?? { revenue: 0, liters: 0, count: 0 };
    cur.revenue += t.total;
    cur.liters += t.liters;
    cur.count += 1;
    thisMonthByStation.set(t.stationId, cur);
  }

  // Group last-month txs by station
  const lastMonthByStation = new Map<number, { revenue: number; liters: number; count: number }>();
  for (const t of lastMonthTxs) {
    const cur = lastMonthByStation.get(t.stationId) ?? { revenue: 0, liters: 0, count: 0 };
    cur.revenue += t.total;
    cur.liters += t.liters;
    cur.count += 1;
    lastMonthByStation.set(t.stationId, cur);
  }

  // Group settlements by station and status
  const settlementsByStation = new Map<
    number,
    { pending: number; in_progress: number; paid: number }
  >();
  for (const s of settlements) {
    const cur = settlementsByStation.get(s.stationId) ?? {
      pending: 0,
      in_progress: 0,
      paid: 0,
    };
    if (s.status === "paid") cur.paid += s.netAmount;
    else if (s.status === "in_progress") cur.in_progress += s.netAmount;
    else cur.pending += s.netAmount;
    settlementsByStation.set(s.stationId, cur);
  }

  // Monthly trend per station (from allTxsUnfiltered for consistent sparklines)
  const monthlyByStation = new Map<
    number,
    Map<string, { revenue: number; liters: number; count: number }>
  >();
  for (const t of allTxsUnfiltered) {
    const month = t.createdAt.toISOString().slice(0, 7);
    if (!trendMonths.includes(month)) continue;
    if (!monthlyByStation.has(t.stationId)) monthlyByStation.set(t.stationId, new Map());
    const mMap = monthlyByStation.get(t.stationId)!;
    const cur = mMap.get(month) ?? { revenue: 0, liters: 0, count: 0 };
    cur.revenue += t.total;
    cur.liters += t.liters;
    cur.count += 1;
    mMap.set(month, cur);
  }

  // Build per-station summaries
  const stationSummaries = stations.map((s) => {
    const totals = byStation.get(s.id) ?? { revenue: 0, liters: 0, count: 0 };
    const thisMonth = thisMonthByStation.get(s.id) ?? { revenue: 0, liters: 0, count: 0 };
    const lastMonth = lastMonthByStation.get(s.id) ?? { revenue: 0, liters: 0, count: 0 };
    const settl = settlementsByStation.get(s.id) ?? { pending: 0, in_progress: 0, paid: 0 };

    const revenueChange =
      lastMonth.revenue > 0
        ? Number((((thisMonth.revenue - lastMonth.revenue) / lastMonth.revenue) * 100).toFixed(1))
        : thisMonth.revenue > 0
          ? 100
          : 0;

    const mMap = monthlyByStation.get(s.id) ?? new Map();
    const monthlyTrend = trendMonths.map((month) => {
      const m = mMap.get(month) ?? { revenue: 0, liters: 0, count: 0 };
      return {
        month,
        revenue: Number(m.revenue.toFixed(2)),
        transactions: m.count,
        liters: Number(m.liters.toFixed(2)),
      };
    });

    return {
      stationId: s.id,
      stationName: s.name,
      city: s.city,
      totalRevenue: Number(totals.revenue.toFixed(2)),
      totalTransactions: totals.count,
      totalLiters: Number(totals.liters.toFixed(2)),
      avgTransactionValue:
        totals.count > 0 ? Number((totals.revenue / totals.count).toFixed(2)) : 0,
      thisMonthRevenue: Number(thisMonth.revenue.toFixed(2)),
      lastMonthRevenue: Number(lastMonth.revenue.toFixed(2)),
      revenueChange,
      pendingAmount: Number(settl.pending.toFixed(2)),
      inProgressAmount: Number(settl.in_progress.toFixed(2)),
      paidAmount: Number(settl.paid.toFixed(2)),
      monthlyTrend,
    };
  });

  // Sort stations by total revenue descending
  stationSummaries.sort((a, b) => b.totalRevenue - a.totalRevenue);

  // Network monthly trend
  const networkMonthlyMap = new Map<string, { revenue: number; liters: number; count: number }>();
  for (const month of trendMonths) networkMonthlyMap.set(month, { revenue: 0, liters: 0, count: 0 });
  for (const t of allTxsUnfiltered) {
    const month = t.createdAt.toISOString().slice(0, 7);
    const cur = networkMonthlyMap.get(month);
    if (!cur) continue;
    cur.revenue += t.total;
    cur.liters += t.liters;
    cur.count += 1;
  }
  const networkMonthlyTrend = trendMonths.map((month) => {
    const m = networkMonthlyMap.get(month)!;
    return {
      month,
      revenue: Number(m.revenue.toFixed(2)),
      transactions: m.count,
      liters: Number(m.liters.toFixed(2)),
    };
  });

  // Network totals
  const totalRevenue = stationSummaries.reduce((s, r) => s + r.totalRevenue, 0);
  const totalTransactions = stationSummaries.reduce((s, r) => s + r.totalTransactions, 0);
  const totalLiters = stationSummaries.reduce((s, r) => s + r.totalLiters, 0);
  const top = stationSummaries[0] ?? { stationId: 0, stationName: "", totalRevenue: 0 };

  const pendingSettlementsAmount = settlements
    .filter((s) => s.status === "pending")
    .reduce((sum, s) => sum + s.netAmount, 0);
  const inProgressSettlementsAmount = settlements
    .filter((s) => s.status === "in_progress")
    .reduce((sum, s) => sum + s.netAmount, 0);
  const paidSettlementsAmount = settlements
    .filter((s) => s.status === "paid")
    .reduce((sum, s) => sum + s.netAmount, 0);

  res.json(
    GetStationFinancialsResponse.parse({
      overview: {
        totalRevenue: Number(totalRevenue.toFixed(2)),
        totalTransactions,
        totalLiters: Number(totalLiters.toFixed(2)),
        totalStations: stations.length,
        topStationId: top.stationId,
        topStationName: top.stationName,
        topStationRevenue: top.totalRevenue,
        pendingSettlementsAmount: Number(pendingSettlementsAmount.toFixed(2)),
        inProgressSettlementsAmount: Number(inProgressSettlementsAmount.toFixed(2)),
        paidSettlementsAmount: Number(paidSettlementsAmount.toFixed(2)),
        monthlyTrend: networkMonthlyTrend,
      },
      stations: stationSummaries,
    }),
  );
});

export default router;
