import { Router, type IRouter } from "express";
import { db, transactionsTable, vehiclesTable, stationsTable } from "@workspace/db";
import { desc, eq } from "drizzle-orm";
import {
  ListTransactionsQueryParams,
  ListTransactionsResponse,
  GetTransactionParams,
  GetTransactionResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

async function enrich(rows: (typeof transactionsTable.$inferSelect)[]) {
  const vehicles = await db.select().from(vehiclesTable);
  const stations = await db.select().from(stationsTable);
  const vMap = new Map(vehicles.map((v) => [v.id, v]));
  const sMap = new Map(stations.map((s) => [s.id, s]));
  return rows.map((t) => ({
    id: t.id,
    vehicleId: t.vehicleId,
    vehicleName: vMap.get(t.vehicleId)?.name ?? "Vehicle",
    stationId: t.stationId,
    stationName: sMap.get(t.stationId)?.name ?? "Station",
    fuelType: t.fuelType,
    liters: t.liters,
    pricePerLiter: t.pricePerLiter,
    total: t.total,
    createdAt: t.createdAt,
  }));
}

router.get("/transactions", async (req, res): Promise<void> => {
  const params = ListTransactionsQueryParams.safeParse(req.query);
  let rows: (typeof transactionsTable.$inferSelect)[];
  if (params.success && params.data.vehicleId != null) {
    rows = await db
      .select()
      .from(transactionsTable)
      .where(eq(transactionsTable.vehicleId, params.data.vehicleId))
      .orderBy(desc(transactionsTable.createdAt));
  } else {
    rows = await db.select().from(transactionsTable).orderBy(desc(transactionsTable.createdAt));
  }
  res.json(ListTransactionsResponse.parse(await enrich(rows)));
});

router.get("/transactions/:id", async (req, res): Promise<void> => {
  const params = GetTransactionParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [row] = await db
    .select()
    .from(transactionsTable)
    .where(eq(transactionsTable.id, params.data.id));
  if (!row) {
    res.status(404).json({ error: "Transaction not found" });
    return;
  }
  const [enriched] = await enrich([row]);
  res.json(GetTransactionResponse.parse(enriched));
});

export default router;
