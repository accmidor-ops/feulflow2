import { Router, type IRouter } from "express";
import { db, stationsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import {
  ListStationsQueryParams,
  ListStationsResponse,
  GetStationParams,
  GetStationResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

function distanceKm(lat1: number, lng1: number, lat2: number, lng2: number) {
  const R = 6371;
  const toRad = (n: number) => (n * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.asin(Math.min(1, Math.sqrt(a)));
}

function shape(s: typeof stationsTable.$inferSelect, originLat: number, originLng: number) {
  return {
    id: s.id,
    name: s.name,
    address: s.address,
    city: s.city,
    lat: s.lat,
    lng: s.lng,
    distanceKm: Number(distanceKm(originLat, originLng, s.lat, s.lng).toFixed(2)),
    fuelTypes: s.fuelTypes,
    prices: {
      gasoline91: s.priceGasoline91,
      gasoline95: s.priceGasoline95,
      diesel: s.priceDiesel,
    },
    isOpen: s.isOpen,
    rating: s.rating,
    amenities: s.amenities,
  };
}

router.get("/stations", async (req, res): Promise<void> => {
  const params = ListStationsQueryParams.safeParse(req.query);
  const lat = params.success && params.data.lat != null ? params.data.lat : 30.0444;
  const lng = params.success && params.data.lng != null ? params.data.lng : 31.2357;
  const rows = await db.select().from(stationsTable);
  const result = rows
    .map((s) => shape(s, lat, lng))
    .sort((a, b) => a.distanceKm - b.distanceKm);
  res.json(ListStationsResponse.parse(result));
});

router.get("/stations/:id", async (req, res): Promise<void> => {
  const params = GetStationParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [row] = await db.select().from(stationsTable).where(eq(stationsTable.id, params.data.id));
  if (!row) {
    res.status(404).json({ error: "Station not found" });
    return;
  }
  res.json(GetStationResponse.parse(shape(row, 30.0444, 31.2357)));
});

export default router;
