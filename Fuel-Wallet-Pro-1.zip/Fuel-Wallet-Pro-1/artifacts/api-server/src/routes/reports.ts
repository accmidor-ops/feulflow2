import { Router, type IRouter } from "express";
import {
  db,
  transactionsTable,
  vehiclesTable,
  stationsTable,
  walletsTable,
} from "@workspace/db";
import { desc, gte } from "drizzle-orm";
import {
  GetDashboardSummaryResponse,
  GetMonthlyReportResponse,
  GetYearlyReportResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/reports/dashboard", async (_req, res): Promise<void> => {
  const startMonth = new Date();
  startMonth.setUTCDate(1);
  startMonth.setUTCHours(0, 0, 0, 0);
  const mtd = await db
    .select()
    .from(transactionsTable)
    .where(gte(transactionsTable.createdAt, startMonth));
  const totalSpentMtd = mtd.reduce((s, t) => s + t.total, 0);
  const totalLitersMtd = mtd.reduce((s, t) => s + t.liters, 0);
  const avgPricePerLiter = totalLitersMtd > 0 ? totalSpentMtd / totalLitersMtd : 0;
  const vehicles = await db.select().from(vehiclesTable);
  const vMap = new Map(vehicles.map((v) => [v.id, v]));
  const vBreakdown = new Map<number, { liters: number; spent: number }>();
  for (const t of mtd) {
    const prev = vBreakdown.get(t.vehicleId) ?? { liters: 0, spent: 0 };
    prev.liters += t.liters;
    prev.spent += t.total;
    vBreakdown.set(t.vehicleId, prev);
  }
  const vehicleBreakdown = Array.from(vBreakdown.entries())
    .map(([vehicleId, v]) => ({
      vehicleId,
      vehicleName: vMap.get(vehicleId)?.name ?? "Vehicle",
      liters: Number(v.liters.toFixed(2)),
      spent: Number(v.spent.toFixed(2)),
    }))
    .sort((a, b) => b.spent - a.spent);

  const recentRaw = await db
    .select()
    .from(transactionsTable)
    .orderBy(desc(transactionsTable.createdAt))
    .limit(5);
  const stations = await db.select().from(stationsTable);
  const sMap = new Map(stations.map((s) => [s.id, s]));
  const recentTransactions = recentRaw.map((t) => ({
    id: t.id,
    vehicleId: t.vehicleId,
    vehicleName: vMap.get(t.vehicleId)?.name ?? "Vehicle",
    stationId: t.stationId,
    stationName: sMap.get(t.stationId)?.name ?? "Station",
    fuelType: t.fuelType,
    liters: t.liters,
    pricePerLiter: t.pricePerLiter,
    total: t.total,
    createdAt: t.createdAt,
  }));
  const [wallet] = await db.select().from(walletsTable).limit(1);
  res.json(
    GetDashboardSummaryResponse.parse({
      totalSpentMtd: Number(totalSpentMtd.toFixed(2)),
      totalLitersMtd: Number(totalLitersMtd.toFixed(2)),
      transactionCountMtd: mtd.length,
      avgPricePerLiter: Number(avgPricePerLiter.toFixed(3)),
      walletBalance: wallet?.balance ?? 0,
      vehicleBreakdown,
      recentTransactions,
    }),
  );
});

router.get("/reports/monthly", async (_req, res): Promise<void> => {
  const start = new Date();
  start.setUTCMonth(start.getUTCMonth() - 11);
  start.setUTCDate(1);
  start.setUTCHours(0, 0, 0, 0);
  const txs = await db
    .select()
    .from(transactionsTable)
    .where(gte(transactionsTable.createdAt, start));
  const map = new Map<string, { liters: number; spent: number; count: number }>();
  for (let i = 0; i < 12; i++) {
    const d = new Date(start);
    d.setUTCMonth(d.getUTCMonth() + i);
    map.set(d.toISOString().slice(0, 7), { liters: 0, spent: 0, count: 0 });
  }
  for (const t of txs) {
    const key = t.createdAt.toISOString().slice(0, 7);
    const cur = map.get(key);
    if (!cur) continue;
    cur.liters += t.liters;
    cur.spent += t.total;
    cur.count += 1;
  }
  const out = Array.from(map.entries()).map(([month, v]) => ({
    month,
    liters: Number(v.liters.toFixed(2)),
    spent: Number(v.spent.toFixed(2)),
    transactionCount: v.count,
  }));
  res.json(GetMonthlyReportResponse.parse(out));
});

router.get("/reports/yearly", async (_req, res): Promise<void> => {
  const txs = await db.select().from(transactionsTable);
  const map = new Map<string, { liters: number; spent: number; count: number }>();
  for (const t of txs) {
    const year = t.createdAt.getUTCFullYear().toString();
    const cur = map.get(year) ?? { liters: 0, spent: 0, count: 0 };
    cur.liters += t.liters;
    cur.spent += t.total;
    cur.count += 1;
    map.set(year, cur);
  }
  const out = Array.from(map.entries())
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([year, v]) => ({
      year,
      liters: Number(v.liters.toFixed(2)),
      spent: Number(v.spent.toFixed(2)),
      transactionCount: v.count,
      avgPricePerLiter: v.liters > 0 ? Number((v.spent / v.liters).toFixed(3)) : 0,
    }));
  res.json(GetYearlyReportResponse.parse(out));
});

export default router;
