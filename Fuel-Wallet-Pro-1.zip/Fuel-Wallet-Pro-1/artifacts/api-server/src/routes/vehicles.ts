import { Router, type IRouter } from "express";
import {
  db,
  vehiclesTable,
  transactionsTable,
} from "@workspace/db";
import { desc, eq, sql } from "drizzle-orm";
import {
  ListVehiclesResponse,
  CreateVehicleBody,
  GetVehicleParams,
  GetVehicleResponse,
  UpdateVehicleParams,
  UpdateVehicleBody,
  UpdateVehicleResponse,
  DeleteVehicleParams,
  GetVehicleConsumptionParams,
  GetVehicleConsumptionResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

async function shape(v: typeof vehiclesTable.$inferSelect) {
  const [agg] = await db
    .select({
      totalLiters: sql<number>`coalesce(sum(${transactionsTable.liters}), 0)`,
      totalSpent: sql<number>`coalesce(sum(${transactionsTable.total}), 0)`,
      lastFueledAt: sql<Date | null>`max(${transactionsTable.createdAt})`,
    })
    .from(transactionsTable)
    .where(eq(transactionsTable.vehicleId, v.id));
  const totalLiters = Number(agg?.totalLiters ?? 0);
  const totalSpent = Number(agg?.totalSpent ?? 0);
  const avgConsumption = totalLiters > 0 ? Number((totalSpent / totalLiters).toFixed(2)) : 0;
  return {
    id: v.id,
    name: v.name,
    make: v.make,
    model: v.model,
    year: v.year,
    plate: v.plate,
    fuelType: v.fuelType,
    tankCapacity: v.tankCapacity,
    color: v.color,
    totalLiters,
    totalSpent,
    avgConsumption,
    lastFueledAt: agg?.lastFueledAt ?? null,
  };
}

router.get("/vehicles", async (_req, res): Promise<void> => {
  const rows = await db.select().from(vehiclesTable).orderBy(desc(vehiclesTable.createdAt));
  const out = await Promise.all(rows.map(shape));
  res.json(ListVehiclesResponse.parse(out));
});

router.post("/vehicles", async (req, res): Promise<void> => {
  const parsed = CreateVehicleBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [v] = await db.insert(vehiclesTable).values(parsed.data).returning();
  res.status(201).json(GetVehicleResponse.parse(await shape(v)));
});

router.get("/vehicles/:id", async (req, res): Promise<void> => {
  const params = GetVehicleParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [v] = await db.select().from(vehiclesTable).where(eq(vehiclesTable.id, params.data.id));
  if (!v) {
    res.status(404).json({ error: "Vehicle not found" });
    return;
  }
  res.json(GetVehicleResponse.parse(await shape(v)));
});

router.patch("/vehicles/:id", async (req, res): Promise<void> => {
  const params = UpdateVehicleParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const body = UpdateVehicleBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }
  const [v] = await db
    .update(vehiclesTable)
    .set(body.data)
    .where(eq(vehiclesTable.id, params.data.id))
    .returning();
  if (!v) {
    res.status(404).json({ error: "Vehicle not found" });
    return;
  }
  res.json(UpdateVehicleResponse.parse(await shape(v)));
});

router.delete("/vehicles/:id", async (req, res): Promise<void> => {
  const params = DeleteVehicleParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  await db.delete(vehiclesTable).where(eq(vehiclesTable.id, params.data.id));
  res.sendStatus(204);
});

router.get("/vehicles/:id/consumption", async (req, res): Promise<void> => {
  const params = GetVehicleConsumptionParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const txs = await db
    .select()
    .from(transactionsTable)
    .where(eq(transactionsTable.vehicleId, params.data.id))
    .orderBy(transactionsTable.createdAt);
  const totalLiters = txs.reduce((s, t) => s + t.liters, 0);
  const totalSpent = txs.reduce((s, t) => s + t.total, 0);
  const avgPricePerLiter = totalLiters > 0 ? Number((totalSpent / totalLiters).toFixed(3)) : 0;
  const monthlyMap = new Map<string, { liters: number; spent: number }>();
  for (const t of txs) {
    const key = t.createdAt.toISOString().slice(0, 7);
    const prev = monthlyMap.get(key) ?? { liters: 0, spent: 0 };
    prev.liters += t.liters;
    prev.spent += t.total;
    monthlyMap.set(key, prev);
  }
  const monthly = Array.from(monthlyMap.entries())
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([month, v]) => ({
      month,
      liters: Number(v.liters.toFixed(2)),
      spent: Number(v.spent.toFixed(2)),
    }));
  res.json(
    GetVehicleConsumptionResponse.parse({
      vehicleId: params.data.id,
      totalLiters: Number(totalLiters.toFixed(2)),
      totalSpent: Number(totalSpent.toFixed(2)),
      avgPricePerLiter,
      transactionCount: txs.length,
      monthly,
    }),
  );
});

export default router;
