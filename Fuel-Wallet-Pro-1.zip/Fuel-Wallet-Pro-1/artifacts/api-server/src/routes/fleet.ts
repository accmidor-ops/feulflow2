import { Router, type IRouter } from "express";
import {
  db,
  fleetCompanyTable,
  fleetVehiclesTable,
  fleetTransactionsTable,
  fleetAlertsTable,
  fleetDriversTable,
} from "@workspace/db";
import { desc, gte } from "drizzle-orm";
import {
  GetFleetOverviewResponse,
  ListFleetVehiclesResponse,
  GetFleetDailyUsageResponse,
  GetFleetMonthlyUsageResponse,
  ListFleetDriversResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

function startOfMonth() {
  const d = new Date();
  d.setUTCDate(1);
  d.setUTCHours(0, 0, 0, 0);
  return d;
}

router.get("/fleet/overview", async (_req, res): Promise<void> => {
  const [company] = await db.select().from(fleetCompanyTable).limit(1);
  const vehicles = await db.select().from(fleetVehiclesTable);
  const drivers = await db.select().from(fleetDriversTable);
  const monthTx = await db
    .select()
    .from(fleetTransactionsTable)
    .where(gte(fleetTransactionsTable.createdAt, startOfMonth()));
  const alerts = await db
    .select()
    .from(fleetAlertsTable)
    .orderBy(desc(fleetAlertsTable.createdAt))
    .limit(8);

  const monthlyByVehicle = new Map<number, { liters: number; spent: number }>();
  for (const t of monthTx) {
    const cur = monthlyByVehicle.get(t.fleetVehicleId) ?? { liters: 0, spent: 0 };
    cur.liters += t.liters;
    cur.spent += t.total;
    monthlyByVehicle.set(t.fleetVehicleId, cur);
  }
  const vMap = new Map(vehicles.map((v) => [v.id, v]));
  const topVehicles = Array.from(monthlyByVehicle.entries())
    .map(([vehicleId, v]) => ({
      vehicleId,
      plate: vMap.get(vehicleId)?.plate ?? "",
      name: `${vMap.get(vehicleId)?.make ?? ""} ${vMap.get(vehicleId)?.model ?? ""}`.trim(),
      liters: Number(v.liters.toFixed(2)),
      spent: Number(v.spent.toFixed(2)),
    }))
    .sort((a, b) => b.spent - a.spent)
    .slice(0, 5);

  res.json(
    GetFleetOverviewResponse.parse({
      companyName: company?.name ?? "Fleet",
      vehicleCount: vehicles.length,
      driverCount: drivers.length,
      monthlySpent: Number(monthTx.reduce((s, t) => s + t.total, 0).toFixed(2)),
      monthlyLiters: Number(monthTx.reduce((s, t) => s + t.liters, 0).toFixed(2)),
      activeVehicles: vehicles.filter((v) => v.status === "active").length,
      alerts,
      topVehicles,
    }),
  );
});

router.get("/fleet/vehicles", async (_req, res): Promise<void> => {
  const vehicles = await db.select().from(fleetVehiclesTable);
  const monthTx = await db
    .select()
    .from(fleetTransactionsTable)
    .where(gte(fleetTransactionsTable.createdAt, startOfMonth()));
  const byV = new Map<number, { liters: number; spent: number }>();
  for (const t of monthTx) {
    const cur = byV.get(t.fleetVehicleId) ?? { liters: 0, spent: 0 };
    cur.liters += t.liters;
    cur.spent += t.total;
    byV.set(t.fleetVehicleId, cur);
  }
  const out = vehicles.map((v) => ({
    id: v.id,
    plate: v.plate,
    make: v.make,
    model: v.model,
    driver: v.driver,
    department: v.department,
    monthlyLiters: Number((byV.get(v.id)?.liters ?? 0).toFixed(2)),
    monthlySpent: Number((byV.get(v.id)?.spent ?? 0).toFixed(2)),
    status: v.status,
    lastFueledAt: v.lastFueledAt,
  }));
  res.json(ListFleetVehiclesResponse.parse(out));
});

router.get("/fleet/usage/daily", async (_req, res): Promise<void> => {
  const start = new Date();
  start.setUTCDate(start.getUTCDate() - 29);
  start.setUTCHours(0, 0, 0, 0);
  const txs = await db
    .select()
    .from(fleetTransactionsTable)
    .where(gte(fleetTransactionsTable.createdAt, start));
  const map = new Map<string, { liters: number; spent: number; count: number }>();
  for (let i = 0; i < 30; i++) {
    const d = new Date(start);
    d.setUTCDate(d.getUTCDate() + i);
    map.set(d.toISOString().slice(0, 10), { liters: 0, spent: 0, count: 0 });
  }
  for (const t of txs) {
    const key = t.createdAt.toISOString().slice(0, 10);
    const cur = map.get(key);
    if (!cur) continue;
    cur.liters += t.liters;
    cur.spent += t.total;
    cur.count += 1;
  }
  const out = Array.from(map.entries()).map(([period, v]) => ({
    period,
    liters: Number(v.liters.toFixed(2)),
    spent: Number(v.spent.toFixed(2)),
    transactionCount: v.count,
  }));
  res.json(GetFleetDailyUsageResponse.parse(out));
});

router.get("/fleet/usage/monthly", async (_req, res): Promise<void> => {
  const start = new Date();
  start.setUTCMonth(start.getUTCMonth() - 11);
  start.setUTCDate(1);
  start.setUTCHours(0, 0, 0, 0);
  const txs = await db
    .select()
    .from(fleetTransactionsTable)
    .where(gte(fleetTransactionsTable.createdAt, start));
  const map = new Map<string, { liters: number; spent: number; count: number }>();
  for (let i = 0; i < 12; i++) {
    const d = new Date(start);
    d.setUTCMonth(d.getUTCMonth() + i);
    map.set(d.toISOString().slice(0, 7), { liters: 0, spent: 0, count: 0 });
  }
  for (const t of txs) {
    const key = t.createdAt.toISOString().slice(0, 7);
    const cur = map.get(key);
    if (!cur) continue;
    cur.liters += t.liters;
    cur.spent += t.total;
    cur.count += 1;
  }
  const out = Array.from(map.entries()).map(([period, v]) => ({
    period,
    liters: Number(v.liters.toFixed(2)),
    spent: Number(v.spent.toFixed(2)),
    transactionCount: v.count,
  }));
  res.json(GetFleetMonthlyUsageResponse.parse(out));
});

router.get("/fleet/drivers", async (_req, res): Promise<void> => {
  const drivers = await db.select().from(fleetDriversTable);
  const vehicles = await db.select().from(fleetVehiclesTable);
  const monthTx = await db
    .select()
    .from(fleetTransactionsTable)
    .where(gte(fleetTransactionsTable.createdAt, startOfMonth()));
  const vMap = new Map(vehicles.map((v) => [v.id, v]));
  const byDriver = new Map<string, { liters: number; spent: number }>();
  for (const t of monthTx) {
    const v = vMap.get(t.fleetVehicleId);
    if (!v) continue;
    const cur = byDriver.get(v.driver) ?? { liters: 0, spent: 0 };
    cur.liters += t.liters;
    cur.spent += t.total;
    byDriver.set(v.driver, cur);
  }
  const out = drivers.map((d) => {
    const stats = byDriver.get(d.name) ?? { liters: 0, spent: 0 };
    return {
      id: d.id,
      name: d.name,
      employeeId: d.employeeId,
      vehicleCount: vehicles.filter((v) => v.driver === d.name).length,
      monthlyLiters: Number(stats.liters.toFixed(2)),
      monthlySpent: Number(stats.spent.toFixed(2)),
      status: d.status,
    };
  });
  res.json(ListFleetDriversResponse.parse(out));
});

export default router;
