import { Router } from "express";
import nodemailer from "nodemailer";
import { format } from "date-fns";

const router = Router();

function getTransporter() {
  const host = process.env.SMTP_HOST;
  const user = process.env.SMTP_USER;
  const pass = process.env.SMTP_PASS;

  if (!host || !user || !pass) return null;

  return nodemailer.createTransport({
    host,
    port: parseInt(process.env.SMTP_PORT || "587"),
    secure: process.env.SMTP_SECURE === "true",
    auth: { user, pass },
  });
}

function buildInvoiceHtml(data: any): string {
  const subtotal = data.subtotal || 0;
  const vat = subtotal * 0.14;
  const total = subtotal + vat;

  return `
<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><style>
  body { font-family: Arial, sans-serif; color: #0F172A; margin: 0; padding: 0; background: #F9FAFB; }
  .header { background: #F5A623; padding: 24px 32px; color: white; }
  .header h1 { margin: 0; font-size: 24px; }
  .header p { margin: 4px 0 0; font-size: 13px; opacity: 0.85; }
  .content { padding: 32px; }
  .invoice-meta { display: flex; justify-content: space-between; margin-bottom: 24px; }
  .invoice-no { font-size: 20px; font-weight: bold; color: #F5A623; }
  table { width: 100%; border-collapse: collapse; font-size: 13px; }
  th { background: #F5A623; color: #0F172A; padding: 10px 12px; text-align: left; }
  td { padding: 10px 12px; border-bottom: 1px solid #E2E8F0; }
  tr:nth-child(even) td { background: #F8FAFC; }
  .totals { margin-top: 16px; float: right; width: 280px; }
  .totals tr td:last-child { text-align: right; }
  .totals .total-row td { font-weight: bold; font-size: 15px; background: #F5A623; color: #0F172A; padding: 12px; }
  .footer { margin-top: 48px; padding: 24px 32px; border-top: 1px solid #E2E8F0; font-size: 11px; color: #64748B; }
</style></head>
<body>
<div class="header">
  <h1>FuelFlow Egypt</h1>
  <p>Tax Registration No: 345-678-901 | support@fuelflow.eg</p>
</div>
<div class="content">
  <div class="invoice-meta">
    <div>
      <div class="invoice-no">INVOICE ${data.invoiceNumber || "FF-0001"}</div>
      <p style="margin:4px 0;color:#64748B;">Date: ${format(new Date(), "dd/MM/yyyy")}</p>
      <p style="margin:4px 0;font-weight:600;">To: ${data.buyerName || "Customer"}</p>
    </div>
    <div style="text-align:right;color:#64748B;font-size:13px;">
      <p>Period: ${data.period || format(new Date(), "MMMM yyyy")}</p>
      <p>Transactions: ${data.transactions?.length || 0}</p>
    </div>
  </div>

  <table>
    <thead><tr><th>#</th><th>Station</th><th>Date</th><th>Liters</th><th>Price/L</th><th>Amount (EGP)</th></tr></thead>
    <tbody>
      ${(data.transactions || []).map((tx: any, i: number) => `
        <tr>
          <td>${i + 1}</td>
          <td>${tx.stationName}</td>
          <td>${tx.date ? format(new Date(tx.date), "dd/MM/yyyy") : "-"}</td>
          <td>${Number(tx.liters).toFixed(2)} L</td>
          <td>EGP ${Number(tx.pricePerLiter).toFixed(2)}</td>
          <td>EGP ${Number(tx.total).toFixed(2)}</td>
        </tr>
      `).join("")}
    </tbody>
  </table>

  <table class="totals">
    <tr><td>Subtotal:</td><td>EGP ${subtotal.toFixed(2)}</td></tr>
    <tr><td>VAT (14%):</td><td>EGP ${vat.toFixed(2)}</td></tr>
    <tr class="total-row"><td>Total:</td><td>EGP ${total.toFixed(2)}</td></tr>
  </table>
</div>
<div class="footer">
  This invoice is compliant with Egypt Tax Authority (ETA) e-invoicing standards.<br>
  FuelFlow Egypt — Cairo, Egypt | support@fuelflow.eg
</div>
</body></html>`;
}

function buildReportHtml(data: any): string {
  const rows = data.monthlyData || [];
  const totalSpent = rows.reduce((s: number, r: any) => s + (r.spent || 0), 0);
  const totalLiters = rows.reduce((s: number, r: any) => s + (r.liters || 0), 0);

  return `
<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><style>
  body { font-family: Arial, sans-serif; color: #0F172A; margin: 0; padding: 0; background: #F9FAFB; }
  .header { background: #F5A623; padding: 24px 32px; color: white; }
  .header h1 { margin: 0; font-size: 22px; }
  .header p { margin: 4px 0 0; opacity: 0.85; font-size: 13px; }
  .content { padding: 32px; }
  .stats { display: flex; gap: 16px; margin-bottom: 24px; }
  .stat-card { background: white; border: 1px solid #E2E8F0; border-radius: 8px; padding: 16px 20px; flex: 1; }
  .stat-card .label { font-size: 11px; color: #64748B; text-transform: uppercase; letter-spacing: 0.05em; }
  .stat-card .value { font-size: 22px; font-weight: bold; color: #0F172A; margin-top: 4px; }
  table { width: 100%; border-collapse: collapse; font-size: 13px; }
  th { background: #F5A623; color: #0F172A; padding: 10px 12px; text-align: left; }
  td { padding: 10px 12px; border-bottom: 1px solid #E2E8F0; }
  tr:nth-child(even) td { background: #F8FAFC; }
  .footer { margin-top: 32px; padding: 16px 32px; border-top: 1px solid #E2E8F0; font-size: 11px; color: #64748B; }
</style></head>
<body>
<div class="header">
  <h1>FuelFlow — Monthly Consumption Report</h1>
  <p>${data.period || format(new Date(), "MMMM yyyy")} | Generated ${format(new Date(), "dd/MM/yyyy")}</p>
</div>
<div class="content">
  <div class="stats">
    <div class="stat-card">
      <div class="label">Total Spent</div>
      <div class="value">EGP ${totalSpent.toFixed(2)}</div>
    </div>
    <div class="stat-card">
      <div class="label">Total Volume</div>
      <div class="value">${totalLiters.toFixed(1)} L</div>
    </div>
    <div class="stat-card">
      <div class="label">Avg Price / L</div>
      <div class="value">EGP ${totalLiters > 0 ? (totalSpent / totalLiters).toFixed(2) : "0.00"}</div>
    </div>
  </div>

  <table>
    <thead><tr><th>Month</th><th>Spent (EGP)</th><th>Volume (L)</th><th>Transactions</th><th>Avg/L (EGP)</th></tr></thead>
    <tbody>
      ${rows.map((r: any) => `
        <tr>
          <td>${r.month}</td>
          <td>${Number(r.spent).toFixed(2)}</td>
          <td>${Number(r.liters).toFixed(1)}</td>
          <td>${r.transactionCount}</td>
          <td>${r.liters > 0 ? (r.spent / r.liters).toFixed(2) : "-"}</td>
        </tr>
      `).join("")}
    </tbody>
  </table>
</div>
<div class="footer">
  This report was automatically generated by FuelFlow Egypt. For support, contact support@fuelflow.eg
</div>
</body></html>`;
}

router.post("/send-invoice", async (req, res) => {
  const transporter = getTransporter();
  if (!transporter) {
    res.status(503).json({
      error: "Email service not configured",
      message: "SMTP environment variables (SMTP_HOST, SMTP_USER, SMTP_PASS) are not set.",
    });
    return;
  }

  const { recipientEmail, recipientName, invoiceData } = req.body;
  if (!recipientEmail) {
    res.status(400).json({ error: "recipientEmail is required" });
    return;
  }

  try {
    await transporter.sendMail({
      from: process.env.SMTP_FROM || `"FuelFlow Egypt" <${process.env.SMTP_USER}>`,
      to: recipientEmail,
      subject: `FuelFlow Invoice ${invoiceData?.invoiceNumber || ""} — ${format(new Date(), "MMMM yyyy")}`,
      html: buildInvoiceHtml({ ...invoiceData, buyerName: recipientName || invoiceData?.buyerName }),
    });
    res.json({ success: true, message: `Invoice sent to ${recipientEmail}` });
  } catch (err: any) {
    req.log.error(err, "Failed to send invoice email");
    res.status(500).json({ error: "Failed to send email", detail: err.message });
  }
});

router.post("/send-report", async (req, res) => {
  const transporter = getTransporter();
  if (!transporter) {
    res.status(503).json({
      error: "Email service not configured",
      message: "SMTP environment variables (SMTP_HOST, SMTP_USER, SMTP_PASS) are not set.",
    });
    return;
  }

  const { recipientEmail, reportData } = req.body;
  if (!recipientEmail) {
    res.status(400).json({ error: "recipientEmail is required" });
    return;
  }

  try {
    await transporter.sendMail({
      from: process.env.SMTP_FROM || `"FuelFlow Egypt" <${process.env.SMTP_USER}>`,
      to: recipientEmail,
      subject: `FuelFlow Monthly Report — ${reportData?.period || format(new Date(), "MMMM yyyy")}`,
      html: buildReportHtml(reportData || {}),
    });
    res.json({ success: true, message: `Report sent to ${recipientEmail}` });
  } catch (err: any) {
    req.log.error(err, "Failed to send report email");
    res.status(500).json({ error: "Failed to send email", detail: err.message });
  }
});

export default router;
