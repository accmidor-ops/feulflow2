import { Router, type IRouter } from "express";
import { db, supportTicketsTable } from "@workspace/db";
import { desc } from "drizzle-orm";
import {
  ListSupportTicketsResponse,
  CreateSupportTicketBody,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/support/tickets", async (_req, res): Promise<void> => {
  const rows = await db
    .select()
    .from(supportTicketsTable)
    .orderBy(desc(supportTicketsTable.createdAt));
  res.json(ListSupportTicketsResponse.parse(rows));
});

router.post("/support/tickets", async (req, res): Promise<void> => {
  const parsed = CreateSupportTicketBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [t] = await db.insert(supportTicketsTable).values(parsed.data).returning();
  res.status(201).json(t);
});

export default router;
