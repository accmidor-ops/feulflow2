import {
  db,
  stationsTable,
  walletsTable,
  walletTransactionsTable,
  vehiclesTable,
  transactionsTable,
  notificationsTable,
  supportTicketsTable,
  fleetCompanyTable,
  fleetDriversTable,
  fleetVehiclesTable,
  fleetTransactionsTable,
  fleetAlertsTable,
  pool,
} from "@workspace/db";

// Egyptian fuel prices in EGP per liter
const PRICE_91 = 13.75;
const PRICE_95 = 15.25;
const PRICE_DIESEL = 13.5;

async function main() {
  await db.delete(transactionsTable);
  await db.delete(walletTransactionsTable);
  await db.delete(walletsTable);
  await db.delete(vehiclesTable);
  await db.delete(stationsTable);
  await db.delete(notificationsTable);
  await db.delete(supportTicketsTable);
  await db.delete(fleetTransactionsTable);
  await db.delete(fleetVehiclesTable);
  await db.delete(fleetDriversTable);
  await db.delete(fleetAlertsTable);
  await db.delete(fleetCompanyTable);

  // ---- Stations (Cairo + Alexandria + Giza + 6th of October) ----
  const stations = await db
    .insert(stationsTable)
    .values([
      {
        name: "FuelFlow Zamalek",
        address: "26th of July Corridor, Zamalek",
        city: "Cairo",
        lat: 30.0626,
        lng: 31.2197,
        fuelTypes: ["gasoline_91", "gasoline_95", "diesel"],
        priceGasoline91: PRICE_91,
        priceGasoline95: PRICE_95,
        priceDiesel: PRICE_DIESEL,
        isOpen: true,
        rating: 4.7,
        amenities: ["Convenience Store", "Car Wash", "ATM", "Coffee"],
      },
      {
        name: "FuelFlow Maadi",
        address: "Corniche El Nil, Maadi",
        city: "Cairo",
        lat: 29.9605,
        lng: 31.2569,
        fuelTypes: ["gasoline_91", "gasoline_95", "diesel"],
        priceGasoline91: PRICE_91,
        priceGasoline95: PRICE_95,
        priceDiesel: PRICE_DIESEL,
        isOpen: true,
        rating: 4.5,
        amenities: ["Convenience Store", "Restrooms", "Air Pump"],
      },
      {
        name: "FuelFlow New Cairo",
        address: "90th Street, Fifth Settlement",
        city: "New Cairo",
        lat: 30.0131,
        lng: 31.4956,
        fuelTypes: ["gasoline_95", "diesel"],
        priceGasoline91: PRICE_91,
        priceGasoline95: PRICE_95,
        priceDiesel: PRICE_DIESEL,
        isOpen: true,
        rating: 4.8,
        amenities: ["Premium Lounge", "EV Charging", "Cafe", "Car Wash"],
      },
      {
        name: "FuelFlow Nasr City",
        address: "Abbas El Akkad Street, Nasr City",
        city: "Cairo",
        lat: 30.0588,
        lng: 31.3412,
        fuelTypes: ["gasoline_91", "gasoline_95", "diesel"],
        priceGasoline91: PRICE_91,
        priceGasoline95: PRICE_95,
        priceDiesel: PRICE_DIESEL,
        isOpen: true,
        rating: 4.6,
        amenities: ["Convenience Store", "Tire Service", "ATM"],
      },
      {
        name: "FuelFlow Heliopolis",
        address: "El Nozha Street, Heliopolis",
        city: "Cairo",
        lat: 30.0928,
        lng: 31.3265,
        fuelTypes: ["gasoline_91", "gasoline_95", "diesel"],
        priceGasoline91: PRICE_91,
        priceGasoline95: PRICE_95,
        priceDiesel: PRICE_DIESEL,
        isOpen: true,
        rating: 4.4,
        amenities: ["Convenience Store", "Restrooms"],
      },
      {
        name: "FuelFlow Cairo Airport",
        address: "Cairo International Airport Road",
        city: "Cairo",
        lat: 30.1219,
        lng: 31.4056,
        fuelTypes: ["gasoline_91", "gasoline_95", "diesel"],
        priceGasoline91: PRICE_91,
        priceGasoline95: PRICE_95,
        priceDiesel: PRICE_DIESEL,
        isOpen: true,
        rating: 4.3,
        amenities: ["24/7", "Truck Stop", "Restaurant"],
      },
      {
        name: "FuelFlow 6th of October",
        address: "26th of July Axis, 6th of October City",
        city: "6th of October",
        lat: 29.9285,
        lng: 30.9188,
        fuelTypes: ["gasoline_91", "gasoline_95", "diesel"],
        priceGasoline91: PRICE_91,
        priceGasoline95: PRICE_95,
        priceDiesel: PRICE_DIESEL,
        isOpen: true,
        rating: 4.6,
        amenities: ["Convenience Store", "Coffee", "Car Wash"],
      },
      {
        name: "FuelFlow Alexandria Corniche",
        address: "Corniche Road, Sidi Gaber",
        city: "Alexandria",
        lat: 31.2156,
        lng: 29.9553,
        fuelTypes: ["gasoline_91", "gasoline_95", "diesel"],
        priceGasoline91: PRICE_91,
        priceGasoline95: PRICE_95,
        priceDiesel: PRICE_DIESEL,
        isOpen: false,
        rating: 4.5,
        amenities: ["Convenience Store", "Restaurant"],
      },
    ])
    .returning();

  // ---- Wallet ----
  const [wallet] = await db
    .insert(walletsTable)
    .values({
      balance: 3245.5,
      currency: "EGP",
      cardNumber: "5239 **** **** 4421",
      cardHolder: "Ahmed Hassan",
      monthlyLimit: 8000,
    })
    .returning();

  await db.insert(walletTransactionsTable).values([
    {
      walletId: wallet.id,
      type: "recharge",
      amount: 1000,
      method: "mada",
      description: "Wallet recharged via Meeza",
      createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
    },
    {
      walletId: wallet.id,
      type: "recharge",
      amount: 2000,
      method: "apple_pay",
      description: "Wallet recharged via Apple Pay",
      createdAt: new Date(Date.now() - 12 * 24 * 60 * 60 * 1000),
    },
    {
      walletId: wallet.id,
      type: "debit",
      amount: 587.25,
      method: "wallet",
      description: "Fuel purchase - 38.5L",
      createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
    },
  ]);

  // ---- Vehicles ----
  const vehicles = await db
    .insert(vehiclesTable)
    .values([
      {
        name: "Daily Driver",
        make: "Toyota",
        model: "Corolla",
        year: 2023,
        plate: "ا ب ج 4421",
        fuelType: "gasoline_95",
        tankCapacity: 50,
        color: "Pearl White",
      },
      {
        name: "Family SUV",
        make: "Hyundai",
        model: "Tucson",
        year: 2022,
        plate: "د ه و 8812",
        fuelType: "gasoline_91",
        tankCapacity: 62,
        color: "Sand Beige",
      },
      {
        name: "City Runabout",
        make: "Nissan",
        model: "Sunny",
        year: 2024,
        plate: "ز ح ط 1290",
        fuelType: "gasoline_91",
        tankCapacity: 41,
        color: "Midnight Blue",
      },
    ])
    .returning();

  // ---- Personal transactions across the past year ----
  const fuelTypes = ["gasoline_91", "gasoline_95", "diesel"] as const;
  const personalTx: (typeof transactionsTable.$inferInsert)[] = [];
  const now = Date.now();
  for (let i = 0; i < 60; i++) {
    const v = vehicles[i % vehicles.length];
    const s = stations[i % stations.length];
    const ft = (v.fuelType as (typeof fuelTypes)[number]) ?? fuelTypes[i % 3];
    const liters = 25 + Math.round(Math.random() * 30 * 10) / 10;
    const ppl = ft === "diesel" ? PRICE_DIESEL : ft === "gasoline_95" ? PRICE_95 : PRICE_91;
    const total = Number((liters * ppl).toFixed(2));
    const daysAgo = Math.floor(Math.random() * 330);
    personalTx.push({
      vehicleId: v.id,
      stationId: s.id,
      fuelType: ft,
      liters: Number(liters.toFixed(2)),
      pricePerLiter: ppl,
      total,
      createdAt: new Date(now - daysAgo * 24 * 60 * 60 * 1000),
    });
  }
  await db.insert(transactionsTable).values(personalTx);

  // ---- Notifications ----
  await db.insert(notificationsTable).values([
    {
      type: "promotion",
      title: "Double points this weekend",
      message: "Earn 2x FuelFlow points on every refuel from Friday to Sunday at all network stations.",
      isRead: false,
    },
    {
      type: "charge",
      title: "Wallet charged - EGP 587.25",
      message: "Your fueling at FuelFlow Zamalek was completed successfully. Receipt is in transactions.",
      isRead: false,
    },
    {
      type: "update",
      title: "New station opened in Heliopolis",
      message: "FuelFlow Heliopolis is now serving Gasoline 92, 80, and Diesel with full convenience services.",
      isRead: true,
      createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
    },
    {
      type: "alert",
      title: "Monthly spend at 65% of limit",
      message: "Heads up - you have spent EGP 5,200 of your EGP 8,000 monthly wallet limit.",
      isRead: false,
      createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
    },
  ]);

  // ---- Support tickets ----
  await db.insert(supportTicketsTable).values([
    {
      category: "complaint",
      subject: "Pump 4 receipt not generated",
      message: "I refueled at FuelFlow Maadi but the receipt wasn't issued from pump 4.",
      status: "in_progress",
      createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
    },
    {
      category: "suggestion",
      subject: "Add EV charging at more stations",
      message: "Please consider adding EV chargers to the Zamalek and Maadi stations.",
      status: "open",
      createdAt: new Date(Date.now() - 9 * 24 * 60 * 60 * 1000),
    },
  ]);

  // ---- Fleet (B2B) ----
  await db.insert(fleetCompanyTable).values({ name: "Nile Logistics Co." });

  const drivers = await db
    .insert(fleetDriversTable)
    .values([
      { name: "Mohamed Abdelrahman", employeeId: "NL-2041", status: "active" },
      { name: "Khaled El-Sayed", employeeId: "NL-2078", status: "active" },
      { name: "Tarek Ibrahim", employeeId: "NL-2103", status: "active" },
      { name: "Youssef Mahmoud", employeeId: "NL-2119", status: "suspended" },
      { name: "Omar El-Naggar", employeeId: "NL-2154", status: "active" },
    ])
    .returning();

  const fleetVehicles = await db
    .insert(fleetVehiclesTable)
    .values([
      {
        plate: "MSR 7710",
        make: "Hino",
        model: "500 Series",
        driver: drivers[0].name,
        department: "Long Haul",
        status: "active",
        lastFueledAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
      },
      {
        plate: "MSR 7811",
        make: "Isuzu",
        model: "FRR",
        driver: drivers[1].name,
        department: "City Delivery",
        status: "active",
        lastFueledAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
      },
      {
        plate: "MSR 7944",
        make: "Mercedes-Benz",
        model: "Actros",
        driver: drivers[2].name,
        department: "Long Haul",
        status: "active",
        lastFueledAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
      },
      {
        plate: "MSR 8012",
        make: "Toyota",
        model: "Hiace",
        driver: drivers[3].name,
        department: "Operations",
        status: "maintenance",
        lastFueledAt: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000),
      },
      {
        plate: "MSR 8158",
        make: "Ford",
        model: "Transit",
        driver: drivers[4].name,
        department: "City Delivery",
        status: "idle",
        lastFueledAt: new Date(Date.now() - 6 * 24 * 60 * 60 * 1000),
      },
      {
        plate: "MSR 8290",
        make: "Hino",
        model: "300 Series",
        driver: drivers[0].name,
        department: "Long Haul",
        status: "active",
        lastFueledAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
      },
    ])
    .returning();

  const fleetTx: (typeof fleetTransactionsTable.$inferInsert)[] = [];
  for (let i = 0; i < 200; i++) {
    const v = fleetVehicles[i % fleetVehicles.length];
    const liters = 60 + Math.round(Math.random() * 200 * 10) / 10;
    const ppl = PRICE_DIESEL;
    const total = Number((liters * ppl).toFixed(2));
    const daysAgo = Math.floor(Math.random() * 330);
    fleetTx.push({
      fleetVehicleId: v.id,
      liters: Number(liters.toFixed(2)),
      total,
      createdAt: new Date(now - daysAgo * 24 * 60 * 60 * 1000),
    });
  }
  await db.insert(fleetTransactionsTable).values(fleetTx);

  await db.insert(fleetAlertsTable).values([
    {
      severity: "warning",
      message: "MSR 7710 consumption up 18% vs last month - inspection recommended",
    },
    {
      severity: "critical",
      message: "Driver Youssef Mahmoud suspended - reassign MSR 8012",
    },
    {
      severity: "info",
      message: "Fleet monthly spend tracking 6% below budget",
    },
    {
      severity: "warning",
      message: "MSR 8158 idle for 6 days - utilization review needed",
    },
  ]);

  console.log("Seed complete.");
  await pool.end();
}

main().catch(async (err) => {
  console.error(err);
  await pool.end();
  process.exit(1);
});
