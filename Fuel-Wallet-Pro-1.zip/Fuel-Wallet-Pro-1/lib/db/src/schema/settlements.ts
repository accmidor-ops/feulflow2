import { pgTable, text, serial, doublePrecision, integer, timestamp } from "drizzle-orm/pg-core";

export const settlementsTable = pgTable("settlements", {
  id: serial("id").primaryKey(),
  stationId: integer("station_id").notNull(),
  period: text("period").notNull(),
  dateFrom: timestamp("date_from", { withTimezone: true }).notNull(),
  dateTo: timestamp("date_to", { withTimezone: true }).notNull(),
  transactionCount: integer("transaction_count").notNull().default(0),
  totalSales: doublePrecision("total_sales").notNull().default(0),
  commissionRate: doublePrecision("commission_rate").notNull().default(0.025),
  commissionAmount: doublePrecision("commission_amount").notNull().default(0),
  gatewayFeeRate: doublePrecision("gateway_fee_rate").notNull().default(0.015),
  gatewayFeeAmount: doublePrecision("gateway_fee_amount").notNull().default(0),
  adjustments: doublePrecision("adjustments").notNull().default(0),
  netAmount: doublePrecision("net_amount").notNull().default(0),
  status: text("status").notNull().default("pending"),
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export type Settlement = typeof settlementsTable.$inferSelect;
export type InsertSettlement = typeof settlementsTable.$inferInsert;
