import { pgTable, text, serial, doublePrecision, integer, timestamp } from "drizzle-orm/pg-core";

export const fleetCompanyTable = pgTable("fleet_company", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
});

export const fleetDriversTable = pgTable("fleet_drivers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  employeeId: text("employee_id").notNull(),
  status: text("status").notNull().default("active"),
});

export const fleetVehiclesTable = pgTable("fleet_vehicles", {
  id: serial("id").primaryKey(),
  plate: text("plate").notNull(),
  make: text("make").notNull(),
  model: text("model").notNull(),
  driver: text("driver").notNull(),
  department: text("department").notNull(),
  status: text("status").notNull().default("active"),
  lastFueledAt: timestamp("last_fueled_at", { withTimezone: true }),
});

export const fleetTransactionsTable = pgTable("fleet_transactions", {
  id: serial("id").primaryKey(),
  fleetVehicleId: integer("fleet_vehicle_id").notNull(),
  liters: doublePrecision("liters").notNull(),
  total: doublePrecision("total").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const fleetAlertsTable = pgTable("fleet_alerts", {
  id: serial("id").primaryKey(),
  severity: text("severity").notNull(),
  message: text("message").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type FleetCompany = typeof fleetCompanyTable.$inferSelect;
export type FleetDriver = typeof fleetDriversTable.$inferSelect;
export type FleetVehicle = typeof fleetVehiclesTable.$inferSelect;
export type FleetTransaction = typeof fleetTransactionsTable.$inferSelect;
export type FleetAlert = typeof fleetAlertsTable.$inferSelect;
