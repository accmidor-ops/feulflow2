import { pgTable, text, serial, doublePrecision, timestamp, integer } from "drizzle-orm/pg-core";

export const walletsTable = pgTable("wallets", {
  id: serial("id").primaryKey(),
  balance: doublePrecision("balance").notNull().default(0),
  currency: text("currency").notNull().default("SAR"),
  cardNumber: text("card_number").notNull(),
  cardHolder: text("card_holder").notNull(),
  monthlyLimit: doublePrecision("monthly_limit").notNull().default(5000),
});

export const walletTransactionsTable = pgTable("wallet_transactions", {
  id: serial("id").primaryKey(),
  walletId: integer("wallet_id").notNull().references(() => walletsTable.id),
  type: text("type").notNull(),
  amount: doublePrecision("amount").notNull(),
  method: text("method").notNull(),
  description: text("description").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type Wallet = typeof walletsTable.$inferSelect;
export type WalletTransaction = typeof walletTransactionsTable.$inferSelect;
