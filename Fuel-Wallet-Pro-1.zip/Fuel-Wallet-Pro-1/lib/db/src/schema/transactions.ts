import { pgTable, text, serial, doublePrecision, integer, timestamp } from "drizzle-orm/pg-core";

export const transactionsTable = pgTable("transactions", {
  id: serial("id").primaryKey(),
  vehicleId: integer("vehicle_id").notNull(),
  stationId: integer("station_id").notNull(),
  fuelType: text("fuel_type").notNull(),
  liters: doublePrecision("liters").notNull(),
  pricePerLiter: doublePrecision("price_per_liter").notNull(),
  total: doublePrecision("total").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const fuelingSessionsTable = pgTable("fueling_sessions", {
  id: serial("id").primaryKey(),
  qrPayload: text("qr_payload").notNull(),
  vehicleId: integer("vehicle_id").notNull(),
  stationId: integer("station_id").notNull(),
  status: text("status").notNull().default("pending"),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type Transaction = typeof transactionsTable.$inferSelect;
export type FuelingSession = typeof fuelingSessionsTable.$inferSelect;
