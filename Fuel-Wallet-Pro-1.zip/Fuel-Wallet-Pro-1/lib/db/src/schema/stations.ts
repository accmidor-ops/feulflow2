import { pgTable, text, serial, doublePrecision, boolean, jsonb } from "drizzle-orm/pg-core";

export const stationsTable = pgTable("stations", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  address: text("address").notNull(),
  city: text("city").notNull(),
  lat: doublePrecision("lat").notNull(),
  lng: doublePrecision("lng").notNull(),
  fuelTypes: text("fuel_types").array().notNull(),
  priceGasoline91: doublePrecision("price_gasoline_91").notNull(),
  priceGasoline95: doublePrecision("price_gasoline_95").notNull(),
  priceDiesel: doublePrecision("price_diesel").notNull(),
  isOpen: boolean("is_open").notNull().default(true),
  rating: doublePrecision("rating").notNull().default(4.5),
  amenities: text("amenities").array().notNull(),
  meta: jsonb("meta"),
});

export type Station = typeof stationsTable.$inferSelect;
